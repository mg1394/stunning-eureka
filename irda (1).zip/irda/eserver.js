﻿
require('rootpath')();
var express = require('express');
var app = express();
var session = require('express-session');
var bodyParser = require('body-parser');
var expressJwt = require('express-jwt');
var config = require('config.json');
var http = require('http');
var api = require('apiConfig.json');
var rp = require('request-promise');

var server = http.createServer(app);

var mongo = require('mongodb').MongoClient;
var client = require('socket.io')(server);
// .listen(app).sockets;


app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(session({ secret: config.secret, proxy: true, resave: false, saveUninitialized: true }));

// use JWT auth to secure the api
app.use('/api', expressJwt({ secret: config.secret }).unless({ path: ['/api/users/authenticate', '/api/users/register'] }));

// routes
app.use('/login', require('./controllers/login.controller'));
app.use('/register', require('./controllers/register.controller'));
app.use('/forgotPassword', require('./controllers/forgotPassword.controller'));
app.use('/app', require('./controllers/app.controller'));
app.use('/api/users', require('./controllers/api/users.controller'));
app.use('/api/customer', require('./controllers/api/svr.customer.controller'));
app.use('/api/transactions', require('./controllers/api/svr.transactions.controller'));
app.use('/api/fileUpload', require('./controllers/api/svr.fileUpload.controller'));
app.use('/api/document', require('./controllers/api/svr.document.controller'));
app.use('/api/consent', require('./controllers/api/svr.consent.controller'));
app.use('/api/insurer', require('./controllers/api/svr.insurer.controller'));
app.use('/api/getCustInfo', require('./controllers/api/svr.getCustInfo.controller'));
app.use('/api/getSessionInfo', require('./controllers/api/svr.session.controller'));
app.use('/img', express.static(__dirname + '/views'));
app.use('/uploadedDoc', express.static(__dirname + '/uploads'))

// Connect mongodb
mongo.connect('mongodb://cateina:cateina@ds139984.mlab.com:39984/irda', function(err, db) {
    
        if(err){
            throw err;
        }
        console.log("Mongodb connected....");
    })

    client.on('connection', function(socket) {  
        rp({
            uri:api.localhost+api.transactions,
            headers: {
                'User-Agent': 'Request-Promise',
                'Content-Type': 'application/json'
            }
        }).then(function(data) {
            //console.log('data = ',data);
            socket.emit('getTransactions', { transaction: data });
        });
        
    });
   

    // function getMyDetails(socket){
    //     var irdaRegNo = req.session.irdaRegNo;
    //     rp({
    //         uri:api.localhost+api.getInsurerById+'/'+irdaRegNo,
    //         headers: {
    //             'User-Agent': 'Request-Promise',
    //             'Content-Type': 'application/json'
    //         }
    //     }).then(function(data) {
    //         //if (err) deferred.reject(err.name + ': ' + err.message);
    //         //console.log("successfully get all cust data :::::::::::::: ", data);
    //         socket.emit('getMyDetails', { myDetails: data });
    
    //     });
    // }

    
// make '/app' default route
app.get('/', function (req, res) {
    return res.redirect('/app');
});

// start server
var server = server.listen(3010, function () {
    console.log('Server listening at http://' + server.address().address + ':' + server.address().port);
});