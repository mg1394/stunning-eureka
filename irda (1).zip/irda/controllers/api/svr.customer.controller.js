/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var customerService = require('services/svr.customer.service');

// routes

router.post('/save', save);
router.post('/getAllCustomerDetails', getAllCustomerDetails);
router.post('/getAllCustomerDetailsById/:_id' ,getAllCustomerDetailsById);
router.delete('/:_id', deleteUser);
router.post('/getAllCustomerDetails', getAllCustomerDetails);

module.exports = router;

// io.on('connection', function (socket) {
//     console.log('a user connected');

//     mongo.connect(process.env.CUSTOMCONNSTR_MONGOLAB_URI, function (err, db) {
//         var collection = db.collection('chat messages')
//         var stream = collection.find().sort({ _id : -1 }).limit(10).stream();
//         stream.on('data', function (chat) { socket.emit('chat', chat); });
//     });

//     socket.on('disconnect', function () {
//         console.log('user disconnected');
//     });

//     socket.on('chat', function (msg) {
//         mongo.connect(process.env.CUSTOMCONNSTR_MONGOLAB_URI, function (err, db) {
//             var collection = db.collection('chat messages');
//             collection.insert({ content: msg }, function (err, o) {
//                 if (err) { console.warn(err.message); }
//                 else { console.log("chat message inserted into db: " + msg); }
//             });
//         });

//         socket.broadcast.emit('chat', msg);
//     });
// });
   

// Akshay :- 21-08-2017 Save Customer details
function save(req, res) {
    console.log(req.body);
    customerService.save(req, res)
        .then(function (client) {
            res.send(client);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// Akshay :- 21-08-2017 get all Customer details
function getAllCustomerDetails(req, res) {
    customerService.getAllCustomerDetails(req, res)
        .then(function (customer) {
            res.send(customer);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// Akshay :- 21-08-2017 get all Customer details by id
function getAllCustomerDetailsById(req, res) {
    customerService.getAllCustomerDetailsById(req, res)
        .then(function (customer) {
            res.send(customer);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function deleteUser(req, res) {
    customerService.delete(req, res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}