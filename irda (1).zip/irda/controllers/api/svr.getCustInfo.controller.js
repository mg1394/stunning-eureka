/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var CustInfoService = require('services/svr.getCustInfo.service');

// routes

router.post('/getAllCustInfo', getAllCustInfo);

module.exports = router;

// Akshay :- 21-08-2017 get all Customer details by id
function getAllCustInfo(req, res) {
    CustInfoService.getAllCustInfo(req, res)
        .then(function (customer) {
            res.send(customer);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
