/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var documentService = require('services/svr.document.service');

// routes

router.post('/getAllDocumentType', getAllDocumentType);
router.post('/getAllSaveDocuments', getAllSaveDocuments);
router.post('/getAllSaveDocById/:medId', getAllSaveDocById);
router.post('/deleteDocument', deleteDocument);
router.post('/saveDocument', saveDocument);
router.delete('/:_id', deleteUser);

module.exports = router;

// Akshay :- 21-08-2017 Save Customer details
function getAllDocumentType(req, res) {
    documentService.getAllDocumentType(req, res)
        .then(function (document) {
            res.send(document);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// Akshay :- 21-08-2017 Save Customer details
function getAllSaveDocuments(req, res) {
    documentService.getAllSaveDocuments(req, res)
        .then(function (document) {
            res.send(document);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// Akshay :- 21-08-2017 Save Customer details
function getAllSaveDocById(req, res) {
    console.log("im in new functio  0000000000000000");
    documentService.getAllSaveDocById(req, res)
        .then(function (document) {
            res.send(document);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// Akshay :- 22-08-2017 Save document details
function saveDocument(req, res) {
    documentService.saveDocument(req, res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function deleteDocument(req, res) {
    documentService.deleteDocument(req, res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function deleteUser(req, res) {
    documentService.delete(req, res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}