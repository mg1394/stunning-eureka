/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var md5 = require('md5');
var sha1 = require('js-sha1');
var sha256 = require('js-sha256');
var crypto = require('crypto');
var path = require('path');
var multer = require('multer');
var mkdirp = require('mkdirp');
var app = express();

var customerService = require('services/svr.customer.service');

var storage = multer.diskStorage({
    
     destination: function(req, file, cb) {
         console.log("im in storage");
         var dir = './uploads/' + 'customer' + '/';
         mkdirp(dir, function(err) {
             if (err) {
                 console.error(err);
             }
             // move cb to here
             cb(null, dir);
         });
     },
     filename: function(req, file, cb) {
         cb(null, file.originalname);
     }
     
 });

var upload = multer({ storage: storage });

router.post('/saveFile', upload.single('file'), saveFile);

module.exports = router;

function saveFile(req, res) {
    console.log(req.file);
    var hash = md5(req.file);
    req.hash = hash;
    console.log("hash = ",req.hash);
    // saltHashPassword(hash1);

    saltHashPassword(hash);
    return res.send(hash);
}



var genRandomString = function(length) {
    return crypto.randomBytes(Math.ceil(length / 2))
        .toString('hex') /** convert to hexadecimal format */
        .slice(0, length); /** return required number of characters */
};

var sha512 = function(password, salt) {
    var hash = crypto.createHmac('sha512', salt); /** Hashing algorithm sha512 */
    hash.update(password);
    var value = hash.digest('hex');
    return {
        salt: salt,
        passwordHash: value
    };
};


function saltHashPassword(hash) {
    var userpassword = hash;
    console.log("im in set hash",userpassword);
    var salt = genRandomString(16); /** Gives us salt of length 16 */
    var passwordData = sha512(userpassword, salt);
}