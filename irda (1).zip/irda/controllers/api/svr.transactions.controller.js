/**
 * Created By :- Madhura
 * Created Date :- 19-09-2017 11:00 am
 * Version :- 1.0.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var transactionsService = require('services/svr.transactions.service');

// routes

router.post('/getAllTransactionDetails', getAllTransactionDetails);

module.exports = router;

function getAllTransactionDetails(req, res) {
    transactionsService.getAllTransactionDetails(req, res)
        .then(function (transactions) {
            res.send(transactions);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
