/**
 * Created By :- Akshay
 * Created Date :- 02-09-2017 01:00 pm
 * Version :- 1.0.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var consentService = require('services/svr.consent.service');

// routes

router.post('/reqConsent', reqConsent);
router.post('/sendTelegram', sendTelegram);
router.delete('/:_id', deleteUser);

module.exports = router;

// Akshay :- 21-08-2017 get consent by sms
function reqConsent(req, res) {
    console.log("im in get consent api-ser",req.body);
    consentService.reqConsent(req, res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// Akshay :- 21-08-2017 send telegram
function sendTelegram(req, res) {
    console.log("im in get consent api-ser");
    consentService.sendTelegram(req, res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function deleteUser(req, res) {
    consentService.delete(req, res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}