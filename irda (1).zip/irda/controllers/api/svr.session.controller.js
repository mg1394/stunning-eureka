/**
 * Created By :- Akshay
 * Created Date :- 25-09-2017 01:44 pm
 * Version :- 1.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var telegramService = require('services/svr.telegram.service');

router.post('/', getSessionDetails);
router.post('/saveTelegramResponce/', saveTelegramResponce);

module.exports = router;

function getSessionDetails(req,res) {
    //var name = req.session.username;
    var session = req.session;
    // console.log('req.session.role=',req.session);
    res.send(session);
}

// Akshay :- 21-08-2017 get all Customer details
function saveTelegramResponce(req, res) {
    console.log('saveTelegramResponce1');
    telegramService.saveTelegramResponce(req, res)
        .then(function (res) {
            res.send(res);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}