/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var insurerService = require('services/svr.insurer.service');

// routes

router.post('/getIns', getInsurerByIRDARegNo);

module.exports = router; 

// Akshay :- 21-08-2017 Save Customer details
function getInsurerByIRDARegNo(req, res) {
    insurerService.BKCgetAllCusDetById(req, res)
        .then(function (insurer) {
            res.send(insurer);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


function deleteUser(req, res) {
    customerService.delete(req, res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}