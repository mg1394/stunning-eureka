/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('ConsentDetails.ConsentDetailsController', Controller);

    function Controller($scope,$state,$stateParams,FlashService,InsurerService,$location,$anchorScroll,SessionService) {
        var vm = this;
        vm.user = null;
        console.log("im in consent controler");
        $scope.myDetails = [];
        vm.custId = $stateParams.custId;


        $scope.gotoBottom = function() {
            console.log('called');
            // set the location.hash to the id of
            // the element you wish to scroll to.
            $location.hash('bottom');
            
            // call $anchorScroll()
            $anchorScroll();
            };

        // var Date = Date();

        // var socket = io.connect('http://127.0.0.1:3010');
        // socket.on('getMyDetails', function(data) {
        //     $scope.myDetails = [];
        //     //console.log('Connected transaction:', data.transaction);
        //     var myDetail = JSON.parse(data.myDetails);
            
        //     $scope.$apply(() => $scope.myDetails=myDetail);
            
        // });
        // pie starts
        //pie
        // var ctxP = document.getElementById("pieChart").getContext('2d');
        // var myPieChart = new Chart(ctxP, {
        //     type: 'pie',
        //     data: {
        //         labels: ["Red", "Green", "Yellow", "Grey", "Dark Grey"],
        //         datasets: [
        //             {
        //                 data: [300, 40, 120],
        //                 backgroundColor: ["#F7464A", "#46BFBD", "#FDB45C", "#949FB1", "#4D5360"],
        //                 hoverBackgroundColor: ["#FF5A5E", "#5AD3D1", "#FFC870", "#A8B3C5", "#616774"]
        //             }
        //         ]
        //     },
        //     options: {
        //         responsive: true
        //     }    
        // });
         //  pie ends

   
    
        $scope.cancel = function() {
            $state.go('customerDetails');            
        }

        $scope.incoming = true;
        $scope.outgoing = false;

        $scope.displayIncoming = function(){
            $scope.outgoing = false;
            $scope.incoming = true;
        }

        $scope.displayOutgoing = function(){
            $scope.incoming = false;
            $scope.outgoing = true;
            
        }
        var getInsurerByIRDARegNo = function() {
            InsurerService.getInsurerByIRDARegNo().then(function (Document) {
                vm.document = Document;

                var lineChartData = {
    labels: ["2017,09,03", "2017,09,04", "2017,09,05", "2017,09,06", "2017,09,07", "2017,09,08", "2017,09,04"],
    datasets: [{
        fillColor: "rgba(220,220,220,0)",
        strokeColor: "rgba(220,180,0,1)",
        pointColor: "rgba(220,180,0,1)",
        //data: [vm.document.received]
        data:[20,30,80,20,40,10,60]
    }, {
        fillColor: "rgba(151,187,205,0)",
        strokeColor: "rgba(151,187,205,1)",
        pointColor: "rgba(151,187,205,1)",
        //data: [vm.document.given]
        data:[60,10,40,20,80,30,20]
    }]

}

Chart.defaults.global.animationSteps = 50;
Chart.defaults.global.tooltipYPadding = 16;
Chart.defaults.global.tooltipCornerRadius = 0;
Chart.defaults.global.tooltipTitleFontStyle = "normal";
Chart.defaults.global.tooltipFillColor = "rgba(0,160,0,0.8)";
Chart.defaults.global.animationEasing = "easeOutBounce";
Chart.defaults.global.responsive = true;
Chart.defaults.global.scaleLineColor = "black";
Chart.defaults.global.scaleFontSize = 16;

var ctx = document.getElementById("canvas").getContext("2d");
var LineChartDemo = new Chart(ctx).Line(lineChartData, {
    pointDotRadius: 10,
    bezierCurve: false,
    scaleShowVerticalLines: false,
    scaleShowHorizontalLines: false,
    // scaleGridLineColor: "black"
});
               console.log("my doc::::::::::::::::::",vm.document);
            });       
        };

        var getSession = function() { 
            console.log("my doc::::::::::::::::::"); 
            SessionService.getSessionDet().then(function (sess) { 
                vm.sess = sess; 
                // console.log("my doc::::::::::::::::::",vm.sess); 
            }); 
        };

        var saveTelegramResponce = function() { 
            console.log("my tele function ::::::::::::::::::"); 
            SessionService.saveTelegramResponce().then(function (result) { 
                vm.sess = result; 
                // console.log("my tele function::::::::::::::::::",result); 
            }); 
        };

        getInsurerByIRDARegNo();
        // var refreshId = setInterval(getInsurerByIRDARegNo, 1000);

        getSession();
        saveTelegramResponce();
    }

})();