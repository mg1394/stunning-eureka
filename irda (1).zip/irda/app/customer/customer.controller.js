/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 * Created By :- Akshay
 * Created Date :- 14-09-2017 03:00 pm
 * Version :- 1.1.0
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('Customer.CustomerController', Controller);

    function Controller($window, $scope, $state,UserService, FlashService, CustomerService, FileUpload, DocumentService) {
        var vm = this;
        vm.user = null;

        var socket = io.connect('http://127.0.0.1:3010');

        //check for connection
        if (socket != undefined) {
            console.log('Connected to socket.....');
            socket.on('output', function(data) {
                console.log("Finally = ", data);
            });
        }

        // Akshay :- 21-08-2017 Save Customer details
        vm.saveClient = function(customer) {
            console.log("im in save ", customer);
            CustomerService.save(customer).then(function(result) {
                FlashService.Success('Customer saved');
                vm.clientResAadhrNo = result.AadharNumber;
                console.log("vm.clientResAadhrNo::::::::",vm.clientResAadhrNo);    
                $state.go('documentDetails',{clientResAadhrNo : vm.clientResAadhrNo});
            })
            .catch(function (error) {
                FlashService.Error(error);
            });        
        }

        vm.cancel = function(customer) {
            document.getElementById("customerOverview").reset();
        }

        vm.uploadFile = function(myFile) {
            console.log('my final file=', myFile);
            vm.file = myFile;
            FileUpload.uploadFile(myFile).then(function(hash) {
                vm.hash = hash;
            });
        };

        // Akshay : 14-09-2017 save medical records to the blockchain
        vm.saveDocument = function(document) {
            var DocumentPath = './uploads/' + 'customer' + '/';
            document.DocumentPath = DocumentPath;
            document.hash = vm.hash;
            var file = vm.file;
            console.log("file milgayi = ", file);
            document.FileName = file.name;
            console.log("aadhar milgayi = ", vm.clientResAadhrNo);
            document.AadharNumber = vm.clientResAadhrNo;
            console.log("im in save med records ", document.AadharNumber);
            // CustomerService.save(document).then(function (result) {
            //     window.location.reload();
            // });

            DocumentService.saveDocument(document).then(function(result) {
                console.log("all documents = ", result);
                window.location.reload();
            });
        };

        vm.deleteDocument = function(d) {
            console.log("im in delete ", d);
            DocumentService.deleteDocument(d).then(function(result) {
                // console.log("all delete = ",result);
                window.location.reload();
            });
        };

       

        var getAllDocumenttype = function() {
            DocumentService.getAllDocumentType().then(function(DocumentType) {
                vm.documentType = DocumentType;
                // console.log("all documents = ",vm.documentType);
            });
        };

        
        getAllDocumenttype();
    }

})();