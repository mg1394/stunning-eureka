/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 * Created By :- Akshay
 * Created Date :- 14-09-2017 03:00 pm
 * Version :- 1.1.0
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('Customer.DocumentDetailsController', Controller);

    function Controller($window, $scope,$state,$stateParams,DocumentService,FileUpload,FlashService) {
        var vm = this;
        vm.user = null;
        vm.custId = $stateParams.clientResAadhrNo;
        console.log('I am in document details',vm.custId);

        // Akshay : 14-09-2017 save medical records to the blockchain
        vm.saveDocument = function(document) {
            var DocumentPath = './uploads/' + 'customer' + '/';
            document.DocumentPath = DocumentPath;
            document.hash = vm.hash;
            document.AadharNumber = vm.custId;
            document.fileName = vm.fileName;
            console.log("docum file ::::::::",document.fileName);
            if(document.fileName ==='undefined' ){
                console.log("Im in save doc else");
                alert("Please select File");                
            }else{
                console.log("Im in save doc");
                DocumentService.saveDocument(document).then(function(result) {
                    FlashService.Success('Document saved');
                    console.log("all documents = ", result);
                    $state.go('fileUpload');
                })
                .catch(function (error) {
                    FlashService.Error(error);
                });
            }
        };

        var getAllDocumenttype = function() {
            DocumentService.getAllDocumentType().then(function(DocumentType) {
                vm.documentType = DocumentType;
                // console.log("all documents = ",vm.documentType);
            });
        };

        vm.uploadFile = function(myFile) {
            console.log('my final file=', myFile);
            vm.file = myFile;
            vm.fileName = myFile.name;
            FileUpload.uploadFile(myFile).then(function(hash) {
                vm.hash = hash;
                FlashService.Success('File saved');
                // console.log("all documents = ", result);
            })
            .catch(function (error) {
                FlashService.Error(error);
            });
        };

        getAllDocumenttype();
    }

})();