/**
 * Created By :- Akshay
 * Created Date :- 18-09-2017 09:00 am
 * Version :- 1.0.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('GetCustInfo.GetCustInfoController', Controller);

    function Controller($window, $scope, $state,FlashService,GetCustInfo) {
        console.log("im in get cust info");
        var vm = this;
        vm.user = null;

        var getAllCustInfo = function() {
            GetCustInfo.getAllCustInfo().then(function(customer) {
                vm.customer = customer;
                console.log("all path = ", vm.customer);
            });
        };

        getAllCustInfo();
         
    }

})();