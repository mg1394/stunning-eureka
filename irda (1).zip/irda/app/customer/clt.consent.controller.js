/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('Consent.ConsentController', Controller);

    function Controller($window,$scope,$state,$stateParams,FlashService,CustomerService,ConsentService) {
        var vm = this;
        vm.user = null;

        vm.custId = $stateParams.custId;
        
        $scope.cancel = function() {
            $state.go('customerDetails');            
        }

        vm.reqConsent = function (data){
            console.log(":::im in get consent:::",data)
            ConsentService.reqConsent(data).then(function (responce) {
                console.log("final res::::::::::::",responce);
                // $state.go('customerDetails');
            });
        }

        // Akshay 01-09-2017 :  get single customer by id
        function getAllCustomerDetailsById() {
            // get single customer by id
            CustomerService.getAllCustomerDetailsById(vm.custId).then(function (customerDetails) {
                vm.customer = customerDetails;
                console.log(vm.customer);
            });
        }

        getAllCustomerDetailsById();
    }

})();