/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 * Updated By :- Akshay
 * Created Date :- 14-09-2017 05:00 am
 * Version :- 1.1.0 get med data from blockchain
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('Customer.CustomerDetailsController', Controller);

    function Controller($window, $scope, $state,UserService,FlashService,CustomerService,SessionService) {
        var vm = this;

        vm.user = null;
        
        $scope.reqConsent = function(val1) {
            var custId = val1;
            console.log(val1);
            $state.go('Consent',{custId:val1});            
        }

        
        $scope.goToAddMedRec = function(val1) {
            var custId = val1;
            console.log(val1);
            $state.go('documentDetails',{clientResAadhrNo:val1});            
        }
        $scope.goToDocument = function(val1) {
            var custId = val1;
            console.log("got to doc::::::::::::::",val1);
            $state.go('fileUpload',{medId:val1});            
        }

        // #Akshay 01-09-2012 get all customer details
        function getAllCustomerDetails() {
            // get current user
            CustomerService.getAllCustomerDetails().then(function (customerDetails) {
                SessionService.getSessionDet().then(function (session) {
                    vm.session = session;
                    console.log("::::::::::::::::::::::::::::::",vm.session);
                var irdaRegNo = session.irdaRegNo;
                for(var i=0;i<customerDetails.length;i++){
                    var viewDocumentFlag = false;
                    var viewConsentFlag = '';
                    var owner = customerDetails[i].owner;
                    var listApproved = [];
                    listApproved = customerDetails[i].approvedConsent;
                    var listDeclined = [];
                    listDeclined = customerDetails[i].declinedConsent;
                    console.log("listDeclined ====> ",listDeclined);
                    if(owner.endsWith(irdaRegNo)){
                        viewDocumentFlag = true;
                        customerDetails[i]["viewDocumentFlag"]=viewDocumentFlag;
                        //break;
                    } else {
                        if(typeof listApproved != 'undefined'){
                            for(var j=0;j<listApproved.length;j++){
                                var approvedRegNo = listApproved[j];
                                if(approvedRegNo == irdaRegNo){
                                    viewDocumentFlag = true;
                                    viewConsentFlag = true;
                                    customerDetails[i]["viewDocumentFlag"]=viewDocumentFlag;
                                    customerDetails[i]["viewConsentFlag"]=viewConsentFlag;
                                    break;
                                }
                            }
                        }
                        if(typeof listDeclined != 'undefined'){
                            for(var j=0;j<listDeclined.length;j++){
                                var declinedRegNo = listDeclined[j];
                                if(declinedRegNo == irdaRegNo){
                                    //viewDocumentFlag = true;
                                    viewConsentFlag = false;
                                    //customerDetails[i]["viewDocumentFlag"]=viewDocumentFlag;
                                    customerDetails[i]["viewConsentFlag"]=viewConsentFlag;
                                    break;
                                }
                            }
                        } else {
                            viewConsentFlag = '';
                            //customerDetails[i]["viewDocumentFlag"]=viewDocumentFlag;
                            customerDetails[i]["viewConsentFlag"]=viewConsentFlag;
                            
                        }
                        
                    }
                    customerDetails[i]["viewDocumentFlag"]=viewDocumentFlag;
                    customerDetails[i]["viewConsentFlag"]=viewConsentFlag;
                }
                vm.customer = customerDetails;//uncomment here
                console.log(":::::::::::::::::::",vm.customer);
            });
        });
        } 

        function initController() {
            // get current user
            UserService.GetCurrent().then(function (user) {
                vm.user = user;
            });
        }  

        getAllCustomerDetails();
        initController();  

         
    }

})();