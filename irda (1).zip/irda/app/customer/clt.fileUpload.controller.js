/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 * Created By :- Akshay
 * Created Date :- 14-09-2017 03:00 pm
 * Version :- 1.1.0
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('Customer.FileUploadController', Controller);

    function Controller($window, $scope,$stateParams, FlashService,DocumentService) {
        var vm = this;
        vm.user = null;
        console.log("im in get all save doc",$stateParams.medId);
        vm.medId = $stateParams.medId;


        var getAllSaveDocById = function() {
            console.log("vm::::::::::::::::",vm.medId);
            DocumentService.getAllSaveDocById(vm.medId).then(function(Document) {
                vm.document = Document;
                console.log("all get doc by id = ", vm.document);
            });
        };
        
        getAllSaveDocById();

    }

})();