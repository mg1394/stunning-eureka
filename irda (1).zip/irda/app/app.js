﻿/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
(function() {
    'use strict';

    angular
        .module('app', ['ui.router', 'ngFileUpload', 'radialIndicator', 'angularUtils.directives.dirPagination'])
        .config(config)
        .run(run);

    function config($stateProvider, $urlRouterProvider) {
        // default route
        $urlRouterProvider.otherwise("/consentDetails");

        $stateProvider
        // .state('home', {
        //     url: '/',
        //     templateUrl: 'home/index.html',
        //     controller: 'Home.IndexController',
        //     controllerAs: 'vm',
        //     data: { activeTab: 'home' }
        // })
            .state('customer', {
                url: '/customer',
                templateUrl: 'customer/customer.html',
                controller: 'Customer.CustomerController',
                controllerAs: 'vm',
                data: { activeTab: 'customer' }
            })
            .state('documentDetails', {
                url: '/documentDetails/:clientResAadhrNo',
                templateUrl: 'customer/documentDetails.html',
                controller: 'Customer.DocumentDetailsController',
                controllerAs: 'vm',
                data: { activeTab: 'documentDetails' }
            })
            .state('fileUpload', {
                url: '/fileUpload/:medId',
                templateUrl: 'customer/fileUpload.html',
                controller: 'Customer.FileUploadController',
                controllerAs: 'vm',
                data: { activeTab: 'fileUpload' }
            })
            .state('account', {
                url: '/account',
                templateUrl: 'account/changePassword.html',
                controller: 'ChangePassword.ChangePasswordController',
                controllerAs: 'vm',
                data: { activeTab: 'account' }
            })

        .state('customerDetails', {
                url: '/customerDetails',
                templateUrl: 'customer/customerDetails.html',
                controller: 'Customer.CustomerDetailsController',
                controllerAs: 'vm',
                data: { activeTab: 'customerDetails' }
            })
            .state('Consent', {
                url: '/Consent/:custId',
                templateUrl: 'customer/consent.html',
                controller: 'Consent.ConsentController',
                controllerAs: 'vm',
                data: { activeTab: 'Consent' }
            })
            .state('consentDetails', {
                url: '/consentDetails',
                templateUrl: 'customer/consentDetails.html',
                controller: 'ConsentDetails.ConsentDetailsController',
                controllerAs: 'vm',
                data: { activeTab: 'consentDetails' }
            })
            .state('getCustInfo', {
                url: '/getCustInfo',
                templateUrl: 'customer/getCustInfo.html',
                controller: 'GetCustInfo.GetCustInfoController',
                controllerAs: 'vm',
                data: { activeTab: 'getCustInfo' }
            })
            .state('audit', {
                url: '/audit',
                templateUrl: 'audit/audit.html',
                controller: 'audit.auditController',
                controllerAs: 'vm',
                data: { activeTab: 'audit' }
            });
    }

    function run($http, $rootScope, $window) {
        // add JWT token as default auth header
        $http.defaults.headers.common['Authorization'] = 'Bearer ' + $window.jwtToken;

        // update active tab on state change
        $rootScope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
            $rootScope.activeTab = toState.data.activeTab;
        });
    }

    // manually bootstrap angular after the JWT token is retrieved from the server
    $(function() {
        // get JWT token from server
        $.get('/app/token', function(token) {
            window.jwtToken = token;

            angular.bootstrap(document, ['app']);
        });
    });
})();