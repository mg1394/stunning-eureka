/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('CustomerService', Service);

    function Service($http, $q) {
        var service = {};

        service.save = save;
        service.getAllCustomerDetails = getAllCustomerDetails;
        service.getAllCustomerDetailsById = getAllCustomerDetailsById;
        service.Delete = Delete;

        return service;

        // Akshay :- 21-08-2017 Save Customer details
        function save(customer) {
            return $http.post('/api/customer/save',customer).then(handleSuccess, handleError);
        }

        // Akshay :- 01-09-2017 get all Customer details
        function getAllCustomerDetails() {
            return $http.post('/api/customer/getAllCustomerDetails').then(handleSuccess, handleError);
        }
        // Akshay :- 01-09-2017 get all Customer details by id
        function getAllCustomerDetailsById(_id) {
            console.log(_id);
            return $http.post('/api/customer/getAllCustomerDetailsById/'+_id).then(handleSuccess, handleError);
        }

        function Delete(_id) {
            return $http.delete('/api/customer/' + _id).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
