/**
 * Created By :- Madhura
 * Created Date :- 19-09-2017 11:00 am
 * Version :- 1.0.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('TransactionService', Service);

    function Service($http, $q) {
        var service = {};

        service.getAllTransactionDetails = getAllTransactionDetails;

        return service;

        function getAllTransactionDetails() {
            return $http.post('/api/transactions/getAllTransactionDetails').then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
