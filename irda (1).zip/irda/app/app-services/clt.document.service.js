/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('DocumentService', Service);

    function Service($http, $q) {
        var service = {};

        service.getAllDocumentType = getAllDocumentType;
        service.getAllSaveDocuments = getAllSaveDocuments;
        service.getAllSaveDocById = getAllSaveDocById;
        service.saveDocument = saveDocument;
        service.deleteDocument = deleteDocument;
        service.Delete = Delete;

        return service;

        // Akshay :- 22-08-2017 get all document details
        function getAllDocumentType() {
            return $http.post('/api/document/getAllDocumentType').then(handleSuccess, handleError);
        }

        // Akshay :- 22-08-2017 get all document details
        function getAllSaveDocuments() {
            return $http.post('/api/document/getAllSaveDocuments').then(handleSuccess, handleError);
        }

        // Akshay :- 22-08-2017 get all document details by id
        function getAllSaveDocById(medId) {
            console.log("----------------med id ::::::::::::::",medId);
            return $http.post('/api/document/getAllSaveDocById/'+medId).then(handleSuccess, handleError);
        }

        // Akshay :- 22-08-2017 delete document details
        function deleteDocument(d) {
            return $http.post('/api/document/deleteDocument/',d).then(handleSuccess, handleError);
        }
        
         // Akshay :- 22-08-2017 Save document details
         function saveDocument(document) {
            return $http.post('/api/document/saveDocument/',document).then(handleSuccess, handleError);
        }

        function Delete(_id) {
            return $http.delete('/api/customer/' + _id).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
