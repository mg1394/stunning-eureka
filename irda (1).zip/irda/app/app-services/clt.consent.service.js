/**
 * Created By :- Akshay
 * Created Date :- 02-09-2017 01:00 pm
 * Version :- 1.0.0 get consent by sms
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('ConsentService', Service);

    function Service($http, $q) {
        var service = {};

        service.reqConsent = reqConsent;
        service.sendTelegram = sendTelegram;
        service.Delete = Delete;

        return service;

        // Akshay :- 21-08-2017 get consent by sms
        function reqConsent(data) {
            console.log("____im in get consent a-ser______",data);
            return $http.post('/api/consent/reqConsent',data).then(handleSuccess, handleError);
        }

        // Akshay :- 21-08-2017 get consent by sms
        function sendTelegram() {
            console.log("im in get consent a-ser");
            return $http.post('/api/consent/sendTelegram').then(handleSuccess, handleError);
        }

        function Delete(_id) {
            return $http.delete('/api/consent/' + _id).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
