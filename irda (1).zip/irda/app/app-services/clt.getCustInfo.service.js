/**
 * Created By :- Akshay
 * Created Date :- 18-09-2017 10:00 am
 * Version :- 1.0.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('GetCustInfo', Service);

    function Service($http, $q) {
        var service = {};

        service.getAllCustInfo = getAllCustInfo;

        return service;

        // Akshay :- 22-08-2017 get all document details
        function getAllCustInfo() {
            return $http.post('/api/getCustInfo/getAllCustInfo').then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
