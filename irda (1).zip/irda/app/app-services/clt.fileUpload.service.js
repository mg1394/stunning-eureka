/**
 * Created By :- Akshasy
 * Created Date :- 23-08-2017 03:30 pm
 * Version :- 1.0.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('FileUpload', Service);

    function Service($http, $q) {

        var service = {};

        service.uploadFile = uploadFile;

        return service;

        function uploadFile(file){
            console.log("app serv  = ",file);
            var fd = new FormData();
            fd.append('file', file);
            // console.log("app     serv  = ",fb);
            return $http.post('/api/fileUpload/saveFile/',fd,{
                transformRequest: angular.identity,
                headers: {'Content-Type': undefined},
                params: "paramData"
             }).then(handleSuccess, handleError);
        }
        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }
})();
