/**
 * Created By :- Akshay
 * Created Date :- 18-09-2017 04:00 am
 * Version :- 1.0.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('SessionService', Service);

    function Service($http, $q) {
        var service = {};

        service.getSessionDet = getSessionDet;
        service.saveTelegramResponce = saveTelegramResponce

        return service;

        // Akshay :- 22-08-2017 get all document details
        function getSessionDet() {
            // console.log("im session ser:::::::::");
            return $http.post('/api/getSessionInfo/').then(handleSuccess, handleError);
        }

        // Akshay :- 22-08-2017 get all document details
        function saveTelegramResponce() {
            console.log("im session ser:::::::::");
            return $http.post('/api/getSessionInfo/saveTelegramResponce/').then(handleSuccess, handleError);
        }
        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
