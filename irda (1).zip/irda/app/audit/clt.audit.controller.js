/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('audit.auditController', Controller);

    function Controller($window,$scope,$state,$filter,$stateParams,FlashService) {
        console.log("im in audit controller")
        var vm = this;
        vm.user = null;
        $scope.transaction = [];
        var socket = io.connect('http://127.0.0.1:3010');
        socket.on('getTransactions', function(data) {
            console.log("all tran::::::::::",data);
            $scope.transaction = [];
            //console.log('Connected transaction:', data.transaction);
            var transactionDetails = JSON.parse(data.transaction);
            console.log('Connected transaction:', transactionDetails.length);
            for(var i=0; i<transactionDetails.length; i++){
                var getTxnType = [];
                
                getTxnType=transactionDetails[i].$class.split('.')[4];
                if(typeof getTxnType==='undefined'){
                    getTxnType=transactionDetails[i].$class.split('.')[3];
                }
                transactionDetails[i].$class = getTxnType;
                transactionDetails[i].txnHash = transactionDetails.length;
                transactionDetails[i].timestamp = $filter('date')(transactionDetails[i].timestamp,'dd-MM-yyyy HH:mm:ss');
                //transactionDetails[i].timestampInHour = $filter('date')(transactionDetails[i].timestamp,'HH');
                if(getTxnType.startsWith('Add'))
                {
                    var className = transactionDetails[i].resources[0].$class;
                    if(className.endsWith('Client')){
                        transactionDetails[i].submitter = transactionDetails[i].resources[0].owner.split('#')[1];
                    } else if(className.endsWith('MedRecords')){
                        transactionDetails[i].submitter = transactionDetails[i].resources[0].owner.split('#')[1];
                    } else {
                        transactionDetails[i].submitter = transactionDetails[i].resources[0].firstName;
                    }
                } else if(getTxnType.startsWith('Update'))
                {
                    var className = transactionDetails[i].resources[0].$class;
                    if(className.endsWith('Client')){
                        transactionDetails[i].submitter = transactionDetails[i].resources[0].owner.split('#')[1];
                    } else if(className.endsWith('MedRecords')){
                        transactionDetails[i].submitter = transactionDetails[i].resources[0].owner.split('#')[1];
                    } else {
                        transactionDetails[i].submitter = transactionDetails[i].resources[0].firstName;
                    }
                } else if(getTxnType.startsWith('Req')){
                    transactionDetails[i].submitter = transactionDetails[i].consentRequestedBy.split('#')[1];
                } else if(getTxnType.startsWith('Pro')){
                    transactionDetails[i].submitter = transactionDetails[i].consentProvidedBy.split('#')[1];
                } else {
                    transactionDetails[i].submitter = 'Owner';
                }
                
            }
            //uncomment here
            $scope.$apply(() => $scope.transaction=transactionDetails);
            $scope.transaction = transactionDetails;
            console.log('$scope.transaction == ',$scope.transaction);
            
        });
        // var transactionDetails={};
        // transactionDetails.$class='Participant';
        // transactionDetails.txnHash = 4;
        // transactionDetails.submitter='Owner';
        // transactionDetails.transactionId='eff017911iryegeyeyeueue7809090009ffg';
        // transactionDetails.transactionTimestamp='26-09-2017';
        // $scope.transaction.push(transactionDetails);
        // transactionDetails={};
        // transactionDetails.$class='Client';
        // transactionDetails.txnHash = 4;
        // transactionDetails.submitter='User';
        // transactionDetails.transactionId='afhaiudasdjaid039403ioiowiew8e223203';
        // transactionDetails.transactionTimestamp='26-09-2017';
        // $scope.transaction.push(transactionDetails);
        // transactionDetails={};
        // transactionDetails.$class='Participant';
        // transactionDetails.txnHash = 4;
        // transactionDetails.submitter='Requester';
        // transactionDetails.transactionId='jshdjhdjsdjndj878798dhsbdnb88u989899';
        // transactionDetails.transactionTimestamp='26-09-2017';
        // $scope.transaction.push(transactionDetails);
        // transactionDetails={};
        // transactionDetails.$class='Approver';
        // transactionDetails.txnHash = 4;
        // transactionDetails.submitter='User';
        // transactionDetails.transactionId='rtetrcndbcndsb765745674nxnxskxn89899';
        // transactionDetails.transactionTimestamp='26-09-2017';
        // $scope.transaction.push(transactionDetails);

        
        //console.log('$scope.transaction == ',$scope.transaction);

        // function getAllTransactionDetails() {
        //     // get all transaction
        //     TransactionService.getAllTransactionDetails().then(function (transactionDetails) {
        //         //vm.transaction = transactionDetails;
        //         //console.log(vm.transaction);
        //         for(var i=0; i<transactionDetails.length; i++){
        //             var getTxnType = [];
                    
        //             getTxnType=transactionDetails[i].$class.split('.')[4];
        //             if(typeof getTxnType==='undefined'){
        //                 getTxnType=transactionDetails[i].$class.split('.')[3];
        //             }
        //             transactionDetails[i].$class = getTxnType;
        //             transactionDetails[i].txnHash = transactionDetails.length;
        //             transactionDetails[i].timestamp = $filter('date')(transactionDetails[i].timestamp,'dd-MM-yyyy HH:mm:ss');
        //             //transactionDetails[i].timestampInHour = $filter('date')(transactionDetails[i].timestamp,'HH');
        //             if(getTxnType.startsWith('Add'))
        //             {
        //                 var className = transactionDetails[i].resources[0].$class;
        //                 if(className.endsWith('Client')){
        //                     transactionDetails[i].submitter = transactionDetails[i].resources[0].owner.split('#')[1];
        //                 } else if(className.endsWith('MedRecords')){
        //                     transactionDetails[i].submitter = transactionDetails[i].resources[0].owner.split('#')[1];
        //                 } else {
        //                     transactionDetails[i].submitter = transactionDetails[i].resources[0].firstName;
        //                 }
        //             } else if(getTxnType.startsWith('Update'))
        //             {
        //                 var className = transactionDetails[i].resources[0].$class;
        //                 if(className.endsWith('Client')){
        //                     transactionDetails[i].submitter = transactionDetails[i].resources[0].owner.split('#')[1];
        //                 } else if(className.endsWith('MedRecords')){
        //                     transactionDetails[i].submitter = transactionDetails[i].resources[0].owner.split('#')[1];
        //                 } else {
        //                     transactionDetails[i].submitter = transactionDetails[i].resources[0].firstName;
        //                 }
        //             } else if(getTxnType.startsWith('Req')){
        //                 transactionDetails[i].submitter = transactionDetails[i].consentRequestedBy.split('#')[1];
        //             } else if(getTxnType.startsWith('Pro')){
        //                 transactionDetails[i].submitter = transactionDetails[i].consentProvidedBy.split('#')[1];
        //             } else {
        //                 transactionDetails[i].submitter = 'Owner';
        //             }
                    
        //         }
        //         vm.transaction = transactionDetails;
        //         console.log(vm.transaction);
        //     });
        // } 
        
        // getAllTransactionDetails();
    }

})();