/**
 * Created By :- Akshay
 * Created Date :- 18-09-2017 10:00 am
 * Version :- 1.0.0
 */
var config = require('config.json');
var api = require('apiConfig.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var rp = require('request-promise');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('DocumentType');
db.bind('Document');

var service = {};

service.getAllCustInfo = getAllCustInfo;

// service. = ;


module.exports = service;

// Akshay : 14-09-2017 get all med records from blockchain
function getAllCustInfo(req, res) {
    console.log("im in bkc getAllCust info::::::::::::::::::::::::::::");
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;

    rp({
        uri:api.localhost+api.getClient,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json'
        }
    }).then(function(data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        console.log("successfully get all client data = ", data);
        deferred.resolve(data);

    });
    return deferred.promise;
}