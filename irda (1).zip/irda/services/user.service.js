﻿/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
var config = require('config.json');
var api = require('apiConfig.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var rp = require('request-promise');
var bcrypt = require('bcryptjs');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('users');

var service = {};

service.authenticate = authenticate;
service.getById = getById;
service.create = create;
service.update = update;
service.delete = _delete;

module.exports = service;

function authenticate(username, password) {
    var deferred = Q.defer();
    db.users.findOne({ username: username }, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        
        if (user && bcrypt.compareSync(password, user.hash)) {
            // authentication successful
            // console.log("user =  ",user);
            // Akshay : Add irda reg from db 
            var users = {};
            users['irdaRegNo'] = user.IRDARegistrationNumber;
            users['insOrg'] = user.insurerCompanyName;
            users['telegramToken'] = user.telegramToken;
            var user = jwt.sign({ sub: user._id ,user : user}, config.secret);
            // Akshay : send token for autharization
            users["token"] = user;
            //Akshay : send users data
            console.log(users);
            deferred.resolve(users);
        } else {
            // authentication failed
            deferred.resolve();
        }
    });

    return deferred.promise;
}

function getById(_id) {
    var deferred = Q.defer();

    db.users.findById(_id, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);

        if (user) {
            // return user (without hashed password)
            deferred.resolve(_.omit(user, 'hash'));
        } else {
            // user not found
            deferred.resolve();
        }
    });

    return deferred.promise;
}

function create(req,res) {
    var deferred = Q.defer();

    var username = req.username;
    console.log("username , ",username);
    // validation
    db.users.findOne(
        { username: username },
        function (err, user) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            if (user) {
                // username already exists
                deferred.reject('Username "' + username + '" is already taken');
            } else {
                createUser(req,res);
            }
        });

    function createUser(req,res) {
        // set user object to userParam without the cleartext password
        var userParam = req;
        var user = _.omit(userParam, 'password');

        // add hashed password to user object
        user.hash = bcrypt.hashSync(userParam.password, 10);
        // console.log("user",user);
        db.users.insert(
            user,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                // console.log("user in = ",doc);
                insurerRegister(req,res);
                deferred.resolve(doc);
        });
    }
    return deferred.promise;
}

function insurerRegister(req, res) {
    var insurer = req;
    console.log("insurer = ",insurer);
    var deferred = Q.defer();

    var body = "{" +
        "\"$class\": \"net.biz.irdaNetwork.Insurer\"," +
        "\"irdaRegNo\": \""+insurer.IRDARegistrationNumber+"\","+
        "\"firstName\": \""+insurer.firstName+"\","+
        "\"lastName\": \""+insurer.lastName+"\","+
        "\"emailId\": \""+insurer.Email+"\","+
        "\"mobileNo\": \""+insurer.MobileNumber+"\","+
        "\"userName\": \""+insurer.username+"\","+
        "\"insuranceType\": \""+insurer.insuranceType+"\","+
        "\"compIdNo\": \""+insurer.companyIdentificationNumber+"\","+
        "\"insurerOrg\": \""+insurer.insurerCompanyName+"\","+
        "\"balance\": \"200\","+
        "\"received\": \"0\","+
        "\"given\": \"0\""+
         "}";
      console.log("insurer reg body = ",body);

    rp({
        method: 'POST',
        uri: api.localhost+api.insurerRegister,
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json'
            // 'X-Access-Token': api.gitToken
        }
    }).then(function(data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        console.log("successfully reg insurer = ", data);
        deferred.resolve(data);

    });
    return deferred.promise;
}

function update(_id, userParam) {
    var deferred = Q.defer();

    // validation
    db.users.findById(_id, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);

        if (user.username !== userParam.username) {
            // username has changed so check if the new username is already taken
            db.users.findOne(
                { username: userParam.username },
                function (err, user) {
                    if (err) deferred.reject(err.name + ': ' + err.message);

                    if (user) {
                        // username already exists
                        deferred.reject('Username "' + req.body.username + '" is already taken')
                    } else {
                        updateUser();
                    }
                });
        } else {
            updateUser();
        }
    });

    function updateUser() {
        // fields to update
        var set = {
            firstName: userParam.firstName,
            lastName: userParam.lastName,
            username: userParam.username,
            Email : userParam.Email,
            MobileNumber : userParam.MobileNumber    
        };

        // update password if it was entered
        if (userParam.password) {
            set.hash = bcrypt.hashSync(userParam.password, 10);
        }

        db.users.update(
            { _id: mongo.helper.toObjectID(_id) },
            { $set: set },
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
    }

    return deferred.promise;
}

function _delete(_id) {
    var deferred = Q.defer();

    db.users.remove(
        { _id: mongo.helper.toObjectID(_id) },
        function (err) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            deferred.resolve();
        });

    return deferred.promise;
}