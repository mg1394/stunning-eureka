/**
 * Created By :- Akshay
 * Created Date :- 25-09-2017 03:30 am
 * Version :- 1.0.0
 */
var TelegramBot = require('node-telegram-bot-api');
// var TelegramBotClient = require('api-telegram-bot');
var http = require('http');
var smsConfig = require('smsconfig.json');
var urlencode = require('urlencode');
var config = require('config.json');
var api = require('apiConfig.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var mongo = require('mongoskin');
var rp = require('request-promise');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('telegram');

var service = {};

service.saveTelegramResponce = saveTelegramResponce;

module.exports = service;


////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////telegram code starts here for receiving responce /////////////////////
//////////////////////////////////////////////////////////////////////////////////////////
// function saveTelegramResponce(req, res) {
//     console.log("im in telegram function");
//     var deferred = Q.defer();
//     var apiKey = smsConfig.apiKey;
//     var username = smsConfig.username;
//     var hash = smsConfig.hash;

//     var address = "https://api.textlocal.in/get_history_single/?&apikey=&";
//     var api = address +  apiKey ;
//     console.log("api:::::::::::",api);

//     rp({
//         uri:api,
//         headers: {
//             'User-Agent': 'Request-Promise',
//             'Content-Type': 'application/json'
//         }
//     }).then(function(data) {
//         //if (err) deferred.reject(err.name + ': ' + err.message);
//         // console.log("successfully get all med data = ", data);
//         deferred.resolve(data);

//     });
//     return deferred.promise;
// }


function saveTelegramResponce(req, res) {
    console.log("im in telegram function");
    var deferred = Q.defer();

    var key = urlencode('apikey='+smsConfig.apiKey);
    console.log('key ==>',key);

        var options = {
            host: 'api.textlocal.in', path: '/get_messages?username=' + smsConfig.username+'&hash='+smsConfig.hash+'&&inbox_id='+10
            };

            callback = function (response) {
            var str = '';//another chunk of data has been recieved, so append it to `str`
            //console.log('response ==>',response);
            response.on('data', function (chunk) {
                console.log('chunk ==>',chunk);
                str += chunk;
            });//the whole response has been recieved, so we just print it out here
            response.on('end', function () {
                console.log("rece res ::::::::::;;",str);
            });
            }//console.log('hello js'))
            http.request(options, callback).end();//url encode instalation need to use $ npm install urlencode

        db.telegram.insert(
            body,
            function (err, doc) {
                // console.log("err::::::::::",err);
                if (err) deferred.reject(err.name + ': ' + err.message);
                // BKCsaveTelegram(req, res);
                deferred.resolve(doc);
        });

    return deferred.promise;
}
//////////////////////////////////////////////////////////////////////////////////////////
/////////////////////telegram code ends here for receiving responce /////////////////////
////////////////////////////////////////////////////////////////////////////////////////

function BKCsaveTelegram(req, res) {
    console.log("im in bkc function",req.body);
    var tem = req.body;

    var arr = new Array();
    arr = tem.text.split("Z");
    console.log("my arr::::::::::::: ------ ",arr);
    var deferred = Q.defer();
    var irdaRegNo = req.session.irdaRegNo;
    // var medId = req.params.medId;
    // console.log("medi params ::::::::",medId);

    var body = "{" +
        "\"$class\": \"net.biz.irdaNetwork.ProvideConsent\"," +
        "\"consentProvideTo\":\""+arr[9]+"\"," +
        "\"consentProvidedBy\": \""+arr[5]+"\","+
        "\"medId\": \""+arr[3]+"\","+
        "\"medRecOwner\": \""+arr[7]+"\","+
        "\"custConsentBySms\": \""+arr[11]+"\""+
         "}";
      console.log("get consent body = ",body);

    rp({
        method: 'POST',
        uri: api.localhost+api.provideConsent,
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json'
            // 'Authorization': 'Bearer ' + blockChainToken
        }
    }).then(function(data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        console.log("successfully send res to b = ", data);
        deferred.resolve(data);

    });
    return deferred.promise;
}
