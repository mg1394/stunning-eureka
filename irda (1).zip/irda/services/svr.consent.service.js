/**
 * Created By :- Akshay
 * Created Date :- 02-09-2017 01:00 pm
 * Version :- 1.0.0
 */
var http = require('http');
var config = require('config.json');
var smsConfig = require('smsconfig.json');
var api = require('apiConfig.json');
var TelegramApi = require('telegram.json');
var urlencode = require('urlencode');

var rp = require('request-promise');

var express = require('express');
var replace = require("replace");
var app = express();



var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('customer');
db.bind('MessageTemplate');
db.bind('users');
db.bind('SMSNotification');
db.bind('smsGateway');
db.bind('Consent');


var service = {};


service.reqConsent = reqConsent;
service.delete = _delete;
service.sendTelegram = getTelegram;

module.exports = service;

function reqConsent(req,res) {
    console.log("im in final ::::::::::::");
    var deferred = Q.defer();
    //var type = "consent";
    var id = "101";
    db.MessageTemplate.find({ templateID: id }).toArray(function(err, SMS) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        //   console.log("get all err = ",err);
        console.log("get all sms :::= ", SMS);

        var CustData = req.body;
        console.log("CustData ===",req.body.owner.toString().split("#")[1]);
        var SMSBody = SMS[0].smsBody;
        // console.log("sms body = ", SMSBody);
        var username = req.session.username;
        var first = SMSBody.replace("*****",username);
        var second = first.replace("$$$$$$",CustData.aadharNo);
        var third = second.replace("!!!!!",CustData.aadharNo);
        var owner = CustData.owner;
        var arr = owner.toString().split("#");
        //console.log("arr = ", arr[1]);
        var final = third.replace("^^^^^",arr[1]);

        var irdaRegNo =  req.session.irdaRegNo;
        var msg = req.finalSMS;
        req.finalSMS = final.replace("#####",irdaRegNo);
        console.log("temp = ", req.finalSMS);

        var body={
            mobileNo : "91"+CustData.mobileNo,
            smsBody : req.finalSMS,
            createDtTm : Date(),
            sendDtTm : "0",
            sendStatus : "0",
            AckStatus : "0"
        }
        console.log('var body==',body);
        db.SMSNotification.insert(
            body,
            function (err, doc) {
                console.log("doc::::::::::",doc);
                if (err) deferred.reject(err.name + ': ' + err.message);
                deferred.resolve(doc);
        });
        var gatewayID = "1";
        //BKCGetConsent(req,res);
        sendSMS(req,res,gatewayID);
        deferred.resolve(SMS);
    });
    return deferred.promise;
}

function BKCGetConsent(req, res) {
    console.log("im in bkc function",req.body);
    var deferred = Q.defer();
    var irdaRegNo = req.session.irdaRegNo;
    var obj = JSON.parse(req.body.medDetails[0]);
    //var keys = Object.keys(medId);
    var medId = [];
    for(var k in obj) medId.push(k);
    console.log("medi params ::::::::",medId);

    var body = "{" +
        "\"$class\": \"net.biz.irdaNetwork.RequestConsent\"," +
        "\"consentRequestedBy\":\""+irdaRegNo+"\"," +
        "\"medId\": \""+medId[0]+"\","+
        "\"client\": \""+medId[0]+"\""+
         "}";
      console.log("get consent body = ",body);

    rp({
        method: 'POST',
        uri: api.localhost+api.requestConsent,
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json'
            // 'Authorization': 'Bearer ' + blockChainToken
        }
    }).then(function(data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        console.log("successfully get consent = ", data);
        sendSMS(req,res);
        deferred.resolve(data);

    });
    return deferred.promise;
}

function sendTelegram(req, res) {
    console.log("im in bkc function");
    var smsBody =  req.finalSMS;
    var telegramToken = req.session.telegramToken;
    console.log("getting sms = ", smsBody);
    var deferred = Q.defer();
    console.log(TelegramApi.api+telegramToken+'/'+TelegramApi.sendMessage+'?'+TelegramApi.chat_id+'&'+'text='+smsBody)

    rp({
        uri:TelegramApi.api+telegramToken+'/'+TelegramApi.sendMessage+'?'+TelegramApi.chat_id+'&'+'text='+smsBody,
    }).then(function(data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        // console.log("successfully get all med data = ", data);
        deferred.resolve(data);

    });
    return deferred.promise;
}

/////////////////////////////////////////////////////////////////////
//////////////////#Akshay : - send sms ///////////////////////////
////////////////////////////////////////////////////////////////
function sendSMS(req,res,gatewayID) {
    console.log('gatewayID==',gatewayID);
    var deferred = Q.defer();
    var body =  req.finalSMS;
    console.log("getting sms = ", body);
    var msgBody = urlencode(body);
    var username = req.session.username;
    console.log("username = ",username);
    db.users.find({ username: username }).toArray(function(err, contactDetails) {
        console.log("get contact = ",contactDetails);
        var mobilleNumber = contactDetails[0].MobileNumber;
        console.log("mob num = ",'+91'+mobilleNumber);
        ////////////get Gateway deatils///////////////
        db.smsGateway.find({ gatewayID: gatewayID }).toArray(function(err, gateway) {
            console.log('gateway from db:::',gateway);
            var user = gateway[0].username
            var hash = gateway[0].hash
            var sender = gateway[0].sender
            var apiKey = gateway[0].apiKey
        
        console.log('username CHECK here==',user);
        var data = 'username=' + user + '&hash=' + hash + '&sender=' + sender + '&numbers=' + mobilleNumber + '&message=' + msgBody;
        //var data = 'apiKey=' + apiKey + '&sender=' + sender + '&numbers=' + toNumber + '&message=' + msg;
        console.log('data==',data);
        var key = urlencode('apikey='+apiKey);
        console.log('key ==>',key);

        var options = {
            host: 'api.textlocal.in', path: '/send?' + data
        };

    callback = function (response) {
    var str = '';//another chunk of data has been recieved, so append it to `str`
    //console.log('response ==>',response);
    response.on('data', function (chunk) {
        console.log('chunk ==>',chunk);
        str += chunk;
    });//the whole response has been recieved, so we just print it out here
    response.on('end', function () {
        console.log(str);//response token from msg gateway
        var set={
            sendStatus : "Yes"
        }
        if(str){
            db.SMSNotification.update( 
            { mobileNo: mobilleNumber }, 
            { $set: set }, 
            function (err, doc){
                    if(doc && !err){

                        var consent={
                            mobileNo : mobilleNumber,
                            ConsentRequestor :username,
                            ConsentFor : req.body.owner.toString().split("#")[1],
                            ConsentGiver :req.body.clientName,
                            ConsentStatus :"0",
                            BCUpdateDtTm :"0"
                        }
                        console.log('consent table data===',consent);
                        db.Consent.insert(
                        consent,
                        function (err, doc) {
                            console.log("doc::::::::::",doc);
                            if (err) deferred.reject(err.name + ': ' + err.message);
                            deferred.resolve(doc);
                    });
                    } 
                    //console.log("SMSNotification update===:",doc); 
                    if (err) deferred.reject(err.name + ': ' + err.message); 
                    deferred.resolve(); 
            });
        }
    });
    }//console.log('hello js'))
    http.request(options, callback).end();//url encode instalation need to use $ npm install urlencode

    })
    /////////////////gateway////////////////////////////
    })
    return deferred.promise;
}


function _delete(_id) {
    var deferred = Q.defer();

    db.users.remove(
        { _id: mongo.helper.toObjectID(_id) },
        function (err) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            deferred.resolve();
        });

    return deferred.promise;
}


/////////////////////////////////////////////////////////
////////Akshay : send telegram sms starts //////////////
///////////////////////////////////////////////////////
function getTelegram(req,res) {
    console.log("im in get consent svr-ser");
    var deferred = Q.defer();
    var type = "consent";
    db.MessageTemplate.find({ messageType: type }).toArray(function(err, SMS) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        //   console.log("get all err = ",err);
        // console.log("get all sms = ", SMS);
        var SMSBody = SMS[0].smsBody;
        // console.log("sms body = ", SMSBody);
        var test = req.session.username;
        req.finalSMS = SMSBody.replace("*****",test);
        // console.log("temp = ", req.finalSMS);
        sendTelegram(req,res);
        deferred.resolve(SMS);
    });
    return deferred.promise;
}

function sendTelegram(req, res) {
    // console.log("im in bkc function");
    var smsBody =  req.finalSMS;
    var telegramToken = req.session.telegramToken;
    console.log("getting sms = ", telegramToken);
    var deferred = Q.defer();
    console.log(TelegramApi.api+telegramToken+'/'+TelegramApi.sendMessage+'?'+TelegramApi.chat_id+'&'+'text='+smsBody)

    rp({
        uri:TelegramApi.api+telegramToken+'/'+TelegramApi.sendMessage+'?'+TelegramApi.chat_id+'&'+'text='+smsBody,
    }).then(function(data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        // console.log("successfully get all med data = ", data);
        deferred.resolve(data);

    });
    return deferred.promise;
}
/////////////////////////////////////////////////////////
////////Akshay : send telegram sms ends here ///////////
///////////////////////////////////////////////////////
