/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 * Updated By :- Akshay
 * Updated Date :- 18-09-2017 10:00 am
 * Version :- 1.0.1 add upload med rec
 */
var config = require('config.json');
var api = require('apiConfig.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var rp = require('request-promise');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('DocumentType');
db.bind('Document');

var service = {};


service.getAllDocumentType = getAllDocumentType;
service.getAllSaveDocuments = getAllSaveDocuments;
service.getAllSaveDocById = getAllSaveDocById;
service.getAllSaveDocumentsById = getAllSaveDocumentsById;
service.saveDocument = saveDocument;
service.deleteDocument = deleteDocument;
service.delete = _delete;

module.exports = service;


function saveDocument(req,res) {
    // console.log("final doc = ",req.body);
    var customer = req.body;
    // console.log("customer = ",customer);
    var deferred = Q.defer();

        db.Document.insert(
            customer,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                BKCSaveMedRecByAdhrId(req, res);
            });
    return deferred.promise;
}

/////////////////////////////////////////////////////////////////
//////////Akshay Save med rec (blockchain)//////////////////////
////////////////////////////////////////////////////////////////
function BKCSaveMedRecByAdhrId(req, res) {
    var deferred = Q.defer();
    var MedRec = req.body;
    var id = Date.now();
    var medId = MedRec.AadharNumber + id;
    var irdaRegNo = req.session.username;
    console.log("sess :::::",req.session.irdaRegNo);
    var body = "{" +
        "\"$class\": \"net.biz.irdaNetwork.MedRecords\","+
        "\"medId\": \""+medId+"\","+
        "\"medicalCenter\": \""+MedRec.medicalCenter+"\","+
        "\"medicalAvailable\": \"Yes\","+
        "\"medicalReportType\": \""+MedRec.DocumentType+"\","+
        "\"medicalReportName\": \""+MedRec.medicalReportName+"\","+
        "\"medicalDoneDate\": \""+MedRec.medicalDoneDate+"\","+
        "\"client\": \"resource:net.biz.irdaNetwork.Client#"+MedRec.AadharNumber+"\","+
        "\"owner\": \"resource:net.biz.irdaNetwork.Insurer#"+irdaRegNo+"\""+
        "}";
      console.log("BKCSaveMedRecByAdhrId body = ",body);

    rp({
        method: 'POST',
        uri: api.localhost+api.medRecordSave,
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json'
            // 'Authorization': 'Bearer ' + blockChainToken
        }
    }).then(function(data) {
        console.log("successfully save med records = ", data);
        BKCUploadMedRec(req, res);
        deferred.resolve(data);
    });
    return deferred.promise;
}

/////////////////////////////////////////////////////////////////
//////////Akshay upload med rec.//////////////////////
////////////////////////////////////////////////////////////////
function BKCUploadMedRec(req, res) {
    var deferred = Q.defer();
    var MedRec = req.body;
    console.log("sess :::::",req.body);
    var body = "{" +
        "\"$class\": \"net.biz.irdaNetwork.UploadMedRecords\","+
        "\"client\": \""+MedRec.AadharNumber+"\","+
        "\"medicalAvailable\": \"Yes\","+
        "\"medicalDoneDate\": \""+MedRec.medicalDoneDate+"\","+
        "\"medicalDoneAt\": \""+MedRec.medicalCenter+"\","+
        "\"medId\": \""+MedRec.AadharNumber+"\""+
        "}";
      console.log("upload  body :::::::::::: ",body);

    rp({
        method: 'POST',
        uri: api.localhost+api.uploadMedRec,
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json'
            // 'Authorization': 'Bearer ' + blockChainToken
        }
    }).then(function(data) {
        console.log("successfully upload med records = ", data);
        deferred.resolve(data);
    });
    return deferred.promise;
}
function getAllDocumentType(req,res) {
    var deferred = Q.defer();

    db.DocumentType.find().toArray(function(err, doc) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(doc);
    });
    
    return deferred.promise;
}

function getAllSaveDocuments(req,res) {
    var deferred = Q.defer();

    db.Document.find().toArray(function(err, doc) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(doc);
    });
    
    return deferred.promise;
}

function getAllSaveDocById(req,res) {
    var deferred = Q.defer();
    var medId = req.params.medId;
    console.log("my med id 7777777777",medId);
    db.Document.findOne({ AadharNumber : medId }, function (err, doc) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        // console.log(" -------------doc-----------",doc);
        deferred.resolve(doc);
    });
    
    return deferred.promise;
}

function getAllSaveDocumentsById(req,res) {
    var deferred = Q.defer();
    var _id = req.params._id;
    db.Document.find(
        { _id: mongo.helper.toObjectID(_id) }).toArray(function(err, doc) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        
        deferred.resolve(doc);
    });
    
    return deferred.promise;
}

function deleteDocument(req,res) {
    var deferred = Q.defer();
    var _id = req.body._id;
    // console.log(_id);
    db.Document.remove(
        { _id: mongo.helper.toObjectID(_id) },
        function (err) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            deferred.resolve();
        });

    return deferred.promise;
}

function _delete(_id) {
    var deferred = Q.defer();

    db.users.remove(
        { _id: mongo.helper.toObjectID(_id) },
        function (err) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            deferred.resolve();
        });

    return deferred.promise;
}