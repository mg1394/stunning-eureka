/**
 * Created By :- Madhura
 * Created Date :- 19-09-2017 11:00 am
 * Version :- 1.0.0
 */
var config = require('config.json');
var api = require('apiConfig.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var mongo = require('mongoskin');
var rp = require('request-promise');
var db = mongo.db(config.connectionString, { native_parser: true });

var service = {};

service.getAllTransactionDetails = getAllTransactionDetails;

module.exports = service;




function getAllTransactionDetails(req, res) {
    // console.log("im in bkc function");
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;

    rp({
        uri:api.localhost+api.transactions,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json'
        }
    }).then(function(data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        // console.log("successfully get all med data = ", data);
        deferred.resolve(data);

    });
    return deferred.promise;
}
