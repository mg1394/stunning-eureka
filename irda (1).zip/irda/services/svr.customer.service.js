/**
 * Created By :- Akshay
 * Created Date :- 21-08-2017 10:00 am
 * Version :- 1.0.0
 */
var config = require('config.json');
var api = require('apiConfig.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var mongo = require('mongoskin');
var rp = require('request-promise');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('customer');

var service = {};


service.save = save;
service.getAllCustomerDetails = getAllCustomerDetails;
// for db get all cust details based on id
// service.getAllCustomerDetailsById = getAllCustomerDetailsById;
// for blockcahin get all cust details based on id 
service.getAllCustomerDetailsById = BKCgetAllCusDetById;

service.delete = _delete;
// service.BKCSaveCustDetails = BKCSaveCustDetails;
// service.BKCSaveCustDetails = BKCSaveCustDetails;

module.exports = service;


function save(req,res) {
    var customer = req.body;
    var irdaRegNo = req.session.irdaRegNo;
    var insurerOrg = req.session.insOrg;    
    customer.irdaRegNo = irdaRegNo;
    customer.insurerOrg = insurerOrg;
    var deferred = Q.defer();    
        db.customer.insert(
            customer,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                BKCSaveClient(req,res);
                deferred.resolve(customer);
            });
    return deferred.promise;
}

function BKCSaveClient(req, res) {
    var deferred = Q.defer();
    var client = req.body;
    var irdaRegNo = req.session.irdaRegNo;
    var insurerOrg = req.session.insOrg;
    console.log("client:::::::::::::",client);
    var body = "{" +
        "\"$class\": \"net.biz.irdaNetwork.Client\","+
        "\"aadharNo\": \""+client.AadharNumber+"\","+
        "\"clientName\": \""+client.ClientName+"\","+
        "\"panNo\": \""+client.PANNumber+"\","+
        "\"dob\": \""+client.DOB+"\","+
        "\"mobileNo\": \""+client.MobileNumber+"\","+
        "\"emailId\": \""+client.EmailId+"\","+
        "\"medicalAvailable\": \"No\","+
        "\"owner\": \"resource:net.biz.irdaNetwork.Insurer#"+irdaRegNo+"\","+
        "\"insurerOrg\": \""+insurerOrg+"\""+
        "}";
      console.log("cust body = ",body);

    rp({
        method: 'POST',
        uri: api.localhost+api.client,
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json'
            // 'Authorization': 'Bearer ' + blockChainToken
        }
    }).then(function(data) {
        console.log("successfully save client records = ", data);
        deferred.resolve(data);
    });
    return deferred.promise;
}

// Akshay 01-09-2017 get all customer details
// function getAllCustomerDetails(req,res) {
//     var deferred = Q.defer();

//     db.customer.find().toArray(function(err, doc) {
//         if (err) deferred.reject(err.name + ': ' + err.message);
//         deferred.resolve(doc);
//     });
    
//     return deferred.promise;
// }

// Akshay : 14-09-2017 get all med records from blockchain
function getAllCustomerDetails(req, res) {
    // console.log("im in bkc function");
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;

    rp({
        uri:api.localhost+api.getClient,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json'
        }
    }).then(function(data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        // console.log("successfully get all med data = ", data);
        deferred.resolve(data);

    });
    return deferred.promise;
}

// Akshay 01-09-2017 get all customer details by id
function getAllCustomerDetailsById(req,res) {
    var deferred = Q.defer();
    var _id = req.params._id;
    db.customer.find(
        { _id: mongo.helper.toObjectID(_id) }).toArray(function(err, customer) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        // console.log(customer);
        deferred.resolve(customer);
    });
    
    return deferred.promise;
}

// Akshay : 14-09-2017 get all med records from blockchain
function BKCgetAllCusDetById(req, res) {
    var deferred = Q.defer();
    var _id = req.params._id;
    rp({
        uri:api.localhost+api.getClient+'/'+_id,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json'
        }
    }).then(function(data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        // console.log("successfully get all cust data :::::::::::::: ", data);
        deferred.resolve(data);

    });
    return deferred.promise;
}

function _delete(_id) {
    var deferred = Q.defer();

    db.users.remove(
        { _id: mongo.helper.toObjectID(_id) },
        function (err) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            deferred.resolve();
        });

    return deferred.promise;
}