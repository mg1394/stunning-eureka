/**
 * Created By :- Girijashankar Mishra
 * Created Date :- 08-05-2017 15:30 pm
 * Version :- 1.0
 */
require('controllers/login.controller.js');
var config = require('config.json');
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('Customer');

var service = {};
var ftuc =0;

service.getById = getById;
service.getAll = getAll;
service.create = create;
service.update = update;
service.delete = _delete;
service.getAll = getAll;

module.exports = service;


function getById(_id) {
    var deferred = Q.defer();
    db.Customer.findById(_id, function (err, customer) {
        if (err) deferred.reject(err.name + ': ' + err.message);

        if (customer) {
            // return user (without hashed password)
            deferred.resolve(_.omit(customer, 'hash'));
        } else {
            // user not found
            deferred.resolve();
        }
    });

    return deferred.promise;
}

function create(customer) {
    var deferred = Q.defer();
    /*function createCustomer() {*/

        db.Customer.insert(
            customer,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
  /*  }*/

    return deferred.promise;
}

function update(_id, userParam) {
    var deferred = Q.defer();

    // validation
    db.Customer.findById(_id, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateCustomer();

    });

    function updateCustomer() {
        // fields to update
        var set = {
            customername  : userParam.customername,
            email: userParam.email,
            accountno: userParam.accountno,
            phoneno: userParam.phoneno,
            panno: userParam.panno
        };


        db.Customer.update(
            { _id: mongo.helper.toObjectID(_id) },
            { $set: set },
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
    }

    return deferred.promise;
}

function _delete(_id, userParam) {
    var deferred = Q.defer();
    db.Customer.remove(
        { _id: mongo.helper.toObjectID(_id) },
        function (err) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            deferred.resolve();
        });

    return deferred.promise;
}


function getAll() {
  var deferred = Q.defer();

  db.Customer.find().toArray(function (err, cust) {
    if (err) deferred.reject(err.name + ': ' + err.message);
    deferred.resolve(cust);
  });

  return deferred.promise;
}
