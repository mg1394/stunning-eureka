/**
 * Created By :- Girijashankar Mishra
 * Created Date :- 08-05-2017 16:30 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('CustomerService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetCurrent = GetCurrent;
        service.GetAll = GetAll;
        service.GetById = GetById;
        service.GetByCustname = GetByCustname;
        service.Create = Create;
        service.Update = Update;
        service.Delete = Delete;

        return service;

        function GetCurrent() {
            return $http.get('/api/customers/current').then(handleSuccess, handleError);
        }

        function GetAll() {
            return $http.get('/api/customers/all').then(handleSuccess, handleError);
        }

        function GetById(_id) {
            return $http.get('/api/customers/' + _id).then(handleSuccess, handleError);
        }

        function GetByCustname(customername) {
            return $http.get('/api/customers/' + customername).then(handleSuccess, handleError);
        }

        function Create(customer) {
          console.log("customer = ",customer);
            return $http.post('/api/customers/create', customer).then(handleSuccess, handleError);
        }

        function Update(customer) {
            return $http.put('/api/customers/' + customer._id, customer).then(handleSuccess, handleError);
        }

        function Delete(customer) {
          console.log("_id = ",customer._id);
            return $http.delete('/api/customers/' + customer._id).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
