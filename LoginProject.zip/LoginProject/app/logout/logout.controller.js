/**
 * Created By :- Girijashankar Mishra
 * Created Date :- 08-05-2017 10:30 am
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('Logout.LogoutController', Controller);

    function Controller($window, UserService, FlashService) {
        var vm = this;

        vm.user = null;
        vm.saveUser = saveUser;
        console.log("Inside Logout Controller");

        var userDet = {};

        //Get the details on load of controller
        function initController() {
            // get current user
            UserService.GetCurrent().then(function (user) {
                userDet = user;

                userDet.logout_time = new Date().toLocaleString();
                vm.user = userDet;
                console.log("Logout Time : ",user);
                console.log("vm.user Current = ",vm.user);
                saveUser();
            });
        }

        initController();

        //Save the details and logout of the system
        function saveUser() {

            UserService.Logouttime(vm.user)
                .then(function () {
                    $window.location = '/login';
                    FlashService.Success('Logged Out Successfully');
                })
                .catch(function (error) {
                    FlashService.Error(error);
                });
        }


    }

})();
