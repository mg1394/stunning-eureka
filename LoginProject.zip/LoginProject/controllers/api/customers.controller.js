/**
 * Created By :- Girijashankar Mishra
 * Created Date :- 08-05-2017 15:45 pm
 * Version :- 1.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var custService = require('services/customer.service');

// routes
router.post('/create', createCustomer);
router.get('/current', getCurrentCustomer);
router.put('/:_id', updateCustomer);
router.delete('/:_id', deleteCustomer);
router.get('/all', getAll);
module.exports = router;


function createCustomer(req, res) {
    custService.create(req.body)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getCurrentCustomer(req, res) {
    custService.getById(req.body._id)
        .then(function (customer) {
            if (customer) {
                res.send(customer);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function updateCustomer(req, res) {
    var custId = req.body._id;

    custService.update(custId, req.body)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function deleteCustomer(req, res) {
    var custId = req.url;
    custId = custId.replace("/", "")
    custService.delete(custId)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getAll(req,res) {
  custService.getAll()
    .then(function (cust) {
      //console.log('The customers are ' + cust[0]);
      res.send(cust)
    })
    .catch(function (err) {
      res.status(400).send(err);
    });
}
