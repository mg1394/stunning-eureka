var express = require('express'),
    app = express(),
    twilio = require('twilio');
var request = require('request');
var urlencode = require('urlencode');
 
var port = (process.env.VCAP_APP_PORT || 3000);


//mvaayooapi

var receipient_no = '9702368970';
var msgBody = 'Helloooooooooooooooo';
var apiKey ="apikey=" + urlencode.parse('VqXxKjjUlLI-Ruhi03aP2Y3HTqybNGBAILJV6qXoqY', {charset: 'UTF-8'});
console.log('apiKey==',apiKey);

/*request("http://api.mvaayoo.com/mvaayooapi/MessageCompose?user=madhura@cateina.com:Abc123@@&senderID=TEST%20SMS&receipientno="+receipient_no+"&dcs=0&msgtxt="+msgBody+"&state=4", function(err, res, body){
		console.log('body==',body);
});*/

/*request("http://api.mVaayoo.com/mvaayooapi/MessageReply?user=madhura@cateina.com:Abc123@@&senderID=TEST SMS&receipientno=919702368970&sdtime=start time&edtime=end time ", function(err, res, body){
		console.log('body==',body);
});*/

request("https://api.textlocal.in/get_inboxes/?"+ "VqXxKjjUlLI-Ruhi03aP2Y3HTqybNGBAILJV6qXoqY", function(err , res , body){
		console.log('body==',body);
})

app.get('/message', function (req, res) {
	//var client = new twilio.RestClient('ACf97a290c33c2107fb3b1e4317aef0266', 'cbb0d86f36af3697403c755cc1802dee');
	var client = require('twilio')('ACf97a290c33c2107fb3b1e4317aef0266', 'cbb0d86f36af3697403c755cc1802dee');
	
	client.messages.create({
        to:'+919819775480',
        from:'+14125047607',
        body:'Brooooooklllllynnnn sms from app hosted!'
        }, function(err, message) {
        res.send('Message sent! ID: '+message.sid);
        });
});

//response to YES/NO
app.post('/sms', (req, res) => {
  var twiml = new MessagingResponse();

  twiml.message('The Robots are coming! Head for the hills!');

  res.writeHead(200, {'Content-Type': 'text/xml'});
  res.end(twiml.toString());
});

 
var server = app.listen(port, function () {
  console.log('Example app started')
});
