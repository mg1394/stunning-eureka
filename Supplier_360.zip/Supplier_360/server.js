﻿require('rootpath')();
var express = require('express');
var app = express();

var session = require('express-session');
var bodyParser = require('body-parser');
var expressJwt = require('express-jwt');
var config = require('config.json');

// var storage = multer.diskStorage({
//   /*destination: './uploads/',
//   filename: function (req, file, cb) {
//     cb(null, req.body.projectId+'/'+req.body.milestoneId+'/' +file.originalname.replace(path.extname(file.originalname), "") + '-' + Date.now() + path.extname(file.originalname))
//   }*/
//   destination: function (req, file, cb) {
//     var dir = './uploads/' + req.query.projectId + '/' + req.query.milestoneId + '/';
//     mkdirp(dir, function(err) {
//         if(err) {
//             console.error(err);
//         }
//         // move cb to here
//         cb(null, dir);
//     });

//     console.log("Upload: saved to " + dir + file.originalname);
//   },
//   filename: function (req, file, cb) {
//     cb(null, file.originalname);
//   }

// })

// var upload = multer({ storage: storage });

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(session({ secret: config.secret, resave: false, saveUninitialized: true }));

// use JWT auth to secure the api
app.use('/api', expressJwt({ secret: config.secret }).unless({ path: ['/api/users/authenticate', '/api/users/register'] }));

// routes
app.use('/login', require('./controllers/login.controller'));
app.use('/register', require('./controllers/register.controller'));
app.use('/app', require('./controllers/app.controller'));
app.use('/api/users', require('./controllers/api/users.controller'));
app.use('/api/getData', require('./controllers/api/getData.controller'));
app.use('/api/fileUpload', require('./controllers/api/fileUpload.controller'));
app.use('/uploadedDoc', express.static(__dirname+'/uploads'));


// make '/app' default route
app.get('/', function (req, res) {
    return res.redirect('/app');
});

// app.post('/savedata', upload.single('file'), function(req,res,next){
//     console.log('Upload Successful req.file = ', req);
//     console.log('Upload Successful req.body = ', req.body);

//     var hash1 = md5(req.file);
   
//     console.log('md5=',hash1);
//     saltHashPassword(hash1);
//     //console.log('sha1=',hash2);
//     //console.log('sha256=',hash3);
//     return res.send(hash1);
// });

// start server
var server = app.listen(3000, function () {
    console.log('Server listening at http://' + server.address().address + ':' + server.address().port);
});