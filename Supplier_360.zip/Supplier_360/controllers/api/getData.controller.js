var config = require('config.json');
var express = require('express');
var router = express.Router();
var getDataService = require('services/getData.service');



// routes
router.get('/', getData);
router.post('/setData', setData);
router.get('/user_Name', user_Name);
router.get('/getAllDocuments', getAllDocuments);

module.exports = router;

function getData(req, res) {
	// console.log("HI");
    getDataService.getData()
        .then(function (user) {
          // console.log(user);
             res.send(user);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function user_Name(req, res) {
    // console.log("HI user_Name");
    // getDataService.user_Name()
    //     .then(function (userName) {
    //       // console.log("userName:", req.session.username);
    //          res.send(req.session.username);
    //     })
    //     .catch(function (err) {
    //         res.status(400).send(err);
    //     });
    res.send(req.session.username);
}

function getAllDocuments(req, res) {
    console.log("getAllDocuments1");
    getDataService.getAllDocuments()
        .then(function (documents) {
          console.log("getAllDocuments2");
             res.send(documents);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


function setData(req, res) {
	// console.log("HI",req.body);
    getDataService.setData(req, res)
        .then(function () {
             res.send(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function uploadFile(req, res) {
	// console.log("HI, inside controller for file",req.body);
    getDataService.uploadFile(req, res)
        .then(function (user) {
             res.send(user);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}