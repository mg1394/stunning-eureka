var md5 = require('md5');
var hashFiles = require('hash-files');
var md5File = require('md5-file')
var sha1 = require('js-sha1');
var sha256 = require('js-sha256');
var crypto = require('crypto');
var path = require('path');
var multer  = require('multer');
var express = require('express');
var router = express.Router();
var mkdirp = require('mkdirp');

var app = express();
var fileUploadService = require('services/fileUpload.service');

// var filepreview = require('filepreview');
// var FilePreviews = require('filepreviews');
// var unoconv = require('unoconv');
// var topdf = require('topdf');
// var PDFKit = require('pdfkitjs');



var storage = multer.diskStorage({

  destination: function (req, file, cb) {
    // console.log("this is cb" ,cb);
    var dir = './uploads/'+'contractUpload'+'/'+req.session.username+'/';
    console.log(dir);
    mkdirp(dir, function(err) {
        if(err) {
            console.error(err);
        }
        // move cb to here
        cb(null, dir);
    });

    console.log("Upload: saved to " + dir + file.originalname);
  },
  filename: function (req, file, cb) {
    cb(null, file.originalname);
  }

})

var upload = multer({ storage: storage });

router.post('/saveFile/:id',upload.single('file'),saveFile);

module.exports = router;

function saveFile(req, res) {
    console.log("welfjnsfinweifniefn");

    

    console.log("HI, inside controller for file",req.file);
    console.log("IDIDIDIDIDID   :",req.params.id);
    // var hash = md5(req.file);
    // var hashs = sha1(req.file);
    var hash = md5File.sync(req.file.path);
    
    console.log("file hash",hash);
    req.hash = hash;
    // console.log("generated hash = ",req.hash);

    saltHashPassword(req, res);

     fileUploadService.contractUpload(req, res)
        .then(function (user) {
          // console.log(user);
             res.send(200).send(user);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
    // return res.send(res);
}

var genRandomString = function(length){
    return crypto.randomBytes(Math.ceil(length/2))
            .toString('hex') /** convert to hexadecimal format */
            .slice(0,length);   /** return required number of characters */
};
var sha512 = function(password, salt){
    // console.log("password", password);
    console.log("password", salt);
    var hash = crypto.createHmac('sha512', salt); /** Hashing algorithm sha512 */
    
    hash.update(password);
    console.log(" hash.update(password)", hash.update(password));
    var value = hash.digest('hex');
    console.log("crypto hash", value);
    return {
        salt:salt,
        passwordHash:value
    };
};
function saltHashPassword(req, res) {
    var userpassword = req.hash;
    var salt = genRandomString(16); /** Gives us salt of length 16 */
    var passwordData = sha512(userpassword, salt);
    // console.log('UserPassword = '+userpassword);
    // console.log('Passwordhash = '+passwordData.passwordHash);
    // console.log('nSalt = '+passwordData.salt);
    return res.send(200);
    
}