-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2015 at 06:00 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gym`
--

-- --------------------------------------------------------

--
-- Table structure for table `equipments`
--

CREATE TABLE IF NOT EXISTS `equipments` (
`equi_id` int(11) NOT NULL,
  `equi_name` varchar(50) DEFAULT NULL,
  `eq_type` varchar(50) DEFAULT NULL,
  `eq_ty_id` int(11) DEFAULT NULL,
  `equi_descp` text,
  `equi_img` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipments`
--

INSERT INTO `equipments` (`equi_id`, `equi_name`, `eq_type`, `eq_ty_id`, `equi_descp`, `equi_img`) VALUES
(1, 'Chest Bar', 'Chest', 1, 'The bench press(Chest Bar) is an upper body strength training exercise that consists of pressing a weight upwards from a supine position. The exercise works the pectoralis major as well as supporting chest, arm, and shoulder muscles like the anterior deltoids, serratus anterior, coracobrachialis, scapulae fixers, trapezii, and the triceps. A barbell is generally used to hold the weight, but a pair of dumbbells can also be used.', 'EQUIimg/28-06chest_bar.jpg'),
(2, 'Chest Fly Machine ', 'Chest', 1, 'A machine fly, alternatively called a seated lever fly or "Pec Dec" fly is a strength training exercise based on the free weight chest fly. As with the chest fly, the hand and arm move through an arc while the elbow is kept at a constant angle. Flyes are used to work the muscles of the upper body, primarily the sternal head of the pectoralis major. Because these exercises use the arms as levers at their longest possible length, the amount of weight that can be moved is significantly less than equivalent press exercises for the same muscles (the military press and bench press for the shoulder and chest respectively).', 'EQUIimg/28-06chest_fly_machine.jpg'),
(3, 'Incline/Decline', 'Chest', 1, 'The machine incline bench press is an exercise that focuses upon the upper portion of the pectoral muscles and The machine decline bench press exercise works the lower portion of the pectoral muscles.So is preferred by most people as it offers more stability for people new to the exercise.', 'EQUIimg/28-06chest_incline_decline_machine.jpg'),
(4, 'Chest Press Machine', 'Chest', 1, ' Is used for building strength in the pectoral and arm muscles. The exercise involves extending the arms in front of the body by pushing against the two levers, which have an independent action. Resistance is provided by a weight stack which enables the workload to be adjusted to suit each type of user. ', 'EQUIimg/28-06chest_press_machine.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `equi_master`
--

CREATE TABLE IF NOT EXISTS `equi_master` (
`eq_ty_id` int(11) NOT NULL,
  `eq_type` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equi_master`
--

INSERT INTO `equi_master` (`eq_ty_id`, `eq_type`) VALUES
(1, 'Chest'),
(2, 'Back'),
(3, 'Shoulder'),
(4, 'Biceps'),
(5, 'Triceps'),
(6, 'Legs'),
(7, 'Cardio'),
(8, 'Other');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE IF NOT EXISTS `slider` (
`img_id` int(11) NOT NULL,
  `slide_img` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`img_id`, `slide_img`) VALUES
(1, 'Slider Images/28-06ban1.jpg'),
(2, 'Slider Images/28-06ban2.jpg'),
(3, 'Slider Images/28-06ban3.jpg'),
(4, 'Slider Images/28-06ban4.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `trainers`
--

CREATE TABLE IF NOT EXISTS `trainers` (
`train_id` int(11) NOT NULL,
  `train_name` varchar(50) DEFAULT NULL,
  `tr_type` varchar(50) DEFAULT NULL,
  `tr_ty_id` int(11) DEFAULT NULL,
  `train_descp` text,
  `train_img` varchar(100) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trainers`
--

INSERT INTO `trainers` (`train_id`, `train_name`, `tr_type`, `tr_ty_id`, `train_descp`, `train_img`) VALUES
(1, 'amol', 'Weight gain', 1, 'dwqd wqwqwqdwqd w ', 'TRAINimg/25-06002.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `train_master`
--

CREATE TABLE IF NOT EXISTS `train_master` (
`tr_ty_id` int(11) NOT NULL,
  `tr_type` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `train_master`
--

INSERT INTO `train_master` (`tr_ty_id`, `tr_type`) VALUES
(1, 'Weight gain'),
(2, 'Weight loss'),
(3, 'Professional Body-Building');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `equipments`
--
ALTER TABLE `equipments`
 ADD PRIMARY KEY (`equi_id`), ADD KEY `eq_type` (`eq_type`), ADD KEY `eq_ty_id` (`eq_ty_id`);

--
-- Indexes for table `equi_master`
--
ALTER TABLE `equi_master`
 ADD PRIMARY KEY (`eq_type`), ADD UNIQUE KEY `eq_ty_id` (`eq_ty_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
 ADD PRIMARY KEY (`slide_img`), ADD UNIQUE KEY `img_id` (`img_id`);

--
-- Indexes for table `trainers`
--
ALTER TABLE `trainers`
 ADD PRIMARY KEY (`train_id`), ADD KEY `tr_type` (`tr_type`), ADD KEY `tr_ty_id` (`tr_ty_id`);

--
-- Indexes for table `train_master`
--
ALTER TABLE `train_master`
 ADD PRIMARY KEY (`tr_type`), ADD UNIQUE KEY `tr_ty_id` (`tr_ty_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `equipments`
--
ALTER TABLE `equipments`
MODIFY `equi_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `equi_master`
--
ALTER TABLE `equi_master`
MODIFY `eq_ty_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `trainers`
--
ALTER TABLE `trainers`
MODIFY `train_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `train_master`
--
ALTER TABLE `train_master`
MODIFY `tr_ty_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `equipments`
--
ALTER TABLE `equipments`
ADD CONSTRAINT `equipments_ibfk_1` FOREIGN KEY (`eq_type`) REFERENCES `equi_master` (`eq_type`),
ADD CONSTRAINT `equipments_ibfk_2` FOREIGN KEY (`eq_ty_id`) REFERENCES `equi_master` (`eq_ty_id`);

--
-- Constraints for table `trainers`
--
ALTER TABLE `trainers`
ADD CONSTRAINT `trainers_ibfk_1` FOREIGN KEY (`tr_type`) REFERENCES `train_master` (`tr_type`),
ADD CONSTRAINT `trainers_ibfk_2` FOREIGN KEY (`tr_ty_id`) REFERENCES `train_master` (`tr_ty_id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
