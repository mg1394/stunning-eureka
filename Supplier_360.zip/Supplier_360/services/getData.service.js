var config = require('config.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('users');
db.bind('contracts');
db.bind('filedata');
db.bind('fileUpload');


var service = {};

service.getData = getData;
service.getAllDocuments = getAllDocuments;
service.setData = setData;
service.uploadFile = uploadFile;


module.exports = service;

function getData() {
	// console.log("H13");
    var deferred = Q.defer();

    db.contracts.find().toArray(function (err, user) {
    	// console.log("Data in getData.service.js"+user);
    		deferred.resolve(user);
    	});
    return deferred.promise;
    }

function getAllDocuments() {
    // console.log("H13");
    var deferred = Q.defer();

    db.fileUpload.find().toArray(function (err, documents) {
        // console.log("Data in getData.service.js"+user);
            deferred.resolve(documents);
        });
    return deferred.promise;
    }

function setData(req,res) {
	// console.log("HI",req.body);

    var deferred = Q.defer();
    var contracts= req.body;
db.contracts.insert(
            contracts,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
 return deferred.promise;
    }


function uploadFile(req,res) {
	// console.log("HI, inside service for file",req.body);

    var deferred = Q.defer();
    var filedata= req.body;
db.filedata.insert(
            filedata,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
 return deferred.promise;
    }