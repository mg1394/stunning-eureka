var config = require('config.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
var crypto = require('crypto');
var path = require('path');


db.bind('fileUpload');



var service = {};

service.contractUpload = contractUpload;


module.exports = service;

function contractUpload(req,res) {
     // console.log('hash = '+req.hash);
    // console.log("HI, inside fileUpload service for file",req);

    var deferred = Q.defer();
    var hash = req.hash;
    var fileName = req.file.filename;
    var contrctID = req.params.id;
    // console.log(contrctID);
    var fileUpload= {hash:hash, filename:fileName, contractID:contrctID};
    // console.log("hash for db", fileUpload);
    db.fileUpload.insert(
            fileUpload,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                console.log("Error:",err);
                console.log("Doc:",doc);

                deferred.resolve();
            });
 return deferred.promise;
    }