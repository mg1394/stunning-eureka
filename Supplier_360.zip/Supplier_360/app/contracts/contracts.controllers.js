(function () {
    'use strict';

    angular
        .module('app')
        .controller('Contracts.IndexController', Controller);

    function Controller(UserService,GetData,$scope,FileUpload,$filter,Upload) {
        var vm = this;

        vm.user = null;
        vm.min = 0;
        vm.hr = 0;
        vm.sec = 0;
        $scope.contracts = {};

        // vm.Date = Date();

        // console.log(vm.Date);
        // console.log(Date.now());
        // console.log(vm.Date);

       // console.log("in contracts");

       // $scope.contracts.Date = "01-Sep-2017";
       // console.log($filter('date')(Date.now(), 'yyyy-MM-dd'));
        $scope.contracts.currentDate = $filter('date')(Date.now(), 'yyyy-MM-dd');


        $(document).on('mouseover', '.panel-heading span.clickable', function(e){
            var $this = $(this);
          if(!$this.hasClass('panel-collapsed')) {
            $this.parents('.panel').find('.panel-body').slideUp();
            $this.addClass('panel-collapsed');
            $this.find('i').removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down');
          } else {
            $this.parents('.panel').find('.panel-body').slideDown();
            $this.removeClass('panel-collapsed');
            $this.find('i').removeClass('glyphicon-chevron-down').addClass('glyphicon-chevron-up');
          }
        })


        function initController() {
            // get current user
            UserService.GetCurrent().then(function (user) {
                vm.user = user;
            });
        }

        

        $scope.sort = function(keyname){
            $scope.sortBy = keyname;   //set the sortBy to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        }

        function getData() {
            // get current user
            GetData.getAll().then(function (contracts) {
                // console.log("Data in contracts.controllers.js"+JSON.stringify(contracts));
                // console.log(contracts.EndDate);
                vm.contracts = contracts;

            });
        }


        function getAllDocuments() {
            // get current user
            // console.log("in getAllDocuments");
            GetData.getAllDocuments().then(function (documents) {
                // console.log("Data in contracts.controllers.js"+JSON.stringify(documents));
                vm.documents = documents;
            });
        }

        vm.setData = function (contracts) {
            // get current user
           
             // console.log("in setData"+contracts);

            
            GetData.setData(contracts).then(function (res) {
                alert("Contract saved.");
                window.location.reload();
                // console.log("Response"+res);
                // vm.contracts = res;
            });

            document.getElementById("contractOverview-form").reset();
        }

        vm.uploadFile = function(myFile){
                    
          document.getElementById('validateContractID').classList.remove('hide');
           vm.file = myFile; 
           vm.upload();
        }


        vm.contractUpload = function(doc){
            // console.log("inside contractUpload");
            // console.log(doc.ContractID);
             
             var id = doc.ContractID;
             // console.log(vm.file);

            if(vm.file === undefined){
                alert("Select a file");
            }else{
                console.log(vm.file);
                FileUpload.uploadFileToUrl(vm.file,id).then(function (response) {
                    alert("File uploaded.");
                    window.location.reload();
                    document.getElementById('openContracts').classList.remove('active');
                    document.getElementById('uploadContracts').classList.add('active');
                    // $("#indicatorContainerWrap").load(window.location.href+ " #indicatorContainerWrap");
            });
            }            
        }

        vm.checkDate= function(){
            // console.log(value);
            var startDate = document.getElementById('startDate').value;
            console.log(startDate);
            document.getElementById('endDate').setAttribute("min",startDate);
            // console.log("nextDay:",nextDay);
        }

        vm.currentDate= function(){
            // console.log("Hi");
            var today =  new Date();
            console.log(today);
            var date = today.getDate();
            // console.log(date);
            // document.getElementById("currentDate").disabled = true;
        }

        $(document).ready(function () {
            if (!PDFJS.workerSrc && typeof document !== 'undefined') {
                  // workerSrc is not set -- using last script url to define default location

                  PDFJS.workerSrc = (function () {
                    'use strict';
                    var scriptTagContainer = document.body ||
                                             document.getElementsByTagName('head')[0];
                    var pdfjsSrc = scriptTagContainer.lastChild.src;
                    return pdfjsSrc && pdfjsSrc.replace(/\.js$/i, '.worker.js');
                  })();

                  PDFJS.workerSrc = 'pdfjs-dist-master/build/pdf.worker.js';
                }

            vm.upload = function () {
              // console.log(this.file);
                if (this.file) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        showInCanvas(e.target.result);
                    }
                    reader.readAsDataURL(this.file);
                }
            };

            function convertDataURIToBinary(dataURI) {
                var BASE64_MARKER = ';base64,';
                var base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
                var base64 = dataURI.substring(base64Index);
                var raw = window.atob(base64);
                var rawLength = raw.length;
                var array = new Uint8Array(new ArrayBuffer(rawLength));

                for (var i = 0; i < rawLength; i++) {
                    array[i] = raw.charCodeAt(i);
                }
                return array;
            }

            function showInCanvas(url) {
                // See README for overview
                'use strict';
                // Fetch the PDF document from the URL using promises
                // console.log("inside upload");
                var pdfAsArray = convertDataURIToBinary(url);
                PDFJS.getDocument(pdfAsArray).then(function (pdf) {
                    // Using promise to fetch the page
                    // console.log("pdf:",pdf);
                    pdf.getPage(1).then(function (page) {
                        var scale = 0.75;
                        var viewport = page.getViewport(scale);
                        // Prepare canvas using PDF page dimensions
                        var canvas = document.getElementById('the-canvas');
                        var context = canvas.getContext('2d');
                        canvas.height = viewport.height;
                        canvas.width = viewport.width;
                        // Render PDF page into canvas context
                        var renderContext = {
                            canvasContext: context,
                            viewport: viewport
                        };
                        page.render(renderContext);
                    });
                });
            }
        });

        function getUserName() {
            // get current user
            // console.log("username function");
            GetData.user_Name().then(function (userName) {
                // console.log(contracts.EndDate);
                vm.userName = userName;
                // console.log(vm.userName)
            });
        }

        function timer() {

            var sec = 0;
            var min = 1;
            var hr = 1;

            setInterval(function()
                { 
                    vm.sec = sec++;
                    // console.log(vm.sec);
                    if (sec % 60 == 0) {
                        // console.log(min)
                        vm.min = min++;
                        if (min % 60 == 0) {
                            vm.hr = hr++;
                        }
                    } 
                }, 1000);
            // get current user
            // console.log("username function");
            // GetData.user_Name().then(function (userName) {
            //     // console.log(contracts.EndDate);
            //     vm.userName = userName;
                // console.log(vm.userName)
        }

// setData();
        timer();
        getUserName();
        getData();
        getAllDocuments();
         initController();

     }
    

})();