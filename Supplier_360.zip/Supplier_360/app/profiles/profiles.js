(function () {
    'use strict';

    angular
        .module('app')
        .controller('profiles.IndexController', Controller);

    function Controller(UserService,GetData) {
        var vm = this;

        vm.user = null;
// console.log("hi gokul");      

        function initController() {
            // get current user
            // UserService.GetCurrent().then(function (user) {
            //     vm.user = user;
            // });
        }

        

        // getData();
         initController();
    }

})();