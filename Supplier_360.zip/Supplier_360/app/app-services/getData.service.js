(function () {
    'use strict';

    angular
        .module('app')
        .factory('GetData', Service);

    function Service($http, $q) {
        var service = {};

        // service.GetCurrent = GetCurrent;
        service.getAll = getAll;
        service.setData=setData;
        service.uploadFile=uploadFile;
        service.uploadFileToUrl = uploadFileToUrl;
        service.getAllDocuments = getAllDocuments;
        service.user_Name = user_Name;
        // service.GetById = GetById;
        // service.GetByUsername = GetByUsername;
        // service.Create = Create;
        // service.Update = Update;
        // service.Delete = Delete;

        return service;

       
        function getAll() {
            // console.log("HI");
            return $http.get('/api/getData').then(handleSuccess, handleError);

        }

        function user_Name() {
            // console.log("HI username function");
            return $http.get('/api/getData/user_Name/').then(handleSuccess, handleError);

        }

        function getAllDocuments() {
            console.log("getAllDocuments");
            return $http.get('/api/getData/getAllDocuments/').then(handleSuccess, handleError);

        }

        function setData(contracts) {
            // console.log("setDataCalled",contracts);
            return $http.post('/api/getData/setData/',contracts).then(handleSuccess, handleError);

        }

        function uploadFile() {
            // console.log("uploadFile Called");
            return $http.post('/api/getData/uploadFile/').then(handleSuccess, handleError);

        }

        function uploadFileToUrl(file,uploadUrl){
          var fd = new FormData();
          fd.append('file', file);
          // var paramData = {'milestoneId': milestoneId, 'projectId': projectId };


              return     $http.post(uploadUrl, fd, {
                      transformRequest: angular.identity,
                      headers: {'Content-Type': undefined},
                      // params: paramData
                   }).success(function(hash){
                     console.log('api service hash = ',hash);
                     return hash;
                   }).error(function(error){
                     console.log('api service error = ',error);
                      return error;
                   });
                   /*return $http.get(uploadUrl, fd, {
                           transformRequest: angular.identity,
                           headers: {'Content-Type': undefined}
                        }).then(handleSuccess, handleError);*/
        }

        

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
