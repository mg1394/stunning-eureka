/**
 * Created By :- Gokul
 * Created Date :- 23-08-2017 03:05 pm
 * Version :- 1.0.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('FileUpload', Service);

    function Service($http, $q) {

        var service = {};


        service.uploadFileToUrl = uploadFileToUrl;

        return service;

        function uploadFileToUrl(file,id){
          console.log("inside services ",file);
          var fd = new FormData();
          fd.append('file', file);
          console.log("file:",file)
              return     $http.post('/api/fileUpload/saveFile/'+id, fd, {
                      transformRequest: angular.identity,
                      headers: {'Content-Type': undefined},
                      params: 'paramData'
                   }).then(handleSuccess, handleError);
              // console.log("fd:",fd)
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
