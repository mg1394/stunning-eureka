﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('Home.IndexController', Controller);

    function Controller(UserService,GetData) {
        var vm = this;

        vm.user = null;
// console.log("hi gokul1");
1       

        function initController() {
            // get current user
            UserService.GetCurrent().then(function (user) {
                vm.user = user;
            });
        }

        

        // getData();
         initController();
    }

})();