/**
 * Created By :- Akshay
 * Created Date :- 25-07-2017 02:00 pm
 * Version :- 1.0.0 get single project data based on projectId
*/
require('rootpath')();
var express = require('express');
var app = express();
var config = require('config.json');
var Join = require('mongo-join').Join;
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var mongodb = require('mongodb');
var Db = mongodb.Db;
var Server = mongodb.Server;
var random = require("random-js")(); // uses the nativeMath engine
var rp = require('request-promise');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('Project');
var service = {};
var ftuc =0;
var MJ = require("mongo-fast-join"),
    mongoJoin = new MJ();

//Akshay :- 25-07-2017 search by bkcprojectId  and get single project , milestone , activity
app.get('/project/:projectId', function (req, res) {
    var projectId = req.params.projectId;
    console.log("projectId in db service = ",projectId);
    var deferred = Q.defer();

 mongoJoin
    .query(
      //say we have sales records and we store all the products for sale in a different collection
      db.collection("Project"),
        {projectId:projectId}, //query statement
        {}, //fields
        {
            //limit: 1//options
        }
    )
    .join({
        joinCollection: db.collection("ProjectMilestone"),
        //respects the dot notation, multiple keys can be specified in this array
        leftKeys: ["projectId"],
        //This is the key of the document in the right hand document
        rightKeys: ["projectId"],
        //This is the new subdocument that will be added to the result document
        newKey: "milestone"
    })
    .join({
        //say that we want to get the users that commented too
        joinCollection: db.collection("ProjectActivity"),
        //This is cool, you can join on the new documents you add to the source document
        leftKeys: ["milestone.milestoneId"],//This field accepts many keys, which amounts to a composite key
        rightKeys: ["milestoneId"],
        //unfortunately, as of now, you can only add subdocuments at the root level, not to arrays of subdocuments
        newKey: "activity"//The upside is that this serve the majority of cases
    })
    //Call exec to run the compiled query and catch any errors and results, in the callback
    .exec(function (err, project) {
        //console.log(JSON.stringify(project));
        var projectDet = {};
        var allProjectDet = [];
        for(var i = 0; i<project.length;i++){
            //console.log(JSON.stringify(project));
            projectDet["projectId"]=project[i].projectId;
            projectDet["projectName"]=project[i].projectName;
            projectDet["fundGoal"]=project[i].fundGoal;
            projectDet["currency"]=project[i].currency;
            projectDet["projectType"]=project[i].projectType;
            projectDet["description"]=project[i].description;
            projectDet["projectOwner"]=project[i].projectOwner;
            projectDet["status"]=project[i].status;
            projectDet["docType"]="project";
            projectDet["startDate"]=project[i].startDate;
            projectDet["endDate"]=project[i].endDate;
            var milestone = project[i].milestone;
            var activity = project[i].activity;
            //console.log('milestone.length = ',project[i].milestone);
            //console.log('activity.length = ',project[i].activity);
            var milestoneLength = milestone.length;
            if(typeof milestoneLength == 'undefined'){
                milestoneLength = Object.keys(milestone).length;
                if(milestoneLength > 0){
                    milestoneLength = 1;
                }
            }

            var activityLength = activity.length;
            if(typeof activityLength == 'undefined'){
                activityLength = Object.keys(activity).length;
                if(activityLength > 0){
                    activityLength = 1;
                }
            }

            //console.log('milestone.size = ',milestoneLength);
            var activities = [];
            var milestones = [];
            for(var j = 0; j<milestoneLength;j++){
                //console.log('milestone = ',milestone);
                var milestoneId = null;
                var validationCheck = null;
                var milestoneName = null;
                if(milestoneLength == 1){
                    milestoneId = milestone.milestoneId;
                    milestone.docType="milestone";
                    validationCheck = milestone.validationCheck;
                    milestoneName = milestone.milestone;
                    milestone.milestoneName = milestoneName;
                    delete milestone["activityName"];
                    delete milestone["completedCriteria"];
                    delete milestone["validationCheck"];
                    delete milestone["activity"];
                    delete milestone["milestone"];
                    if(activityLength == 1){
                        var actMilestoneId = activity.milestoneId;
                        activity.docType="activity";
                        activity.activityId=activity.activityId;
                        activity.validationCheck=validationCheck;
                        delete activity["completionCriteria"];
                        if(actMilestoneId == milestoneId){
                            console.log('actMilestoneId = ',actMilestoneId);
                            activities.push(activity);
                        }
                    } else if(activityLength > 1){
                        for(var k = 0; k<activityLength;k++){
                            var actMilestoneId = activity[k].milestoneId;
                            activity[k].docType="activity";
                            activity[k].activityId=activity[k].activityId;
                            activity[k].validationCheck=validationCheck;
                            delete activity[j]["completionCriteria"];
                            if(actMilestoneId == milestoneId){
                                console.log('actMilestoneId = ',actMilestoneId);
                                activities.push(activity[k]);
                            }
                        }
                    }
                    milestone.activities=activities;
                    activities = [];
                    milestones.push(milestone);
                } else {
                    milestoneId = milestone[j].milestoneId;
                    milestone[j].docType="milestone";
                    validationCheck = milestone[j].validationCheck;
                    milestoneName = milestone[j].milestone;
                    milestone[j].milestoneName = milestoneName;
                    delete milestone[j]["activityName"];
                    delete milestone[j]["completedCriteria"];
                    delete milestone[j]["validationCheck"];
                    delete milestone[j]["activity"];
                    delete milestone[j]["milestone"];
                    if(activityLength == 1){
                        var actMilestoneId = activity.milestoneId;
                        activity.docType="activity";
                        activity.activityId=activity[k].activityId;
                        activity.validationCheck=validationCheck;
                        delete activity["completionCriteria"];
                        if(actMilestoneId == milestoneId){
                            console.log('actMilestoneId = ',actMilestoneId);
                            activities.push(activity);
                        }
                    } else if(activityLength > 1){
                        for(var k = 0; k<activityLength;k++){
                            var actMilestoneId = activity[k].milestoneId;
                            activity[k].docType="activity";
                            activity[k].activityId=activity[k].activityId;
                            activity[k].validationCheck=validationCheck;
                            delete activity[j]["completionCriteria"];
                            if(actMilestoneId == milestoneId){
                                console.log('actMilestoneId = ',actMilestoneId);
                                activities.push(activity[k]);
                            }
                        }
                    } else {

                    }


                    milestone[j].activities=activities;
                    activities = [];
                    milestones.push(milestone[j]);
                }

                //console.log('milestoneId = ',milestoneId);


            }

            projectDet.milestones = milestones;
            //console.log('All Details = ',JSON.stringify(projectDet));
        }

        allProjectDet.push(projectDet);

        res.end( JSON.stringify(projectDet));
    });
    return deferred.promise;
})
var server = app.listen(8081, function () {

   var host = server.address().address
   var port = server.address().port
   console.log("Example app listening at http://%s:%s", host, port)

})
