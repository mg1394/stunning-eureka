/**
 * Created By :- Girijashankar Mishra
 * Created Date :- 08-05-2017 14:00 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('Customer.IndexController', Controller);

    function Controller($window, CustomerService, FlashService,$scope,$http) {
       var vm = this;
       vm.model = {selected: {}}

       //Decides what to show based on user input
       vm.getTemplate = function (cust) {
          if (cust._id === vm.model.selected._id ){
              return 'editCustomer';
          }
          else return 'displayCustomer';
       };

       //Gets the customer details for which edit is to be done
       vm.editCustomer = function (cust) {
           vm.model.selected = angular.copy(cust);
       };


       //Deletes the selected customer
       vm.deleteCustomer = function (cust) {
           CustomerService.Delete(cust)
               .then(function () {
                   FlashService.Success('Customer Deleted');
                   $window.location.reload();
               })
               .catch(function (error) {
                   FlashService.Error(error);
               });
       };

       //Reset the edit customer details
       vm.reset = function () {
          vm.model.selected = {};
       };

       //Updates the selected customer details
       vm.updateCustomer = function (cust) {

           CustomerService.Update(cust)
               .then(function () {
                   FlashService.Success('Customer updated');
                   vm.reset();
                   $window.location.reload();
               })
               .catch(function (error) {
                   FlashService.Error(error);
               });
       }

       //Save new customer
       vm.saveCustomer = function (cust) {

           CustomerService.Create(cust)
               .then(function () {
                   FlashService.Success('Customer Saved Successfully');
                   modal.style.display = "none";
                   $window.location.reload();
               })
               .catch(function (error) {
                   FlashService.Error(error);
               });
       }

       //Fetch all the customer from the collection and store in the object
       var getAllCustomer = function() {
            CustomerService.GetAll().then(function (cust) {
                vm.customer = cust;
                console.log("vm.customer All = ",vm.customer);

            });

      };

      getAllCustomer();
    }

})();
