﻿var express = require('express');
var router = express.Router();
var request = require('request');
var config = require('config.json');
var ftuc=require('services/user.service.js').ftuc;

var Client = require('node-rest-client').Client;

var client = new Client();

var base64 = require('base-64');


console.log('FTUC INTITALIZE :'+ftuc);
router.get('/', function (req, res) {
    // log user out
    delete req.session.token;

    // move success message into local variable so it only appears once (single read)
    var viewData = { success: req.session.success };
    delete req.session.success;

    res.render('login', viewData);
});

router.post('/', function (req, res) {
    // authenticate using api to maintain clean separation between layers

    var data=  {username:req.body.username,
                password:  req.body.password,
                role: req.body.role};

    var authdata = base64.encode(data.username + ':' + data.password);
    var base64Conv = 'Basic ' + authdata;
    var args={
      headers: {
                'Content-Type': 'application/json',
                'X-IBM-Client-Id': '174524e5-cec9-4305-a147-2eb41a900dda',
                'Authorization': base64Conv
                },
      xhrFields: {
                withCredentials: true
                 },
      crossDomain: true
    };
    /*request.post({
        //url: config.apiUrl + '/users/authenticate',
        url:'https://10.0.45.87:1443/BlockChain2/LoginService?role=' + data.role,
        //url:'https://uatsky.yesbank.in/app/uat/BlockChainGateway/LoginService?role='+ req.body.role,
        form: req.body,
        json: true
    }*/




        // save JWT token in the session to make it available to the angular app
        req.session.token = req.body.token;

        // redirect to returnUrl
        var returnUrl = req.query.returnUrl && decodeURIComponent(req.query.returnUrl) || '/';
        var name = req.body.username;
        var pw = req.body.password;
        var role=req.body.role;


        console.log('Data  :'+data);
        console.log('name : '+name+'pw: '+pw);
        console.log('role'+role);
        console.log('RETURN URL   '+returnUrl);
        // res.redirect(returnUrl);
        client.get("https://uatsky.yesbank.in/app/uat/BlockChainGateway/LoginService?role="+data.role, args, function (data, response) {
          // parsed response body as js object
          console.log('data  :',data);
          //res.redirect('/app/#/account');
          res.redirect(returnUrl);

          // raw response
          //console.log('response  :',response);
          }, function (error, response, body) {
            if (error) {
                return res.render('login', { error: 'An error occurred' });
            }


    });//request.post
});//router.post

module.exports = router;
