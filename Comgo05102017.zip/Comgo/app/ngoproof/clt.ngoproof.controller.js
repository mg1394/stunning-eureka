/**
 * Created By :- Madhura
 * Created Date :- 01-07-2017 11:00 am
 * Version :- 1.0
 * Updated By :- Akshay
 * Updated Date :- 05-07-2017 10:20 am
 * Version :- 1.0.0
 * Updated By :- Girijashankar
 * Updated Date :- 06-07-2017 04:00 pm
 * Version :- 1.0.2
 * Updated By :- Madhura
 * Updated Date :- 08-07-2017 09:40 am
 * Version :- 1.0.3
 * Updated By :- Mamta
 * Updated Date :- 30-07-2017 10:50 pm
 * Version :- 1.0.3
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('Ngoproof.NgoproofController', Controller);

    function Controller($stateParams, $state, Upload, FileUpload, $timeout, DocumentService, SessionService, MilestoneService, ProofService, FlashService, $scope, $http, currency) {

        var vm = this;
        var val1 = $stateParams.projName;
        var val2 = $stateParams.projId;
        vm.projectnm = $stateParams.projName;
        vm.total = $stateParams.total;
        vm.currency = $stateParams.currency;
        vm.actfundBudgeted = $stateParams.actfundBudgeted
        console.log('vm.currency***** = ', $stateParams.currency);
        vm.role = null;
        SessionService.GetSessionDetails().then(function(session) {
                vm.role = session.role;

            },
            function(error) {

            });

        //breadcrumbs
        $scope.doTheBack = function() {
            window.history.back();
        };

        vm.uploadFile = function(myFile) {
            console.log('file=', myFile);
            vm.file = myFile;
            /*var uploadUrl = "/savedata";
            FileUpload.uploadFileToUrl(file, uploadUrl).then(function (response) {
               console.log('hashed Data = ',response);
               console.log('hashed Data = ',response.data);
               vm.hash=response.data;
            });*/
        };

        vm.model = { selected: {} };
        vm.projectName = $stateParams.projectName;
        console.log("project name = ", vm.projectName);
        vm.milestoneName = $stateParams.milestoneName;
        vm.milestoneId = $stateParams.milestoneId;
        vm.projectId = $stateParams.projectId;
        var milestoneId = $stateParams.milestoneId;
        var projectId = $stateParams.projectId;
        console.log('vm.milestoneId=', vm.milestoneId);
        console.log('vm.projectId=', vm.projectId);
        vm.milestoneActivity = $stateParams.milestoneActivity;
        console.log('$stateParams.milestoneActivity=', $stateParams.milestoneActivity);
        vm.documentName = vm.fileHashValue;

        $scope.submitProof = function(val1, val2, val3) {
            $state.go('ngoproof', { milestoneId: val1, projectId: val2, milestoneName: val3, projectName: vm.projectnm });
        };
        //Fetch all the document from the collection and store in the object
        var getAllDocument = function() {
            var val1 = $stateParams.milestoneId;
            var val2 = $stateParams.projectId;

            DocumentService.GetAllDocument(val1, val2).then(function(doc) {
                vm.document = doc;
            });
            ProofService.GetAllProof(val1, val2).then(function(doc) {
                vm.proof = doc;
            });
        };

        var getAllCurrency = function() {
            currency.GetAll().then(function(proj) {
                vm.currency = proj;
            });
        };

        getAllDocument();
        getAllCurrency();
        //Decides what to show based on user input
        vm.getTemplate = function(doc) {
            if (proj._id === vm.model.selected._id) {
                return 'editDocument';
            } else return 'displayDocument';
        };

        //Gets the documentdetails for which edit is to be done
        vm.editDocument = function(doc) {
            vm.model.selected = angular.copy(doc);
        };


        //Deletes the selected Document
        vm.deleteDocument = function(doc) {
            DocumentService.Delete(doc)
                .then(function() {
                    FlashService.Success('Document Deleted');
                    $state.go('document');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
        };

        //Reset the edit documentdetails
        vm.reset = function() {
            vm.model.selected = {};
        };

        //Updates the selected documentdetails
        vm.updateDocument = function(doc) {
            DocumentService.Update(doc)
                .then(function() {
                    FlashService.Success('Document updated');
                    vm.reset();
                    $state.go('document');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
        };

        //Save new document
        vm.saveDocument = function(doc) {

            DocumentService.Create(doc)
                .then(function() {
                    FlashService.Success('Document Saved Successfully');
                    modal.style.display = "none";
                    $state.go('document');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
        };

        vm.hash = null;
        vm.file = null;
        vm.saveProof = function(proof, val1, val2, val3, val4) {
                //console.log("file in saveproof =",vm.file);
                var uploadUrl = "/savedata";

                var files = document.getElementById('file').files;
                SessionService.GetSessionDetails().then(function(session) {
                    vm.role = session.role;
                    FileUpload.uploadFileToUrl(vm.file, uploadUrl, $stateParams.milestoneId, $stateParams.projectId).then(function(response) {
                        // console.log('hashed Data = ',response.data);
                        vm.hash = response.data;
                        // console.log('files = ',files);
                        // console.log('filename=', files[0].name);
                        vm.FileName = files[0].name;
                        // console.log("hash milgaya 2= ",vm.hash);
                        proof.milestoneId = vm.milestoneId;
                        proof.projectId = vm.projectId;
                        vm.activityId = $stateParams.activityId;
                        //proof.hash=vm.fileHashValue;
                        var allId = {
                            projectId: vm.projectId,
                            milestoneId: vm.milestoneId,
                            activityId: vm.activityId,
                            role: vm.role,
                            projectName: vm.projectName,
                            activityName: vm.milestoneActivity
                        }
                        console.log("allId = ", allId);
                        proof.documentName = vm.FileName;
                        var doc = {};
                        doc["documentName"] = vm.FileName;
                        //doc["documentPath"]=vm.fileHashValue;
                        console.log("my url = ", '/uploadDoc/' + vm.projectId + '/' + vm.milestoneId + '/');
                        doc["documentPath"] = '/uploadDoc/' + vm.projectId + '/' + vm.milestoneId + '/';
                        doc["documentHash"] = vm.hash;
                        doc["allId"] = allId;
                        console.log("doc with id = ", doc);
                        //  console.log("doc 1= ",doc["documentHash"]);
                        //console.log("vm.fileHashValue",vm.fileHashValue);

                        DocumentService.Create(doc).then(function(doc) {
                            //  console.log("doc=",doc.insertedIds[0]);
                            proof.documentId = doc.insertedIds[0];
                            proof.activityId = vm.activityId;
                            console.log('proof.activityId', proof.activityId);
                            proof.projectId = vm.projectId;
                            proof.username = vm.username;
                            ProofService.Create(proof).then(function() {
                                FlashService.Success('Proof Saved Successfully');
                                var status = 'Closed';
                                MilestoneService.UpdateProofStatus($stateParams.milestoneId, status).then(function() {
                                    console.log('Proof status updated');
                                });
                                //#Madhura: On GoBack to submittedproof page update & show new document added
                                val1 = $stateParams.milestoneId;
                                val2 = $stateParams.projectId;
                                val3 = vm.milestoneId;
                                var activityId = $stateParams.activityId;
                                val4 = $stateParams.milestoneActivity;
                                $state.go('submittedproof', { milestoneId: val1, projectId: val2, milestoneName: val3, milestoneActivity: val4, projectName: vm.projectnm, activityId: activityId });
                            }).catch(function(error) {
                                FlashService.Error(error);
                            });
                        }).catch(function(error) {
                            FlashService.Error(error);
                        });
                    });
                }).catch(function(error) {
                    FlashService.Error(error);
                });
            }
            //# mamta :- 30-07-2017 prevent negative value.
        $scope.restrictNegativeNo = function(e) {
            if (e.keyCode == 45) {
                e.preventDefault();
            }
        }

        //#Edited by:- Madhura for base64 conversion
        vm.fileHashValue = null;
        vm.FileName = null;
        vm.getHashValue = function(proof) {
            var files = document.getElementById('file').files;
            console.log('files = ', files);
            console.log('filename=', files[0].name);
            vm.FileName = files[0].name;
            if (files.length > 0) {
                var reader = new FileReader();
                //reader.readAsDataURL(files[0]);
                //reader.readAsText(files[0], MD5);
                reader.onload = function() {
                    //console.log("Base64=",reader.result);
                    vm.fileHashValue = reader.result;

                };
                reader.onerror = function(error) {
                    console.log('Error: ', error);
                };
            }
        }
    }

})();