/**
 * Created By :- Akshay
 * Created Date :- 31-07-2017 14:20 pm
 * Version :- 1.0.0 get data from blockchain and database
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('Audit.AuditController', Controller);

    function Controller($stateParams, $http, $scope, $state, $rootScope, ProjectDonation, ProjectService, MilestoneService, ActivityService, FundRaisedService) {
        var vm = this;
        vm.projectType = $stateParams.projectType;
        vm.fundGoal = $stateParams.fundGoal;
        vm.currency = $stateParams.currency;
        
        var getDataFrom = $stateParams.getDataFrom;
        var projectId = $stateParams.projectId;
        vm.tempFundAllocated=$rootScope.tempFundAllocated;
        
        vm.projectName = $stateParams.projectName;
        $scope.showTransactionSummary = function (val1) {
            $state.go('transactionSummary',{txnId:val1});
        };
        vm.fundRaised = $stateParams.fundRaised;
        vm.fundBalance= vm.fundGoal-vm.fundRaised;
        

        //#MG: code for donut chart
        $scope.labels = ["Fund Raised", "Fund Balance"];
        $scope.data = [vm.fundRaised,vm.fundBalance];
        $scope.Color= ['#90EE90', '#8080FF'];
        $scope.DataSetOverride = [{ yAxisID: 'y-axis-1' }];
        $scope.options = {
              legend: { display: true },
              responsive: true,  // set to false to remove responsiveness. Default responsive value is true.
              scales: {
                  yAxes: [
                      {
                          id: 'y-axis-1',
                          type: 'linear',
                          display: false,
                          position: 'left'
                      }]
              }
          }

        //#Akshay: get milestone details by Params from blockchain
        var getAllBKCproject = function() {
            MilestoneService.BKCGetAllDetails($stateParams.projectId).then(function(project) {
                //  vm.milestoneByParams= milestone;
                //vm.milestone = milestone;
                var milestoneArray = [];
                console.log("project BKC = ", project);
                //var milestones = project[0].Value.milestones;
                //console.log("milestone = ", milestones);
                for (var i = 0; i < project.length; i++) {
                    var mySingleMilestone = {};
                    mySingleMilestone["fundGoal"] = project[i].Value.fundGoal;
                    mySingleMilestone["fundRaised"] = project[i].Value.fundRaised;
                    mySingleMilestone["projectType"] = project[i].Value.projectType;
                    mySingleMilestone["fundAllocated"] = project[i].Value.fundAllocated;
                    mySingleMilestone["txnId"] = project[i].TxId;
                    mySingleMilestone["timeStamp"] = new Date(project[i].Timestamp);//#MG 26-08-2107
                    mySingleMilestone["donationAmount"] = project[i].Value.lastDonation.donationAmount;
                    mySingleMilestone["donorName"] = project[i].Value.lastDonation.donorName;
                    mySingleMilestone["stat"] = project[i].Value.flag.substring(0, 15);
                    mySingleMilestone["flag"] = project[i].Value.flag;
                    mySingleMilestone["bc"] = 'BC';
                    
                    var arr=[];
                    var tempFlag = project[i].Value.flag;
                    
                    var arr = tempFlag.split(" ");  
                      
                    console.log('string==',arr);

                    mySingleMilestone["mil_id"] = arr[arr.length-1];
                    vm.fundGoalBC=project[i].Value.fundGoal;
                    
                     milestoneArray.push(mySingleMilestone);
                }
                vm.milestone = milestoneArray;
                console.log("final = ", vm.milestone);

            });
        };

        var getAllDBProjectforBKC = function() {
            MilestoneService.getAllAudit($stateParams.projectId).then(function(project) {
                console.log('milestone milestone == ',project);

                    var milestoneArray = []
                        //console.log('activity activity == ',activity);
                    for (var i = 0; i < project.length; i++) {

                        var mySingleProject = {};
                        mySingleProject["projectId"] = project[i].projectId!=null?project[i].projectId:"";
                        mySingleProject["currentStatus"] = project[i].currentStatus!=null?project[i].currentStatus:"";
                        mySingleProject["previousStatus"] = project[i].previousStatus!=null?project[i].previousStatus:"";
                        mySingleProject["updatedDate"] = new Date(project[i].updatedDate!=null?project[i].updatedDate:"");//#MG 26-08-2107
                        mySingleProject["milestoneId"] = project[i].milestoneId!=null?project[i].milestoneId:"";
                        mySingleProject["milestoneName"] = project[i].milestone!=null?project[i].milestone:"";
                        mySingleProject["activityId"] = project[i].activityId!=null?project[i].activityId:"";
                        mySingleProject["activityName"] = project[i].activityName!=null?project[i].activityName:"";
                        mySingleProject["role"] = project[i].role!=null?project[i].role:"";
                        mySingleProject["username"] = project[i].username!=null?project[i].username:"";
                        mySingleProject["DB"] = 'DB';
                        milestoneArray.push(mySingleProject);
                    }
                vm.milestoneDBdataForBKC = milestoneArray
                console.log('=====final Audit in db =====', vm.milestoneDBdataForBKC);
                })

        }
        /////////audit for blockchain ends/////////////////
        ///////////////////////////////////////////////////

        //////////////audit for db starts///////////////////
        //////////////////////////////////////////////////

        //# Akky : 31.07.2017 get data from database
        var getAllDBProject = function() {
            MilestoneService.getAllAudit($stateParams.projectId).then(function(project) {
                console.log('milestone milestone == ',project);

                    var milestoneArray = []
                        //console.log('activity activity == ',activity);
                    for (var i = 0; i < project.length; i++) {

                        var mySingleProject = {};
                        mySingleProject["projectId"] = project[i].projectId!=null?project[i].projectId:"";
                        mySingleProject["currentStatus"] = project[i].currentStatus!=null?project[i].currentStatus:"";
                        mySingleProject["previousStatus"] = project[i].previousStatus!=null?project[i].previousStatus:"";
                        mySingleProject["updatedDate"] = new Date(project[i].updatedDate!=null?project[i].updatedDate:"");//#MG 26-08-2107
                        mySingleProject["milestoneId"] = project[i].milestoneId!=null?project[i].milestoneId:"";
                        mySingleProject["milestoneName"] = project[i].milestone!=null?project[i].milestone:"";
                        mySingleProject["activityId"] = project[i].activityId!=null?project[i].activityId:"";
                        mySingleProject["activityName"] = project[i].activityName!=null?project[i].activityName:"";
                        mySingleProject["role"] = project[i].role!=null?project[i].role:"";
                        mySingleProject["username"] = project[i].username!=null?project[i].username:"";
                        mySingleProject["DB"] = 'DB';
                        milestoneArray.push(mySingleProject);
                    }
                vm.milestone = milestoneArray
                console.log('=====final Audit in db =====', vm.milestone);
                })

        }

        if (getDataFrom == 'Blockchain') {
            console.log("get data from blockchain");
            getAllBKCproject();
            getAllDBProjectforBKC();
        } else if (getDataFrom == 'Database') {
            console.log("get data from Database");
            getAllDBProject();
        }

        // #GM : 31072017 Fetch all Fund raised from blockchain
        var formTimelineCssFundRaised = function() {
            FundRaisedService.GetAllFundRaisedDetails($stateParams.projectId).then(function(project) {
                console.log('fundraised project = ', project);
                var fundRaised = project;
                for (var i = 0; i < fundRaised.length; i++) {
                    var donationDate = fundRaised[i].Timestamp;
                    var donorId = fundRaised[i].Value.lastDonation.donorId;
                    var donationAmount = fundRaised[i].Value.lastDonation.donationAmount;

                    if (donationAmount != "" && donationAmount > 0) {
                        donationDate = donationDate.substring(0, 10);
                        var li = document.createElement('li');
                        li.setAttribute('class', 'li complete');
                        var divTime = document.createElement('div');
                        divTime.setAttribute('class', 'timestamp');
                        var spanDate = document.createElement('span');
                        spanDate.setAttribute('class', 'date');
                        spanDate.innerHTML = donationDate;
                        //divTime.appendChild(spanAuth);
                        divTime.appendChild(spanDate);

                        var data = "<h4>" + donorId + "</h4>" +
                            "<p>Donated Amount       : " + donationAmount + "</p><br/>";

                        spanDate.innerHTML = data;
                        var divSts = document.createElement('div');
                        divSts.setAttribute('class', 'status');
                        var divStsData = "<br/><h4>" + donationDate + "</h4>";
                        divSts.innerHTML = divStsData;

                        li.appendChild(divTime);
                        li.appendChild(divSts);
                        console.log('li ====> ', li);
                        document.getElementById('timeline').appendChild(li);

                    }

                }

            });
        };
        //formTimelineCssFundRaised();

    }
})();
