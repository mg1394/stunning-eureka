/**
 * Created By :- Akshay
 * Created Date :- 31-07-2017 14:20 pm
 * Version :- 1.0.0 get transaction history
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('TransactionSummary.TransactionSummaryController', Controller);

    function Controller($stateParams, $http, $scope, $state, $rootScope, TransactionSummaryService) {
        var vm = this;
        console.log("im in transaction history", $stateParams.txnId);
        vm.txnId = $stateParams.txnId;

        // Akshay : - get transaction history
        var BKCGetTransactionDetails = function() {
                TransactionSummaryService.BKCGetTransactionDetails($stateParams.txnId).then(function(transaction) {
                    console.log(transaction);
                    var actions = transaction.transactionEnvelope.payload.data.actions;
                    var myTxnArray = [];
                    for (var i = 0; i < actions.length; i++) {
                        var mySingleTxn = {};
                        var data = actions[i].payload.chaincode_proposal_payload.input;
                        var timeStamp = transaction.transactionEnvelope.payload.header.channel_header.timestamp;
                        var hash = actions[i].payload.action.proposal_response_payload.proposal_hash;
                        //var str = data.replace(/[\]\[]/g, '');
                        // data = data.replace("comgoTest", "");
                        var search = "";
                        var replacement = ";";
                        String.prototype.replaceAll = function(data, replacement) {
                            var target = this;
                            return target.replace(new RegExp(data, ''), replacement);
                        };
                        mySingleTxn["hash"] = hash;
                        mySingleTxn["data"] = data;
                        mySingleTxn["timeStamp"] = timeStamp;
                        myTxnArray.push(mySingleTxn);
                        // console.log(String.prototype.replaceAll);
                        // console.log(hash);
                        // console.log(data);
                        // console.log(timeStamp);
                    }
                    vm.transaction = myTxnArray;
                });
            }
            //#Akshay : - call BKCGetTransactionDetails() 
        BKCGetTransactionDetails();
    }
})();