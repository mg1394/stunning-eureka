/**
 * Created By :- Girijashankar Mishra
 * Created Date :- 08-05-2017 14:00 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('Project.ProjectController', Controller);

    function Controller($window,$state, ProjectService, FlashService,$scope,$http) {
       var vm = this;
       vm.model = {selected: {}}

       //Decides what to show based on user input
       vm.getTemplate = function (proj) {
           if ( proj._id === vm.model.selected._id ){
               return 'editProject';
           }
           else return 'displayProject';
       };

       //Gets the project details for which edit is to be done
       vm.editProject = function (proj) {
           vm.model.selected = angular.copy(proj);
       };


       //Deletes the selected project
       vm.deleteProject = function (proj) {
           ProjectService.Delete(proj)
               .then(function () {
                   FlashService.Success('Project Deleted');
                   $state.go('project');
               })
               .catch(function (error) {
                   FlashService.Error(error);
               });
       };

       //Reset the edit project details
       vm.reset = function () {
          vm.model.selected = {};
       };

       //Updates the selected project details
       vm.updateProject = function (proj) {

           ProjectService.Update(proj)
               .then(function () {
                   FlashService.Success('Project updated');
                   vm.reset();
                   $state.go('project');
               })
               .catch(function (error) {
                   FlashService.Error(error);
               });
       }

       //Save new project
       vm.saveProject = function (proj) {
        console.log("currency=",vm.addProject.fundgoalCurrency);
           ProjectService.Create(proj)
               .then(function () {
                   FlashService.Success('Project Saved Successfully');
                   modal.style.display = "none";
                   $state.go('project');
               })
               .catch(function (error) {
                   FlashService.Error(error);
               });
       }

       //Fetch all the project from the collection and store in the object
       var getAllProject = function() {
            ProjectService.GetAll().then(function (proj) {
                vm.project = proj;
                //console.log("vm.project All = ",vm.project);

            });

      };

      getAllProject();
    }

})();
