
(function () {
    'use strict';

    angular
        .module('app')
        .controller('Activity.ActivityController', Controller);

    function Controller($window,$state, MilestoneService,ImageService,$scope,$stateParams,$rootScope) {
        var vm = this;
        vm.activity={'MilestoneName':'kick-off and procuring' ,
                      'ActivityName':'Buy Bricks',
                      'StartDate':'05/05/17',
                      'EndDate':'06/05/17',
                      'FundBudgeted':'7,000.00',
                      'FundAllocated':'7,000.00',
                      'FundRequested':'7,000.00',
                      'FundReleased':'7,000.00',
                      'Status':'Completed',
                      'RequestFund':'',
                      'SubmitProof':''

          }
          vm.activity1={ 'ActivityName':'Buy metal rod',
                        'StartDate':'07/05/17',
                        'EndDate':'08/05/17',
                        'FundBudgeted':'8,000.00',
                        'FundAllocated':'8,000.00',
                        'FundRequested':'00.00',
                        'FundReleased':'00.00',
                        'Status':'In progress',
                        'RequestFund':'',
                        'SubmitProof':''

            }
vm.ngoData=$rootScope.ngoData;
console.log('ngoData.FundRaised=',vm.ngoData.FundRaised);
        var val1 =  $stateParams.projName;
        var val2 =  $stateParams.projId;
        vm.projectnm = $stateParams.projName;

        // #GM 160617 :- Data to be fetched from $stateParams, hardcoding to be replaced
        vm.description = $stateParams.description;
        vm.fundRaised = Number($stateParams.fundRaised);
        var myDonation = $stateParams.myDonation;
        vm.fundGoal = Number($stateParams.fundGoal);
        //console.log('FG = ',vm.fundGoal);
        //console.log('FR = ',vm.fundRaised);
        //console.log('Cond = ',vm.fundRaised>vm.fundGoal);
        // #GM 210617 :- If fundRaised > fundGoal, fundGoal = vm.fundRaised
        if(vm.fundRaised>vm.fundGoal){
            vm.fundGoal = vm.fundRaised;
            //console.log('FG In = ',vm.fundGoal);
            //console.log('FR In = ',vm.fundRaised);
        }

        var fundBalance = vm.fundGoal - vm.fundRaised;
        var otherDonation = vm.fundRaised-myDonation;

        // #GM 210617 :- If fundRaised < 0, otherDonation = vm.fundRaised
        if(vm.fundRaised<0){
            fundBalance = vm.fundGoal - myDonation;
            otherDonation = vm.fundRaised;
        }

         $scope.labels = ["Other's Donataion", "My Donation", "Fund Balance"];
         $scope.data = [vm.ngoData.FundRaised, 200, vm.ngoData.FundGoal];
         $scope.options = {legend: {display: true,position:"right"}};
         $scope.colours = ['#0a22d8', '#7bf230', '#ff0000'];

        //send projname and projid to donate screen
        $scope.donate = function () {
            $state.go('donate',{projName:val1,projId:val2});
        };

        //go to document page
        $scope.showDocument = function (val1,val2,val3) {
            $state.go('document',{milestoneId:val1,projectId:val2,milestoneName:val3,projectName:vm.projectnm});
        };

        //Fetch all milestones from the project milestone collection and store in the object
        var getByProjName = function() {
            MilestoneService.GetByProjname($stateParams.projId).then(function (project) {
                vm.milestone = project;
            });
        };

        //fetch image from db
        var getImageByProjId = function() {
            ImageService.GetImageByProjId($stateParams.projId).then(function (image) {
                vm.projectImage = image;
                if(image.length==0){
                    var myImageDetails = [];
                    var mySingleImage = {};
                    mySingleImage['imageUrl'] = "img/project/default";
                    mySingleImage['milestoneId'] = $stateParams.projId;
                    mySingleImage['projectId'] = $stateParams.projId;
                    mySingleImage['_id']    = $stateParams.projId;
                    myImageDetails.push(mySingleImage);
                    vm.projectImage = myImageDetails;
                }
            });
        };





        getByProjName();

        getImageByProjId();

    }
})();
