/**
 * Created By :- Mamta Bhardwaj
 * Created Date :- 09-06-2017 11:00 am
 * Version :- 1.0
 * Created By :- Akshay
 * Created Date :- 09-06-2017 03:00 pm
 * Version :- 1.0
 * Updated By :- Madhura
 * Created Date :- 23-06-2017 10:30 am
 * Version :- 1.0
 * Updated By :- Mamta
 * Created Date :- 23-06-2017 03:05 pm
 * Version :- 1.1.1
 * Updated By :- Mamta
 * Created Date :- 05-07-2017 03:05 pm
 * Version :- 1.1.1
 * Updated By :- Madhura
 * Created Date :- 06-07-2017 12:30 pm
 * Version :- 1.1.2
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('AddProject.AddProjectController', Controller);

    function Controller($stateParams, $state, projecttype,FileUpload, country, currency, $timeout, MilestoneService, ActivityService, SessionService, ProjectService, FlashService, $scope, $http, ngoService, $filter) {
        var vm = this;
        $scope.addNew = function(personalDetail) {
            /*$scope.vm.milestone.push({
                'milestone': "",
                'startDate': "",
                'endDate': "",
                'completionCriteria': "",
            });*/

            getAllMilestoneById($stateParams.projId);
        };

        $scope.doTheBack = function() {
            window.history.back();
        };

        var refresh = function() {
            $http.get('/addproject').success(function(response) {
                console.log("I got the data I requested");
                $scope.vm.milestone = response;
                $scope.mil = "";
            });
            getAllMilestoneById($stateParams.projId);
        };

        vm.toDo = $stateParams.toDo;
        console.log('u clicked==', vm.toDo);
        //vm.edit=$stateParams.edit;
        //console.log('u clicked edit=',vm.edit);
        vm.addProject = {};
        $scope.addProject = vm.addProject;
        vm.addProject.projectName = $stateParams.projName;
        //console.log('projName=',vm.projName);
        vm.projId = $stateParams.projId;
        vm.projOwner = $stateParams.ngo;
        console.log(vm.projOwner);
        vm.curr = $stateParams.currency;
        console.log('vm.addProject.currencyCode=== ==', vm.currency);
        vm.country = $stateParams.country;
        console.log('vm.country', vm.country);

        //# Akshay 14-08-2017: Date filter
        vm.startDt = $stateParams.startDate;
        vm.startDate = $filter('date')(vm.startDt, "yyyy-MM-dd");
        console.log("vm.dateAsString = ",vm.startDate);
        vm.endDt = $stateParams.endDate;
        vm.endDate = $filter('date')(vm.endDt, "yyyy-MM-dd");
        console.log("vm.endDate = ",vm.endDate);

        vm.fundGoal = $stateParams.fundGoal;
        vm.addProject.fundGoal = $stateParams.fundGoal;
        vm.addProject.description = $stateParams.description;
        vm.addProject.projectType = $stateParams.projectType;
        vm.addProject.projectOwner = $stateParams.ngo;
        vm.addProject.country = $stateParams.country;

        vm.projtype = $stateParams.projectType;

        //#MG startDate validation
        vm.todaysdate = new Date().toISOString().slice(0, 10);;

        console.log('vm.addProject.projectOwner=============', vm.addProject.projectOwner);
        vm.addProject.startDate = $stateParams.startDate;
        vm.addProject.endDate = $stateParams.endDate;
        vm.file=null;
        vm.saveProject = function(project) {
                console.log('project===', project);
                project.status = 'Not Initiated';
                console.log('condition=',project.startDate<project.endDate);
                if(project.startDate<=project.endDate){
                ProjectService.Create(project).then(function(result) {
                    FlashService.Success('Project Saved');
                });
                $state.go('prePublishProject');
              }else{
                alert('Please enter valid start date and end date!');
              }
            }
            //# mamta :- 30-07-2017 prevent negative value.
        $scope.restrictNegativeNo = function(e) {
            if (e.keyCode == 45) {
                e.preventDefault();
            }
        }

        vm.updateProject = function(val1, val2, val3, val4) {
          var uploadUrl = "/saveimage";
          var image = document.getElementById('image').files;
          console.log(vm.image);
          FileUpload.uploadImageToUrl(vm.image, uploadUrl, $stateParams.projId).then(function(response) {
            })
            var proj = val1;
            console.log('proj.image',proj.image);
            proj.projectId = vm.projId;
            if (!proj.currency) {
                proj.currency = $stateParams.currency;
            }
            if (!proj.projectOwner) {
                proj.projectOwner = $stateParams.ngo;
            }
            if (!proj.fundGoal || proj.fundGoal == '') {
                proj.fundGoal = val2;
            }
            if (!proj.startDate) {
                proj.startDate = val3;
            }
            if (!proj.endDate) {
                proj.endDate = val4;
            }
            //proj.fundGoal = val2;
           //console.log("val1.startDate 1 =",val1.startDate);
           val1.endDate = $filter('date')(val1.endDate, "yyyy-MM-dd");
           val1.startDate = $filter('date')(val1.startDate, "yyyy-MM-dd");
           //console.log("val1.startDate 2 =",val1.endDate);
            console.log('condition=',val1.startDate<=val1.endDate);
            if(val1.startDate<=val1.endDate){
            ProjectService.UpdateProject(proj)
                .then(function() {
                    FlashService.Success('Project updated');
                    //FlashService.Success('Project updated');
                    $state.go('prePublishProject');
                });
            }else{
              alert('Please enter valid start date and end date!');
            }
            //});
        }

        vm.saveMilestone = function(result) {
            result.projectId = vm.projId;
            result.fundAllocated = vm.addMilestone.fundBudgeted;
            MilestoneService.Create(result).then(function(result) {
                    console.log('result=', result);
                    FlashService.Success('milestone saved');
                    $scope.vm.addMilestone.milestone = '';
                    $scope.vm.addMilestone.startDate = '';
                    $scope.vm.addMilestone.endDate = '';
                    $scope.vm.addMilestone.activityName = '';
                    $scope.vm.addMilestone.fundBudgeted = '';
                    $scope.vm.addMilestone.validationCheck = '';

                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
            getAllMilestoneById(vm.projId);
            //getAllMilestone();
        }

        vm.saveActivity = function(result) {
            result.projectId = vm.projId;
            result.milestoneId = $stateParams.milestoneId;
            ActivityService.Create(result)
                .then(function(result) {
                    console.log('result=', result);
                    FlashService.Success('activity saved');
                    $scope.vm.addActivity.activityName = '';
                    $scope.vm.addActivity.startDate = '';
                    $scope.vm.addActivity.endDate = '';
                    $scope.vm.addMilestone.activityName = '';
                    $scope.vm.addMilestone.fundBudgeted = '';
                    $scope.vm.addMilestone.validationCheck = '';
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
            getActivityById($stateParams.milestoneId);
        }

        vm.uploadImg = function(myFile) {
            console.log('file=', myFile);
            vm.image = myFile;

        };

        var getAllCurrency = function() {
            currency.GetAll().then(function(proj) {
                vm.currency = proj;
            });
        };

        var getAllNgo = function() {
            ngoService.GetAll().then(function(ngo) {
                vm.ngo = ngo;
                console.log('vm.ngo==',vm.ngo);
            });
        };

        var getAllCountry = function() {
            country.GetAll().then(function(proj) {
                vm.country = proj;
                console.log('all country====', vm.country);
            });
        };

        var getAllProjectType = function() {
            projecttype.GetAll().then(function(proj) {
                vm.projecttype = proj;
                console.log('all projecttype====', vm.projecttype);
            });
        };

        var getAllMilestone = function() {
            MilestoneService.GetAllMilestone().then(function(mil) {
                vm.milestone = mil;
                console.log('vm.milestone =', vm.milestone);
            });
        };

        var getAllMilestoneById = function(projectId) {
            MilestoneService.GetMilestoneById(projectId).then(function(mil) {
                vm.milestone = mil;
                console.log('vm.milestone =', vm.milestone);
            });
        };

        var getAllActivity = function() {
            ActivityService.GetAllActivity().then(function(act) {
                vm.activity = act;
                console.log('vm.activity =', vm.activity);
            });
        };

        var getActivityById = function(id) {
            ActivityService.GetActivityById(id).then(function(act) {
                vm.activity = act;

            });
        };
        //getAllActivity();
        getAllMilestoneById($stateParams.projId);
        getAllCurrency();
        getAllCountry();
        getAllProjectType();
        getAllNgo();

        var activityDetail = null
        $(document).on('click', '.addActivity', function() {
            // your function here
            var id = $(this).attr('id');

            $stateParams.milestoneId = id;
            getAllMilestoneById($stateParams.projId);
            getActivityById(id);

            $("#activity").show();
        });

    }


})();
