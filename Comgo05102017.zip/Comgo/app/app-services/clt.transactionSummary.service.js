/*
* Updated By :- Madhura
* Created Date :- 08-07-2017 04:11 pm
* Version :- 1.0.1
*/
(function () {
    'use strict';

    angular
        .module('app')
        .factory('TransactionSummaryService', Service);

    function Service($http, $q) {
        var service = {};

        service.BKCGetTransactionDetails = BKCGetTransactionDetails;
      
        return service;

        function BKCGetTransactionDetails(txnId) {
            console.log("txnId app-ser = ",txnId);
            return $http.get('/api/TransactionSummary/all/'+txnId).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
