/*
* Updated By :- Madhura
* Created Date :- 08-07-2017 04:11 pm
* Version :- 1.0.1
*/
(function () {
    'use strict';

    angular
        .module('app')
        .factory('InvoiceService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetCurrent = GetCurrent;
        service.GetAllInvoice = GetAllInvoice;
        service.GetById = GetById;
        service.GetByProjname = GetByDocname;
        service.Create = Create;
        service.Update = Update;
        service.Delete = Delete;
        service.GetInvoiceById = GetInvoiceById;

        return service;

        function GetCurrent() {
            return $http.get('/api/invoices/current').then(handleSuccess, handleError);
        }

        function GetAllInvoice() {
            return $http.get('/api/invoices/all').then(handleSuccess, handleError);
        }

        function GetById(_id) {
            return $http.get('/api/invoices/' + _id).then(handleSuccess, handleError);
        }

        function GetByDocname(documentname) {
            return $http.get('/api/invoices/' + documentname).then(handleSuccess, handleError);
        }

        function Create(document) {
          console.log("document = ",document);
            return $http.post('/api/invoices/create', document).then(handleSuccess, handleError);
        }

        function Update(document) {
            console.log('document in inv service=',document);
            return $http.put('/api/invoices/' + document._id, document).then(handleSuccess, handleError);
        }

        function Delete(document) {
          //console.log("_id = ",documet);
            return $http.delete('/api/invoices/' + document._id).then(handleSuccess, handleError);
        }
        function GetInvoiceById(activityId) {
            console.log('Activity id in InvoiceService=',activityId);
            return $http.get('/api/invoices/allById/'+activityId).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
