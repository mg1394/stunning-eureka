/**
 * Created By :- Madhura
 * Created Date :- 09-08-2017 17:43 pm
 * Version :- 1.0
 */

(function () {
    'use strict';

    angular
        .module('app')
        .factory('ngoService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetAll = GetAll;

        return service;


        function GetAll() {
            return $http.get('/api/ngo/all').then(handleSuccess, handleError);
        }

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
