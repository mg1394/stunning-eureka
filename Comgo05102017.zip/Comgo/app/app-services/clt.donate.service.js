/**
 * Created By :- Madhura
 * Created Date :- 08-06-2017 13:13 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('DonateService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetCurrent = GetCurrent;
        service.GetAll = GetAll;
        service.GetById = GetById;
        service.GetByDonname = GetByDonname;
        service.Create = Create;
        service.Update = Update;
        service.Delete = Delete;
        return service;

        function GetCurrent() {
            return $http.get('/api/donates/current').then(handleSuccess, handleError);
        }

        function GetAll() {
            return $http.get('/api/donates/all').then(handleSuccess, handleError);
        }

        function GetById(_id) {
            return $http.get('/api/donates/' + _id).then(handleSuccess, handleError);
        }

        function GetByDonname(donatename) {
            return $http.get('/api/donates/' + donatename).then(handleSuccess, handleError);
        }

        function Create(donate) {
          //console.log("project = ",project);
            return $http.post('/api/donates/create', donate).then(handleSuccess, handleError);
        }

        function Update(project) {
            return $http.put('/api/donates/' + donate._id, donate).then(handleSuccess, handleError);
        }

        function Delete(donate) {
          //console.log("_id = ",project);
            return $http.delete('/api/donates/' + donate._id).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
