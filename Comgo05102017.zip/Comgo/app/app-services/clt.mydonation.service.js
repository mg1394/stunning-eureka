/**
 * Created By :- Akshay
 * Created Date :- 09-06-2017 04:30 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Created Date :- 13-06-2017 10:11 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('MydonationService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetAll = GetAll;

        return service;

        function GetAll(projId,donorId) {
            return $http.get('/api/mydonation/all/'+ projId+'/'+donorId).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
