/**
 * Created By :- Akshay
 * Created Date :- 12-06-2017 02:30 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('ImageService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetImageByProjId = GetImageByProjId;

        return service;

        function GetImageByProjId(_projId) {
            return $http.get('/api/projectImage/allByProjId/' + _projId).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
