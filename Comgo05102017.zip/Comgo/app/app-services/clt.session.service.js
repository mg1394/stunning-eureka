/**
 * Created By :- Akshay
 * Created Date :- 17-06-2017 08:45 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('SessionService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetSessionDetails = GetSessionDetails;

        return service;

        function GetSessionDetails() {
            return $http.get('/api/session/name').then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
