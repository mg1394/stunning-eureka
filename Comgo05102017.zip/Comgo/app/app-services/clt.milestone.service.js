/**
 * Created By :- Akshay
 * Created Date :- 09-06-2017 04:30 pm
 * Version :- 1.0
 * Updated By :- Madhura
 * Created Date :- 06-07-2017 12:30 pm
 * Version :- 1.1
 * Updated By :- Madhura
 * Created Date :- 11-07-2017 02:00 pm
 * Version :- 1.2
 * Updated By :- Akshay
 * Created Date :- 27-07-2017 12:00 pm
 * Version :- 1.0.3 call fund request to blockchain
 * Updated By :- Madhura
 * Created Date :- 30-07-2017 12:00 pm
 * Version :- 1.0.4 send status on request fund
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('MilestoneService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetByProjname= GetByProjname;
        service.getAllAudit = getAllAudit;
        service.Create = Create;
        service.CreateActivity = CreateActivity;
        service.GetAllMilestone = GetAllMilestone;
        service.GetMilestoneById = GetMilestoneById;
	    service.UpdateFundRequested= UpdateFundRequested;
        service.BKCFundReleased= BKCFundReleased;
        service.BKCFundRequest = BKCFundRequest;
	    service.UpdateFundReleased= UpdateFundReleased;
        service.BKCGetDetailsByParams= BKCGetDetailsByParams;
        service.BKCGetAllDetails= BKCGetAllDetails;
        service.UpdateProofStatus= UpdateProofStatus;
        service.UpdateFundBudget=UpdateFundBudget;
        service.fundAllocateToMilestone = fundAllocateToMilestone;
        service.Update = Update;
        service.Delete = Delete;
        return service;

        //#Akshay :- 07-08-2017 get single project history
        function BKCGetDetailsByParams(projectId) {
            return $http.get('/api/milestone/BKCAllByParams/'+projectId).then(handleSuccess, handleError);
        }
        //#Akshay :- 07-08-2017 get all project history 
        function BKCGetAllDetails(projectId) {
            return $http.get('/api/milestone/BKCGetAll/'+projectId).then(handleSuccess, handleError);
        }

        function GetByProjname(_projId) {
            return $http.get('/api/milestone/allByName/' + _projId).then(handleSuccess, handleError);
        }

        function getAllAudit(_projId) {
            return $http.get('/api/milestone/getAllAudit/' + _projId).then(handleSuccess, handleError);
        }
        function Create(project) {
          //console.log("project = ",project);
            return $http.post('/api/milestone/create', project).then(handleSuccess, handleError);
        }
        function CreateActivity(activity) {
          //console.log("activity = ",activity);
            return $http.post('/api/milestone/createAct', activity).then(handleSuccess, handleError);
        }
        function GetAllMilestone() {
            return $http.get('/api/milestone/all').then(handleSuccess, handleError);
        }

        function GetMilestoneById(projectId) {
            console.log(projectId);
            return $http.get('/api/milestone/allById/'+projectId).then(handleSuccess, handleError);
        }
	// #GM 060717 :- Update FundRequested in ProjectMilestone
        function UpdateFundRequested(milestoneId,fundReq) {
            return $http.get('/api/milestone/updateFundReq/' + milestoneId+'/'+fundReq).then(handleSuccess, handleError);
        }
        // #Akshay :- 27-07-2017 fund release from blockchain
         function BKCFundReleased(projectId,milestoneId,activityId,fundBudgeted,projectOwner) {
            console.log("projectId app-ser = = ",projectId);
            console.log("milestone app-ser = = ",milestoneId);
            console.log("activityId id app-ser = = ",activityId);
            console.log("projectOwner re app-ser = = ",projectOwner);
            return $http.get('/api/milestone/BKCFundReleased/' + projectId+'/'+milestoneId+'/'+activityId+'/'+fundBudgeted+'/'+projectOwner).then(handleSuccess, handleError);
        }
        // #Akshay :- 27-07-2017 fund request from blockchain
        // #Madhura :- 30-07-2017 send status
         function BKCFundRequest(milestoneId,projectId,activityId,fundReq,status) {
             console.log("activityId app-ser = = ",activityId);
             console.log("milestone app-ser = = ",milestoneId);
             console.log("project id app-ser = = ",projectId);
             console.log("fund re app-ser = = ",fundReq);
             console.log("status in req fund=",status);
            return $http.get('/api/milestone/BKCFundRequest/'+milestoneId+'/'+projectId+'/'+activityId+'/'+fundReq+'/'+status).then(handleSuccess, handleError);
        }

        // #GM 060717 :- Update FundReleased in ProjectMilestone
        function UpdateFundReleased(milestoneId,fundRel) {
            return $http.get('/api/milestone/updateFundRel/' + milestoneId+'/'+fundRel).then(handleSuccess, handleError);
        }

        // #GM 060717 :- Update FundReleased in ProjectMilestone
        function UpdateProofStatus(milestoneId,status) {
            return $http.get('/api/milestone/updateProofStatus/' + milestoneId+'/'+status).then(handleSuccess, handleError);
        }
        function Update(document) {
          console.log('milestone in mil service=',document);
            return $http.put('/api/milestone/'  + document._id, document).then(handleSuccess, handleError);
        }
        //#MG update fundBudgeted
        function UpdateFundBudget(milestoneId,fundBudgeted) {
            return $http.get('/api/milestone/updateFundBudget/'  + milestoneId+'/'+fundBudgeted).then(handleSuccess, handleError);
        }

        function fundAllocateToMilestone(projectId,milestoneId,fundBudgetedMil) {
          //console.log("activity = ",projectId);
            return $http.post('/api/milestone/fundAllocate/' + projectId+'/'+milestoneId+'/'+fundBudgetedMil).then(handleSuccess, handleError);
        }

        //delete milestone
        function Delete(_id,projectId,milestoneId,milestone) {
          console.log("_id = ",_id,projectId);
            return $http.delete('/api/milestone/' +_id+'/'+projectId+'/'+milestoneId+'/'+milestone).then(handleSuccess, handleError);
        }
        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
