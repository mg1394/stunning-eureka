/**
 * Created By :- Madhura
 * Created Date :- 06-07-2017 05:30 pm
 * Version :- 1.1
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('ActivityService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetByProjname= GetByProjname;
        service.Create = Create;
        service.GetAllActivity = GetAllActivity;
        service.GetActivityById = GetActivityById;
        service.UpdateActivity = UpdateActivity;
        service.GetAllActivityByProjectId = GetAllActivityByProjectId;
        service.Delete = Delete;
        return service;

        function GetByProjname(_projId) {
            return $http.get('/api/activity/allByName/' + _projId).then(handleSuccess, handleError);
        }
        function Create(project) {
          //console.log("project = ",project);
            return $http.post('/api/activity/create', project).then(handleSuccess, handleError);
        }
        function GetAllActivity() {
            return $http.get('/api/activity/all').then(handleSuccess, handleError);
        }

        function GetAllActivityByProjectId(projectId) {
            return $http.get('/api/activity/activityByProjectId/'+projectId).then(handleSuccess, handleError);
        }

        function GetActivityById(milestoneId) {
            return $http.get('/api/activity/activityById/'+milestoneId).then(handleSuccess, handleError);
        }

        function UpdateActivity(activity) {
          console.log('app-serv activity=',activity);
            return $http.post('/api/activity/updateActivity',activity).then(handleSuccess, handleError);
        }

        function Delete(_id,projectId,milestoneId,activityId,milestoneName,activityName) {
          //console.log("_id = ",documet);
            return $http.delete('/api/activity/' +_id+'/'+projectId+'/'+milestoneId+'/'+activityId+'/'+milestoneName+'/'+activityName).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
