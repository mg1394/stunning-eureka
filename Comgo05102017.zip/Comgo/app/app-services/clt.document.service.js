/**
 * Created By :- Mamta Bhardwaj
 * Created Date :- 09-06-2017 11:30 am
 * Version :- 1.0
 * Updated By :- Akshay
 * Updated Date :- 30-07-2017 11:30 am
 * Version :- 2.0.0 Add proof hash to blockchain 
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('DocumentService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetCurrent = GetCurrent;
        service.GetAllDocument = GetAllDocument;
        service.GetById = GetById;
        service.GetByProjname = GetByDocname;
        service.Create = Create;
        service.Update = Update;
        service.Delete = Delete;

        return service;

        function GetCurrent() {
            return $http.get('/api/documents/current').then(handleSuccess, handleError);
        }

        function GetAllDocument(milestoneId,projectId) {
            return $http.get('/api/documents/all/'+milestoneId+'/'+projectId).then(handleSuccess, handleError);
        }

        function GetById(_id) {
            return $http.get('/api/documents/' + _id).then(handleSuccess, handleError);
        }

        function GetByDocname(documentname) {
            return $http.get('/api/documents/' + documentname).then(handleSuccess, handleError);
        }

        function Create(document) {
          //console.log("document = ",document);
            return $http.post('/api/documents/create', document).then(handleSuccess, handleError);
        }

        function Update(document) {
            return $http.put('/api/documents/' + document._id, document).then(handleSuccess, handleError);
        }

        function Delete(document) {
          //console.log("_id = ",documet);
            return $http.delete('/api/documents/' + document._id).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
