/**
 * Created By :- Akshay
 * Created Date :- 12-06-2017 03:30 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Created Date :- 13-06-2017 11:11 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Created Date :- 14-06-2017 01:00 pm
 * Version :- 1.0
 * Updated By :- Girijashankar
 * Created Date :- 15-06-2017 04:00 pm
 * Version :- 1.0
 * Updated By :- Madhura
 * Created Date :- 11-07-2017 09:00 am
 * Version :- 1.1
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('ProjectDonation', Service);

    function Service($http, $q) {
        var service = {};

        service.GetAllMyProjects = GetAllMyProjects;
        service.GetAllOtherProjects = GetAllOtherProjects;
        service.BKCGetAllFundDetails = BKCGetAllFundDetails;
        service.GetAllProjectDonation = getAllProjectDonation;
        service.GetAllMyDonation= GetAllMyDonation;
        service.BKCGetAllMyDonation= BKCGetAllMyDonation;
        return service;

        // get data from controllers(api folder)
        function BKCGetAllFundDetails() {
            return $http.get('/api/projectdonation/allFunds').then(handleSuccess, handleError);
        }

        function GetAllMyDonation() {
            return $http.get('/api/projectdonation/myFunds').then(handleSuccess, handleError);
        }
        function BKCGetAllMyDonation() {
            return $http.get('/api/projectdonation/BKCMyFunds').then(handleSuccess, handleError);
        }
        // get data from controllers(api folder)
        function getAllProjectDonation() {
            return $http.get('/api/projectdonation/allGroupBy').then(handleSuccess, handleError);
        }

        //send donorid and get data from controllers(api folder)
        function GetAllMyProjects() {
            return $http.get('/api/projectdonation/allMyProject' ).then(handleSuccess, handleError);
        }

        //send donorid and receive data of other project and get data from controllers(api folder)
        function GetAllOtherProjects() {
            return $http.get('/api/projectdonation/allOtherProject' ).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
