/**
 * Created By :- Girijashankar Mishra
 * Created Date :- 08-05-2017 16:30 pm
 * Version :- 1.0
 * Created By :- Akshay
 * Created Date :- 09-06-2017 04:30 pm
 * Version :- 1.0
 * updated By :- Akshay
 * updated Date :- 28-07-2017 09:30 pm
 * Version :- 2.0.0 Add blockchain funnction
 * Updated By :- Akshay
 * Updated Date :- 17-08-2017 01:43 pm
 * Version :- 2.0.2 #project validation to blockchain
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('ProjectService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetCurrent = GetCurrent;
        service.GetAll = GetAll;
        service.GetById = GetById;
        service.GetByProjname = GetByProjname;
        service.GetByProjID = GetByProjID;
        service.Create = Create;
        service.updateMilestoneStatus = updateMilestoneStatus;
        service.saveRemarks = saveRemarks;
        service.BKCpublishProject = BKCpublishProject;
        service.Delete = Delete;
        service.UpdateProject=UpdateProject;
        service.BKCProjectValidation = BKCProjectValidation;

        return service;

        function GetCurrent() {
            return $http.get('/api/projects/current').then(handleSuccess, handleError);
        }

        function GetAll() {
            return $http.get('/api/projects/all').then(handleSuccess, handleError);
        }

        function GetById(_id) {
            return $http.get('/api/projects/' + _id).then(handleSuccess, handleError);
        }

        function GetByProjname(_projectName) {
            return $http.get('/api/projects/allByName/' + _projectName).then(handleSuccess, handleError);
        }

        function GetByProjID(projId) {
            return $http.get('/api/projects/allById/' + projId).then(handleSuccess, handleError);
        }

        function Create(project) {
          //console.log("project = ",project);
            return $http.post('/api/projects/create', project).then(handleSuccess, handleError);
        }

        function BKCpublishProject(projId, status,milestoneId,fundBudgeted) {
             console.log("publ;ish app ser proj id =",projId);
             console.log("publ;ish app ser status id =",status);
             console.log("publ;ish app ser milestoneId id =",milestoneId);
             console.log("publ;ish app ser fundBudgeted =",fundBudgeted);
             return $http.put('/api/projects/BKCpublishProject/'+projId+'/'+status+'/'+milestoneId+'/'+fundBudgeted).then(handleSuccess, handleError);
        }
        function updateMilestoneStatus(projId, status) {
          console.log("publ;ish app ser proj id =",projId);
          console.log("publ;ish app ser status id =",status);
            return $http.put('/api/projects/updateMilestoneStatus/'+projId+'/'+status).then(handleSuccess, handleError);
        }

        function BKCProjectValidation(projectId,milestoneId,activityId,check) {
            console.log("publ;ish app ser proj id =",projectId);
            console.log("publ;ish app ser status id =",milestoneId);
            console.log("publ;ish app ser status id =",check);
               return $http.post('/api/projects/BKCProjectValidation/'+projectId+'/'+milestoneId+'/'+activityId+'/'+check).then(handleSuccess, handleError);
          }
        function saveRemarks(projId, remarks) {
          console.log("publ;ish app ser proj id =",projId);
          console.log("publ;ish app ser remarks id =",remarks);
            return $http.put('/api/projects/saveRemarks/'+projId+'/'+remarks).then(handleSuccess, handleError);
        }

        function UpdateProject(project) {
            return $http.post('/api/projects/updateProject',project).then(handleSuccess, handleError);
        }

        function Delete(project) {
          //console.log("_id = ",project);
            return $http.delete('/api/projects/' + project._id).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
