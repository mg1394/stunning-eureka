/**
 * Created By :- Mamta
 * Created Date :- 10-08-2017 14:25 pm
 * Version :- 1.0
 */

(function() {
    'use strict';

    angular
        .module('app')
        .factory('projecttype', Service);

    function Service($http, $q) {
        var service = {};

        service.GetAll = GetAll;

        return service;


        function GetAll() {
            return $http.get('/api/projecttype/all').then(handleSuccess, handleError);
        }

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();