/**
 * Created By :- Madhura
 * Created Date :- 29-06-2017 10:30 am
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('FileUpload', Service);

    function Service($http, $q) {

        var service = {};


        service.uploadFileToUrl = uploadFileToUrl;
        service.uploadImageToUrl = uploadImageToUrl;

        return service;

        function uploadFileToUrl(file,uploadUrl,milestoneId,projectId){
          var fd = new FormData();
          fd.append('file', file);
          var paramData = {'milestoneId': milestoneId, 'projectId': projectId };


              return     $http.post(uploadUrl, fd, {
                      transformRequest: angular.identity,
                      headers: {'Content-Type': undefined},
                      params: paramData
                   }).success(function(hash){
                     console.log('api service hash = ',hash);
                     return hash;
                   }).error(function(error){
                     console.log('api service error = ',error);
                      return error;
                   });

        }

        function uploadImageToUrl(file,uploadUrl,projectId){
          console.log('app service img=', file);
          var fd = new FormData();
          fd.append('file', file);
           var paramData = {'projectId': projectId };


              return     $http.post('/api/uploadImage/',fd, {
                      transformRequest: angular.identity,
                      headers: {'Content-Type': undefined},
                      params: paramData
                   }).then(handleSuccess, handleError);

        }
        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
