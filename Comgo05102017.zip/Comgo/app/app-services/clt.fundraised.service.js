/**
 * Created By :- Akshay
 * Created Date :- 14-06-2017 06:58 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('FundRaisedService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetAll = GetAll;
        service.GetAllFundRaisedDetails = GetAllFundRaisedDetails;

        return service;

        function GetAll(projId) {
            return $http.get('/api/fundraised/all/'+ projId).then(handleSuccess, handleError);
        }

        function GetAllFundRaisedDetails(projId) {
            return $http.get('/api/fundraised/allFundRaisedByProjectId/'+ projId).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
