/**
 * Created By :- Mamta Bhardwaj
 * Created Date :- 09-06-2017 11:30 am
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .factory('ProofService', Service);

    function Service($http, $q) {
        var service = {};

        service.GetCurrent = GetCurrent;
        service.GetAllProof = GetAllProof;
        service.GetById = GetById;
        service.GetByProjname = GetByDocname;
        service.Create = Create;
        service.Update = Update;
        service.Delete = Delete;

        return service;

        function GetCurrent() {
            return $http.get('/api/documents/current').then(handleSuccess, handleError);
        }

        function GetAllProof(milestoneId,projectId) {
            return $http.get('/api/proofs/all/'+milestoneId+'/'+projectId).then(handleSuccess, handleError);
        }

        function GetById(_id) {
            return $http.get('/api/documents/' + _id).then(handleSuccess, handleError);
        }

        function GetByDocname(documentname) {
            return $http.get('/api/documents/' + documentname).then(handleSuccess, handleError);
        }

        function Create(proof) {
          //console.log("document = ",document);
            return $http.post('/api/proofs/create', proof).then(handleSuccess, handleError);
        }

        function Update(document) {
            return $http.put('/api/documents/' + document._id, document).then(handleSuccess, handleError);
        }

        function Delete(document) {
          //console.log("_id = ",documet);
            return $http.delete('/api/documents/' + document._id).then(handleSuccess, handleError);
        }

        // private functions

        function handleSuccess(res) {
            return res.data;
        }

        function handleError(res) {
            return $q.reject(res.data);
        }
    }

})();
