/**
 * Created By :- Akshay
 * Created Date :- 09-06-2017 09:30 pm
 * Version :- 1.0
 * Updated By :- Mamta
 * Updated Date :- 30-07-2017 10:30 pm
 * Version :- 1.1
 */
(function() {
    'use strict';

    angular
        .module('app', ['ui.router', 'chart.js', 'ngFileUpload', 'AngularChart', 'angularUtils.directives.dirPagination', 'angular-flexslider'])
        .config(config)
        .run(run);

    function config($stateProvider, $urlRouterProvider) {
        // default route
        $urlRouterProvider.otherwise("/");

        $stateProvider
            .state('project', {
                url: '/project',
                templateUrl: 'project/project.html',
                controller: 'Project.ProjectController',
                controllerAs: 'vm',
                data: { activeTab: 'project' }
            })
            .state('account', {
                url: '/account',
                templateUrl: 'account/account.html',
                controller: 'Account.AccountController',
                controllerAs: 'vm',
                data: { activeTab: 'account' }
            })
            .state('ngo', {
                url: '/ngo',
                templateUrl: 'ngo/ngo.html',
                controller: 'Ngo.NgoController',
                controllerAs: 'vm',
                data: { activeTab: 'ngo' }
            })
            .state('activity', {
                url: '/activity',
                templateUrl: 'activity/activity.html',
                controller: 'Activity.ActivityController',
                controllerAs: 'vm',
                data: { activeTab: 'activity' }
            })
            .state('addproject', {
                url: '/addproject/:projName/:projId/:fundGoal/:description/:projectType/:ngo/:currency/:country/:startDate/:endDate/:toDo',
                templateUrl: 'addproject/addproject.html',
                controller: 'AddProject.AddProjectController',
                controllerAs: 'vm',
                data: { activeTab: 'addproject' }
            })
            .state('addmilestone', {
                url: '/addmilestone/:projName/:projId/:fundGoal/:description/:projectType/:ngo/:status/:startDate/:endDate',
                templateUrl: 'addmilestone/addmilestone.html',
                controller: 'AddMilestone.AddMilestoneController',
                controllerAs: 'vm',
                data: { activeTab: 'addmilestone' }
            })
            .state('addactivity', {
                url: '/addactivity/:milestoneId/:projectId/:milestone/:startDate/:endDate/:fundBudgeted/:fundGoal/:remainingBal',
                templateUrl: 'addactivity/addactivity.html',
                controller: 'AddActivity.AddActivityController',
                controllerAs: 'vm',
                data: { activeTab: 'addactivity' }
            })
            .state('ngoproof', {
                url: '/ngoproof/:milestoneId/:projectId/:milestoneName/:milestoneActivity/:activityId/:total/:projectName/:actfundBudgeted/:currency',
                templateUrl: 'ngoproof/ngoproof.html',
                controller: 'Ngoproof.NgoproofController',
                controllerAs: 'vm',
                data: { activeTab: 'ngoproof' }
            })
            .state('submittedproof', {
                url: '/submittedproof/:milestoneId/:projectId/:milestoneActivity/:Amount/:activityId',
                templateUrl: 'submittedproof/submittedproof.html',
                controller: 'Submittedproof.SubmittedproofController',
                controllerAs: 'vm',
                data: { activeTab: 'submittedproof' }
            })
            .state('requestfund', {
                url: '/requestfund/:activityId/:milestoneId/:projectId/:fundBudgeted/:fundAllocated/:activityName/:projectName/:startDate/:endDate/:status',
                templateUrl: 'requestfund/requestfund.html',
                controller: 'Requestfund.RequestfundController',
                controllerAs: 'vm',
                data: { activeTab: 'requestfund' }
            })
            .state('uploadeddocs', {
                url: '/uploadeddocs/:milestoneId/:projectId/:milestoneName/:milestoneActivity/:fundRequested/:projectName/:description/:activityId/:actfundBudgeted/:currency',
                templateUrl: 'uploadeddocs/uploadeddocs.html',
                controller: 'Uploadeddocs.UploadeddocsController',
                controllerAs: 'vm',
                data: { activeTab: 'uploadeddocs' }
            })
            .state('home', {
                url: '/home',
                templateUrl: 'home/home.html',
                controller: 'Home.HomeController',
                controllerAs: 'vm',
                data: { activeTab: 'home' }
            })
            .state('donor', {
                url: '/donor/ViewProjects',
                templateUrl: 'donor/viewproject/viewproject.html',
                controller: 'Donor.DonorController',
                controllerAs: 'vm',
                data: { activeTab: 'donor' }
            })
            // VN 150817 CONTROLLER FOR OTHER PROJECTS
            .state('otherPro', {
                url: '/donor/OtherProjects',
                templateUrl: 'donor/viewproject/otherProject.html',
                controller: 'other.OtherController',
                controllerAs: 'vm',
                data: { activeTab: 'donor' }
            })
            // VN 150817 CONTROLLER FOR OTHER PROJECTS ENDS HERE
            .state('prePublishProject', {
                url: '/donor/prePublishProject',
                templateUrl: 'donor/viewproject/prePublishProject.html',
                controller: 'Project.PrePublishProject',
                controllerAs: 'vm',
                data: { activeTab: 'donor' }
            })
            .state('milestone', {
                url: '/donor/ViewProjects/ViewMilestones/:projName/:projId/:fundRaised/:myDonation/:fundGoal/:description/:status/:projectOwner/:startDate/:endDate/:currency/:getDataFrom',
                templateUrl: 'donor/viewproject/viewmilestones/milestone.html',
                controller: 'Milestone.MilestoneController',
                controllerAs: 'vm',
                data: { activeTab: 'milestone' }
            })
            .state('donate', {
                url: '/donor/donate/:projName/:projId/:fundGoal/:fundRaised/:fundBalance',
                templateUrl: 'donor/donate/donate.html',
                controller: 'Donate.DonateController',
                controllerAs: 'vm',
                data: { activeTab: 'donate' }
            })
            .state('ccgateway', {
                url: '/ccgateway',
                templateUrl: 'donor/donate/ccgateway.html',
                controller: 'Donate.ccgatewayController',
                controllerAs: 'vm',
                data: { activeTab: 'ccgateway' }
            })
            .state('cryptogateway', {
                url: '/cryptogateway',
                templateUrl: 'donor/donate/cryptogateway.html',
                controller: 'Donate.ccgatewayController',
                controllerAs: 'vm',
                data: { activeTab: 'cryptogateway' }
            })
            .state('billdesk', {
                url: '/billdesk',
                templateUrl: 'donor/donate/billdesk.html',
                controller: 'Donate.ccgatewayController',
                controllerAs: 'vm',
                data: { activeTab: 'billdesk' }
            })
            .state('otp', {
                url: '/otp/:projectDonation',
                templateUrl: 'donor/donate/otp.html',
                controller: 'Donate.otpController',
                controllerAs: 'vm',
                data: { activeTab: 'otp' }
            })
            .state('mydonation', {
                url: '/donor/mydonation/:projId/:donorId/:projName/:myDonation',
                templateUrl: 'donor/mydonation/mydonation.html',
                controller: 'Mydonation.MydonationController',
                controllerAs: 'vm',
                data: { activeTab: 'mydonation' }
            })
            .state('fundraised', {
                url: '/donor/fundraised/:projId/:projName/:fundRaised',
                templateUrl: 'donor/fundraised/fundraised.html',
                controller: 'FundRaised.FundRaisedController',
                controllerAs: 'vm',
                data: { activeTab: 'fundraised' }
            })
            .state('document', {
                url: '/donor/document/:milestoneId/:projectId/:milestoneName/:projectName/:activityId',
                templateUrl: 'donor/document/document.html',
                controller: 'Document.DocumentController',
                controllerAs: 'vm',
                data: { activeTab: 'document' }
            })
            .state('audit', {
                url: '/audit/:getDataFrom/:projectId/:projectName/:fundGoal/:projectType/:fundRaised/:currency',
                templateUrl: 'audit/audit.html',
                controller: 'Audit.AuditController',
                controllerAs: 'vm',
                data: { activeTab: 'audit' }
            })
            .state('transactionSummary', {
                url: '/transactionSummary/:txnId',
                templateUrl: 'audit/transactionSummary.html',
                controller: 'TransactionSummary.TransactionSummaryController',
                controllerAs: 'vm',
                data: { activeTab: 'transactionSummary' }
            })
            .state('logout', {
                url: '/logout',
                controller: 'Logout.LogoutController',
                controllerAs: 'vm',
                data: { activeTab: 'login' }
            });
    }

    function run($http, $rootScope, $window) {
        // add JWT token as default auth header
        $http.defaults.headers.common['Authorization'] = 'Bearer ' + $window.jwtToken;

        // update active tab on state change
        $rootScope.$on('$stateChangeSuccess', function(event, toState, toParams, fromState, fromParams) {
            $rootScope.activeTab = toState.data.activeTab;
        });
    }

    // manually bootstrap angular after the JWT token is retrieved from the server
    $(function() {
        // get JWT token from server
        $.get('/app/token', function(token) {
            window.jwtToken = token;

            angular.bootstrap(document, ['app']);
        });

        // BlockChain Services to Create Channel
        /*  $.get('/app/createChannel', function (createChannel) {
              console.log('createChannel = ',createChannel);
              // BlockChain Services to Join Channel
              $.get('/app/joinChannel', function (joinChannel) {
                  //window.jwtToken = token;
                  console.log('joinChannel = ',joinChannel);
                  // BlockChain Services to Install ChainCode
                  $.get('/app/installChainCode', function (installChainCode) {
                      //window.jwtToken = token;
                      console.log('installChainCode = ',installChainCode);
                      // BlockChain Services to Instantiate ChainCode
                      $.get('/app/instantiateChainCode', function (instantiateChainCode) {
                          //window.jwtToken = token;
                          console.log('instantiateChainCode = ',instantiateChainCode);
                          $.get('/app/initDonor', function (initDonor) {
                              //window.jwtToken = token;
                              console.log('initDonor = ',initDonor);
                              $.get('/app/initProject', function (initProject) {
                                  //window.jwtToken = token;
                                  console.log('initProject = ',initProject);
                                  angular.bootstrap(document, ['app']);
                              });
                          });
                      });
                  });
                  //angular.bootstrap(document, ['app']);
              });
          });*/
    });
})();