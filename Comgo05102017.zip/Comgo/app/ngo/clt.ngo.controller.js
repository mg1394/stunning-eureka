/**
 * Created By :- Madhura
 * Created Date :- 30-06-2017 02:50 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('Ngo.NgoController', Controller);
    //inject services
    function Controller(ProjectService,SessionService,ProjectDonation,$scope,$state,$rootScope) {
        var vm = this;
        vm.projectdonationDummy={'ProjectName':'KenyaSchoolProject',
                                 'ProjectType':'educational',
                                 'ProjectDescription':'description',
                                 'FundGoal':'20000',
                                'FundRaised':'10000',
                                'status':'In progress'}
        $rootScope.ngoData=vm.projectdonationDummy;
        console.log(vm.projectdonationDummy);
       // var donorId = null;
        SessionService.GetSessionDetails().then(function (session) {
            $scope.donorId = session.username;
        });
        //Go to milestone screen and pass projName and projId
        $scope.showMilestones = function (val1,val2,val3,val4,val5,val6) {

            var fundRaised = vm.fundRaised;
            for (var i = 0; i < fundRaised.length; i++) {
                var fundId = fundRaised[i].projectId;
                if(fundId==val2){
                    val3 = fundRaised[i].sum;
                }

            }
            if(typeof val4 === 'undefined'){
                val4 = 0;
            }

            $state.go('milestone',{projName:val1,projId:val2,fundRaised:val3,myDonation:val4,fundGoal:val5,description:val6});
        };

        $scope.showNgoMilestone= function(val1,val2,val3,val4,val5,val6){
           $state.go('activity',{projName:val1,projId:val2,fundRaised:val3,myDonation:val4,fundGoal:val5,description:val6});
        };


        //Go to myDonation screen and pass donorid and projId
        $scope.myDonation = function (val1,val2,val4) {
            var val3 = $scope.donorId;

            $state.go('mydonation',{projId:val1,donorId:val3,projName:val2,myDonation:val4});
        };

        //Go to fundraised screen and pass donorid and projId
        $scope.fundRaised = function (val1,val2,val3) {
            $state.go('fundraised',{projId:val1,projName:val2,fundRaised:val3});
        };

        //Fetch data from the collection(project) and store in the object
        var getAllProject = function() {
            ProjectService.GetAll().then(function (proj) {
                vm.project = proj;
            });
        };

           //Fetch data from the collection(projectdonation) based on projId and store in the objects
            var getFundRaised = function() {
                ProjectDonation.GetAllFundDetails().then(function (funds) {
                    vm.fundRaised = funds;
                    var obj ={};
                    var fundRaisedDetails = [];
                    //console.log('funds  = ',funds);
                    ProjectService.GetAll().then(function (proj) {
                        //console.log('Project  = ',proj);
                        if(proj.length > funds.length ){
                            for (var i = 0; i < proj.length; i++) {
                                var projectId = proj[i]._id;
                                var fundsProjId = '';
                                var amount = 0.00;

                                for(var j = 0; j < funds.length; j++){
                                    var fundsProjId = funds[j].projectId;
                                    var amount = funds[j].sum;

                                    if(i==0){
                                        obj[fundsProjId] = amount;
                                    } else if(fundsProjId == projectId){
                                        obj[projectId] = amount;
                                    } else if(!obj[projectId]){
                                        obj[projectId] = 0.00;
                                    }
                                }
                                if(funds.length==0){
                                    obj[projectId] = 0.00;
                                }

                            }

                            for (var k = 0; k < proj.length; k++) {
                                var projectId = proj[k]._id;
                                var mySingleFund = {};

                                if(obj[projectId]){
                                    mySingleFund['projectId'] = proj[k]._id;
                                    mySingleFund['sum'] = obj[projectId];

                                    fundRaisedDetails.push(mySingleFund);
                                }else if(obj[projectId] == 0){
                                    mySingleFund['projectId'] = proj[k]._id;
                                    mySingleFund['sum'] = obj[projectId];

                                    fundRaisedDetails.push(mySingleFund);
                                }
                             }
                            vm.fundRaised = fundRaisedDetails;
                        } else {
                            vm.fundRaised = funds;
                        }
                        //console.log('Funds  = ',vm.fundRaised);
                    });

                });
            };

            getFundRaised();

//Fetch amount from the Project donation collection and store in the object
        var getMyProject = function() {

            ProjectDonation.GetAllMyProjects().then(function (myProj) {
                vm.projectdonation = myProj;
                console.log('myProj==',myProj);
                //vm.projectdonation={'ProjectName':'xyz'}
                var myProjectDetails = [];
                var obj = {};
                var mySingleProject = {};
                SessionService.GetSessionDetails().then(function (session) {
                    var donorId = session.username;
                    for (var j = 0; j < myProj.length; j++) {
                        //console.log("ProjectId = ",myProj[j].projectId._id.toString());
                        //console.log("ProjectAmount = ",myProj[j].amount);

                        if (j == "0") {
                            var key = myProj[j].projectId._id;
                            var value = myProj[j].amount;
                            obj[key] = value;
                            //console.log("Obj All IF = ",obj);
                        } else {
                            var key = myProj[j].projectId._id;
                            //console.log(obj.hasOwnProperty(key));
                            if (obj[key]) {

                                var amountExisting = obj[key];
                                var amount = myProj[j].amount;

                                var value = amountExisting + amount;
                                delete obj[key];

                                obj[key] = value;
                                //console.log("Obj All Else = ",obj);
                            } else {
                                var value = myProj[j].amount;
                                obj[key] = value;
                            }
                        }
                    }
                    //console.log('All Obj = ',obj);
                    for (var j = 0; j < myProj.length; j++) {
                        var key = myProj[j].projectId._id;

                        if (obj[key]) {
                            var mySingleProject = {};
                            mySingleProject['projectName'] = myProj[j].projectId.projectName;
                            mySingleProject['projectType'] = myProj[j].projectId.projectType;
                            mySingleProject['description'] = myProj[j].projectId.description;
                            mySingleProject['fundGoal'] = myProj[j].projectId.fundGoal;
                            mySingleProject['myDonation'] = obj[key];
                            mySingleProject['status'] = myProj[j].projectId.status;
                            mySingleProject['projectId'] = myProj[j].projectId._id;

                            if (myProjectDetails.length > 0) {
                                var len = myProjectDetails.length;
                                if (myProjectDetails[len - 1].projectId != key) {
                                    myProjectDetails.push(mySingleProject);
                                }
                            } else if (myProjectDetails.length == 0) {
                                myProjectDetails.push(mySingleProject);
                            }
                        }
                    }
                    vm.projectdonation = myProjectDetails;
                    //vm.projectdonation={'ProjectName':'xyz'}
                });

            });
        };



        var getOtherProject = function() {
            ProjectService.GetAll().then(function (proj) {
                 vm.otherproject = proj;
                 var myProjectDetails = [];
                ProjectDonation.GetAllProjectDonation().then(function (projDonation) {
                    //console.log('GetAllProjectDonation = ',projDonation);
                    var obj = {};
                    var tempObj = {};
                     SessionService.GetSessionDetails().then(function (session) {
                         var donorId = session.username;
                         for (var i = 0; i < proj.length; i++) {
                             var projectId = proj[i]._id;

                             for (var j = 0; j < projDonation.length; j++) {
                                 var projectIdDon = projDonation[j].projectId;
                                 var donorIdDon = projDonation[j].donorId;
                                 //console.log('projectIdDon = ',projectIdDon,' donorIdDon = ',donorIdDon);
                                 //console.log('projectId = ',projectId,' donorId = ',donorId);
                                 if (projectIdDon == projectId && donorIdDon == donorId) {
                                     tempObj[projectIdDon] = donorIdDon;
                                 } else if (projectIdDon == projectId && donorIdDon != donorId) {
                                     if (tempObj.length == 0) {
                                         tempObj[projectIdDon] = donorIdDon;
                                     } else {
                                         if (!tempObj[projectIdDon]) {
                                             obj[projectIdDon] = donorIdDon;
                                         } else {
                                             delete obj[projectIdDon];
                                         }
                                     }

                                 } else {
                                     //console.log(projectIdDon);
                                     //console.log(tempObj[projectIdDon]);
                                     if (!tempObj[projectIdDon]) {
                                         obj[projectIdDon] = donorIdDon;
                                     } else {
                                         delete obj[projectIdDon];
                                     }
                                 }

                                 if (obj[projectIdDon] == donorId) {
                                     //console.log(projectIdDon, '  Deleted');
                                     delete obj[projectIdDon];
                                 }

                                 if(tempObj[projectIdDon] && obj[projectIdDon]){
                                     delete obj[projectIdDon];
                                 }

                                 //console.log('tempObj = ',tempObj);
                                 //console.log('obj = ',obj);
                             }
                         }

                         for (var k = 0; k < proj.length; k++) {
                             var projectId = proj[k]._id;
                             //console.log('getAllProject = ',proj);
                             if (!tempObj[projectId]) {
                                if (obj[projectId]) {
                                    var mySingleProject = {};
                                    mySingleProject['projectName'] = proj[k].projectName;
                                    mySingleProject['projectType'] = proj[k].projectType;
                                    mySingleProject['description'] = proj[k].description;
                                    mySingleProject['fundGoal'] = proj[k].fundGoal;
                                    mySingleProject['status'] = proj[k].status;
                                    mySingleProject['projectId'] = proj[k]._id;
                                    myProjectDetails.push(mySingleProject);
                                } else {
                                        var mySingleProject = {};
                                        mySingleProject['projectName'] = proj[k].projectName;
                                        mySingleProject['projectType'] = proj[k].projectType;
                                        mySingleProject['description'] = proj[k].description;
                                        mySingleProject['fundGoal'] = proj[k].fundGoal;
                                        mySingleProject['status'] = proj[k].status;
                                        mySingleProject['projectId'] = proj[k]._id;
                                        myProjectDetails.push(mySingleProject);
                                }
                            }
                         }
                     });
                });
                vm.otherproject = myProjectDetails;
            });
        };

        //call my project's data
        getMyProject();

        //call other project's data
        getOtherProject();

        //call function getAllProject();
        getAllProject();
    }
})();
