/**
 * Created By :- Madhura
 * Created Date :- 30-06-2017 12:57 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('NavController', Controller);

    function Controller($stateParams,$state,SessionService,$scope,$http,$rootScope) {
      var vm = this;


      SessionService.GetSessionDetails().then(function(session){
        //$rootScope.username=username;
        $rootScope.role=session.role;
        $rootScope.username = session.username;
        //console.log("$rootScope.username=",$rootScope.username);
        console.log("nav cont $rootScope.role=",$rootScope.role);
        //view project as landing page
      if($rootScope.role=='foundation'){
           $state.go('prePublishProject');
         }
        if($rootScope.role=='board'){
           $state.go('prePublishProject');
         }
         if($rootScope.role=='ngo'){
           $state.go('donor');
         }
      },
      function(error){

      });
      
      $state.go('donor');

       vm.model = {selected: {}};
    }

})();
