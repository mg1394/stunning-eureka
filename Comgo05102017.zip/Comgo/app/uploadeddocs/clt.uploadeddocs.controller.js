/**
 * Created By :- Madhura
 * Created Date :- 01-07-2017 11:00 am
 * Version :- 1.0
 * Updated By :- Madhura
 * Created Date :- 08-07-2017 04:11 pm
 * Version :- 1.0.2
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('Uploadeddocs.UploadeddocsController', Controller);

    function Controller($stateParams, $state, $rootScope, Upload, FileUpload, $timeout, DocumentService, SessionService, ProofService, InvoiceService, FlashService, $scope, $http, currency) {

        var vm = this;
        vm.role = null;
        SessionService.GetSessionDetails().then(function(session) {
                vm.role = session.role;

            },
            function(error) {

            });

        //breadcrumbs
        $scope.doTheBack = function() {
            window.history.back();
        };

        vm.hash = null;
        vm.uploadFile = function(myFile) {
            console.log('file=', myFile);
            var file = myFile;
            var uploadUrl = "/savedata";
            FileUpload.uploadFileToUrl(file, uploadUrl).then(function(response) {
                console.log('hashed Data = ', response);
                console.log('hashed Data = ', response.data);
                vm.hash = response.data;
            });
        };
        vm.model = { selected: {} };
        vm.projectName = $stateParams.projectName;
        console.log('$stateParams.projectName', $stateParams.projectName);
        vm.milestoneName = $stateParams.milestoneName;
        vm.milestoneId = $stateParams.milestoneId;
        vm.projectId = $stateParams.projectId;
        vm.documentName = vm.fileHashValue;
        vm.currency = $stateParams.currency;
        vm.milestoneActivity = $stateParams.milestoneActivity;
        console.log('$stateParams.milestoneActivity', $stateParams.milestoneActivity);
        vm.activityId = $stateParams.activityId;
        vm.activityAmount = $stateParams.fundRequested;
        console.log('vm.currency=', $stateParams.currency);
        vm.description = $stateParams.description;
        vm.actfundBudgeted = $stateParams.actfundBudgeted;
        //#Akshay :(05-07-2017)  go to view document page based on activity
        $scope.viewDocumentByActivity = function(val1, val2, val3) {
            val1 = $stateParams.milestoneId;
            val2 = $stateParams.projectId;
            val3 = $stateParams.milestoneActivity;
            var activityId = $stateParams.activityId;
            console.log('val1*********** = ', activityId);
            $state.go('submittedproof', { milestoneId: val1, projectId: val2, milestoneActivity: val3, activityId: activityId });
        }

        $scope.submitProof = function(val1, val2, val3, val4, val5, val6, val7, val8, val9) {
            val1 = $stateParams.milestoneId;
            val2 = $stateParams.projectId;
            var activityId = $stateParams.activityId;
            console.log('activityId submimt proof*********** = ', activityId);
            console.log('currency= ***= ', currency);
            val4 = $stateParams.milestoneActivity;
            $state.go('ngoproof', { milestoneId: val1, projectId: val2, milestoneName: val3, milestoneActivity: val4, total: val5, activityId: activityId, projectName: vm.projectName, actfundBudgeted: vm.actfundBudgeted, currency: vm.currency });
        };
        //Fetch all the document from the collection and store in the object
        var getAllDocument = function() {
            var val1 = $stateParams.activityId;
            console.log('val1********', val1);
            var val2 = $stateParams.projectId;

            DocumentService.GetAllDocument(val1, val2).then(function(doc) {
                console.log('doc', )
                vm.document = doc;

            });
            ProofService.GetAllProof(val1, val2).then(function(proof) {
                vm.proof = proof;
                vm.noOfDocuments = proof.length;
            });
        };

        var getAllDocumentList = function() {
            // var val1 =  $stateParams.milestoneId;
            var val1 = $stateParams.projectId;
            ProofService.GetAllDocumentByPropjectId(val1).then(function(doc) {
                vm.document = doc;
                console.log("vm.document==== = ", vm.document);
            });
        };

        var getAllCurrency = function() {
            currency.GetAll().then(function(proj) {
                vm.currency = proj;
            });
        };

        var getAllInvoicesById = function(activityId) {
            InvoiceService.GetInvoiceById(activityId).then(function(inv) {
                vm.invoices = inv;
                var sum = 0;
                for (var i = 0; i < inv.length; i++) {
                    var amount = inv[i].total;
                    sum = sum + amount;
                }
                vm.grandTotal = sum;
                console.log('vm.invoices by id=', vm.invoices);
                if (vm.invoices == 'null') {
                    FlashService.Error('No Expense item added.');
                } else if (vm.invoices.length == 0) {
                    FlashService.Error('No Expense item added.');
                }
            });
        };

        //getAllDocumentList();
        getAllInvoicesById($stateParams.activityId);
        getAllDocument();
        getAllCurrency();
        //Decides what to show based on user input
        vm.getTemplate = function(doc) {
            if (proj._id === vm.model.selected._id) {
                return 'editDocument';
            } else return 'displayDocument';
        };

        //Gets the documentdetails for which edit is to be done
        vm.editDocument = function(doc) {
            vm.model.selected = angular.copy(doc);
        };


        //Deletes the selected ocument
        vm.deleteDocument = function(doc) {
            DocumentService.Delete(doc)
                .then(function() {
                    FlashService.Success('Document Deleted');
                    $state.go('document');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
        };

        //Reset the edit documentdetails
        vm.reset = function() {
            vm.model.selected = {};
        };

        //Updates the selected documentdetails
        vm.updateDocument = function(doc) {
            DocumentService.Update(doc)
                .then(function() {
                    FlashService.Success('Document updated');
                    vm.reset();
                    $state.go('document');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
        };

        //Save new document
        vm.saveDocument = function(doc) {

            DocumentService.Create(doc)
                .then(function() {
                    FlashService.Success('Document Saved Successfully');
                    modal.style.display = "none";
                    $state.go('document');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
        };

        vm.saveProof = function(proof) {

            proof.milestoneId = vm.milestoneId;
            proof.projectId = vm.projectId;
            //proof.hash=vm.fileHashValue;
            proof.documentName = vm.FileName;
            var doc = {};
            doc["documentName"] = vm.FileName;
            //doc["documentPath"]=vm.fileHashValue;
            doc["documentPath"] = vm.hash;

            //vm.documentId=null;
            //console.log("vm.fileHashValue",vm.fileHashValue);
            DocumentService.Create(doc)
                .then(function(doc) {
                    //console.log("doc=",doc.insertedIds[0]);
                    vm.documentId = doc.insertedIds[0];
                    proof.documentId = doc.insertedIds[0];
                    proof.milestoneId = vm.milestoneId;
                    proof.projectId = vm.projectId;
                    //console.log('vm.milestoneId=',vm.milestoneId);
                    ProofService.Create(proof)
                        .then(function() {
                            FlashService.Success('Proof Saved Successfully');
                            //modal.style.display = "none";
                            //$state.go('document');
                        })
                        .catch(function(error) {
                            FlashService.Error(error);
                        });

                })
                .catch(function(error) {
                    FlashService.Error(error);
                });



        }

        //#Edited by:- Madhura for base64 conversion
        vm.fileHashValue = null;
        vm.FileName = null;

        vm.getHashValue = function(proof) {
            var files = document.getElementById('file').files;
            console.log('files = ', files);
            console.log('filename=', files[0].name);
            vm.FileName = files[0].name;
            if (files.length > 0) {
                var reader = new FileReader();
                reader.readAsDataURL(files[0]);
                //reader.readAsText(files[0], MD5);
                reader.onload = function() {
                    console.log("Base64=", reader.result);
                    vm.fileHashValue = reader.result;

                };
                reader.onerror = function(error) {
                    console.log('Error: ', error);
                };
            }

        }

    }

})();