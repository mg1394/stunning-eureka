/**
 * Created By :- Madhura
 * Created Date :- 01-07-2017 11:00 am
 * Version :- 1.0
 * Updated By :- Girijashankar
 * Created Date :- 06-07-2017 06:11 pm
 * Version :- 1.0.1
 * Updated By :- Madhura
 * Created Date :- 08-07-2017 04:11 pm
 * Version :- 1.0.2
 * Updated By :- Madhura
 * Created Date :- 12-07-2017 01:11 pm
 * Version :- 1.1.1 inline edit
 * Updated By :- Mamta
 * Created Date :- 30-07-2017 04:21 pm
 * Version :- 1.1.2 prevent negative value
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('Requestfund.RequestfundController', Controller);

    function Controller($stateParams, $state, $filter, $rootScope, InvoiceService, MilestoneService, Upload, FileUpload, $timeout, DocumentService, SessionService, ProofService, FlashService, $scope, $http, currency) {
        //#Mamta :- 04-09-2017 show and hide legends
        //This will hide the DIV by default.
        $scope.IsVisible = false;
        $scope.visible = true;
        $scope.ShowHide = function() {
            //If DIV is visible it will be hidden and vice versa.
            $scope.IsVisible = $scope.IsVisible ? false : true;
            $scope.visible = $scope.visible ? false : true;
        }

        var activityId = $stateParams.activityId;
        var milestoneId = $stateParams.milestoneId;
        var projectId = $stateParams.projectId;
        var fundBudgeted = $stateParams.fundBudgeted;
        console.log("milestoneId 2 = ", milestoneId);
        console.log("projectId 3 = ", projectId);
        console.log("fundBudgeted 4 = ", fundBudgeted);

        $scope.doTheBack = function() {
            window.history.back();
        };

        $scope.reset = function(data) {
            $scope.myForm.$setPristine();
        };

        $scope.addNew = function(personalDetail) {
            $scope.vm.invoices.push({
                'expenseItem': "",
                'description': "",
                'unitCost': "",
                'quantity': "",

            });
            refresh();
            //getAllInvoices();
            getAllInvoicesById($stateParams.activityId);
        };
        $scope.remove = function() {
            var newDataList = [];
            $scope.selectedAll = false;
            angular.forEach($scope.vm.invoices, function(selected) {
                if (!selected.selected) {
                    newDataList.push(selected);
                }
            });
            $scope.vm.invoices = newDataList;
            refresh();
            //getAllInvoices();
            getAllInvoicesById($stateParams.activityId);
        };

        $scope.checkAll = function() {
            if (!$scope.selectedAll) {
                $scope.selectedAll = true;
            } else {
                $scope.selectedAll = false;
            }
            angular.forEach($scope.vm.invoices, function(personalDetail) {
                vm.invoices.selected = $scope.selectedAll;
            });
        };
        $scope.doTheBack = function() {
            window.history.back();
        };

        var refresh = function() {
            $http.get('/requestfund').success(function(response) {
                console.log("I got the data I requested");
                $scope.vm.invoices = response;
                $scope.inv = "";
            });
            //getAllInvoices();
            getAllInvoicesById($stateParams.activityId);
        };

        var vm = this;
        vm.role = null;
        SessionService.GetSessionDetails().then(function(session) {
                vm.role = session.role;

            },
            function(error) {

            });

        vm.hash = null;
        vm.uploadFile = function(myFile) {
            console.log('file=', myFile);
            var file = myFile;
            var uploadUrl = "/savedata";
            FileUpload.uploadFileToUrl(file, uploadUrl).then(function(response) {
                console.log('hashed Data = ', response);
                console.log('hashed Data = ', response.data);
                vm.hash = response.data;
            });
        };
        vm.model = { selected: {} };
        vm.projectName = $stateParams.projectName;


        vm.startDate = $stateParams.startDate.substring(0, 10);
        vm.endDate = $stateParams.endDate.substring(0, 10);
        console.log(" vm.startDate = ", vm.startDate);
        console.log(" vm.endDate = ", vm.endDate);
        vm.stDate = $filter('date')(vm.startDate, "yyyy-MM-dd");
        console.log('vm.stDate==', vm.stDate);

        vm.milestoneName = $stateParams.milestoneName;
        vm.milestoneId = $stateParams.milestoneId;
        vm.projectId = $stateParams.projectId;
        vm.activityName = $stateParams.activityName;
        vm.documentName = vm.fileHashValue;
        vm.status = $stateParams.status;
        console.log(vm.status);
        //vm.fundAllocated=$stateParams.fundAllocated;
        //vm.fundBudgeted=$stateParams.fundBudgeted;
        vm.fundAllocated = $stateParams.fundBudgeted; //fund allocated amount should be same as fund budgeted



        vm.todaysdate = new Date().toISOString().slice(0, 10);;

        $scope.submitProof = function(val1, val2, val3) {
            val1 = $stateParams.milestoneId;
            val2 = $stateParams.projectId
            console.log('milestoneId = ', val1);
            console.log('projectId = ', val2);

            $state.go('ngoproof', { milestoneId: val1, projectId: val2, milestoneName: val3, projectName: vm.projectnm });
        };
        //Fetch all the document from the collection and store in the object
        var getAllDocument = function() {
            var val1 = $stateParams.milestoneId;
            var val2 = $stateParams.projectId;

            DocumentService.GetAllDocument(val1, val2).then(function(doc) {
                vm.document = doc;
            });
            ProofService.GetAllProof(val1, val2).then(function(doc) {
                vm.proof = doc;
            });
        };

        var getAllCurrency = function() {
            currency.GetAll().then(function(proj) {
                vm.currency = proj;
            });
        };

        vm.grandTotal = null;

        /*var getAllInvoices= function(){
          InvoiceService.GetAllInvoice().then(function(inv){
            vm.invoices = inv;
            var sum = 0;
            for(var i =0;i<inv.length;i++){
                var amount = inv[i].total;
                sum = sum+amount;
            }
            vm.grandTotal = sum;
            console.log('vm.invoices =',vm.invoices);
            console.log('vm.invoices.total =',vm.invoices.total);
            $rootScope.expense=vm.invoices.expenseItem;
          });
        };*/

        //#Madhura: Edited to get expense items based on milestoneId(activityId)
        var getAllInvoicesById = function(activityId) {
            console.log('activity+++++', activityId);
            InvoiceService.GetInvoiceById(activityId).then(function(inv) {
                vm.invoices = inv;
                var sum = 0;
                for (var i = 0; i < inv.length; i++) {
                    var amount = inv[i].total;
                    sum = sum + amount;
                }
                vm.grandTotal = sum;
                vm.projectAmt = sum;
                console.log('vm.invoices by id=', vm.invoices);
            });
        };

        getAllInvoicesById($stateParams.activityId);
        //getAllInvoices();
        getAllDocument();
        getAllCurrency();
        //vm.expense=$rootScope.vm.invoices.expenseItem

        //Decides what to show based on user input
        vm.getTemplate = function(inv) {
            if (inv._id === vm.model.selected._id) {
                return 'editDocument';
            } else return 'displayDocument';
        };

        //Gets the documentdetails for which edit is to be done
        vm.editDocument = function(inv) {
            inv.invoiceDate = new Date(inv.invoiceDate);
            vm.model.selected = angular.copy(inv);
            console.log('vm.todaysdate', vm.todaysdate);
        };


        //Deletes the selected ocument
        vm.deleteDocument = function(inv, deletedVal) {
            console.log('deletedVal=', deletedVal);
            if (confirm("Are you sure you want to delete?")) {
                InvoiceService.Delete(inv)
                    .then(function() {
                        FlashService.Success('Expense Item Deleted');
                        getAllInvoicesById($stateParams.activityId);
                        $state.go('requestfund');
                    })
                    .catch(function(error) {
                        FlashService.Error(error);
                    });
            } else {
                console.log('cancelled');
            }
            console.log('deleted inv=', inv);

            getAllInvoicesById($stateParams.activityId);

            vm.fundReq = vm.grandTotal - deletedVal;
            vm.fundRel = vm.grandTotal - deletedVal;
            console.log('vm.fundReq=', vm.fundReq);
            console.log('vm.grandTotal=', vm.grandTotal);
            //vm.updateDocument(inv);
        };

        //Reset the edit documentdetails
        //Reset the edit documentdetails
        vm.reset = function() {
            vm.model.selected = {};
            getAllInvoicesById($stateParams.activityId);
            // getAllMilestoneById(vm.projId); //#MG refresh view
        };
        // vm.reset = function() {
        //     vm.model.selected = {};
        // };

        //Updates the selected documentdetails
        vm.updateDocument = function(inv) {


            //milestoneId is being used as activityId
            inv.activityId = $stateParams.activityId;

            InvoiceService.Update(inv)
                .then(function() {
                    FlashService.Success('Expense Item updated');
                    vm.reset();
                    getAllInvoicesById($stateParams.activityId);
                    //$state.go('requestfund');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });

            getAllInvoicesById($stateParams.activityId);
        };


        //Save new invoice
        vm.saveInvoice = function(inv) {
            if (vm.invoices[0] == null) {
                console.log('inside save inv');
                //milestoneId is being used as activityId
                inv.activityId = $stateParams.activityId;
                console.log('inv.activityId++++++', inv.activityId);
                if (confirm("Are you sure you want to add expense item?")) {
                    InvoiceService.Create(inv).then(function() {
                            console.log('inside save inv create');
                            FlashService.Success('Invoice Saved Successfully');
                            $scope.vm.addInv.expenseItem = '';
                            $scope.vm.addInv.description = '';
                            $scope.vm.addInv.invoiceNo = '';
                            $scope.vm.addInv.invoiceDate = '';

                            getAllInvoicesById($stateParams.activityId);

                        })
                        .catch(function(error) {
                            FlashService.Error(error);
                        });
                } else {
                    console.log('cancelled');
                    $scope.vm.addInv.expenseItem = '';
                    $scope.vm.addInv.description = '';
                    $scope.vm.addInv.invoiceNo = '';
                    $scope.vm.addInv.invoiceDate = '';
                }
            } else {
                FlashService.Error('You can add only one expense item per activity');
                $scope.vm.addInv.expenseItem = '';
                $scope.vm.addInv.description = '';
                $scope.vm.addInv.invoiceNo = '';
                $scope.vm.addInv.invoiceDate = '';
            }
            getAllInvoicesById($stateParams.activityId);

        };

        vm.requestFund = function(val1) {
            if (vm.invoices[0] != null) {
                console.log("im in req .fund ");
                console.log('vm.fundAllocated = ', vm.fundAllocated);
                console.log("activityId req = ", activityId);
                console.log("milestoneId req = ", milestoneId);
                console.log("projectId req = ", projectId);
                console.log("fundBudgeted req = ", fundBudgeted);
                var status = 'Fund Requested';
                console.log('Status req=', status);
                if (confirm("Are you sure you want to request for fund?")) {
                    MilestoneService.BKCFundRequest(milestoneId, projectId, activityId, vm.fundAllocated, status).then(function() {
                        console.log('UpdateFundReleased Done');

                    });
                    setTimeout(function() {
                        window.history.back();
                    }, 3000);
                } else {
                    console.log('cancelled');
                }
            } else {
                console.log('blank data');
            }
        };
        //# mamta :- 30-07-2017 prevent negative value.
        $scope.restrictNegativeNo = function(e) {
            if (e.keyCode == 45) {
                e.preventDefault();
            }
        }
        vm.requestFundMadhura = function() {

            if (vm.projectAmt < vm.fundAllocated) {

                if (confirm("Requested fund is less than fund allocated. do you still want to continue?")) {
                    console.log('vm.fundReq = ', vm.fundReq);
                    console.log('vm.fundRel = ', vm.fundRel);
                    MilestoneService.UpdateFundRequested($stateParams.milestoneId, vm.fundReq).then(function() {
                        console.log('UpdateFundRequested Done');
                    });

                    MilestoneService.UpdateFundReleased($stateParams.milestoneId, vm.fundRel).then(function() {
                        console.log('UpdateFundReleased Done');
                    });

                    /* var status='Not Started';
                     var projid=vm.projectId;
                     MilestoneService.Update(projid, status).then(function (result) {
                       console.log('projid=',projid);
                       console.log('status=',status);
                             FlashService.Success('Milestone updated');
                             //vm.reset();
                             //$state.go('project');
                         });*/

                } else {
                    console.log('You cancelled');
                }

                $state.go('donor');
            }

        };

        vm.saveProof = function(proof) {

            proof.milestoneId = vm.milestoneId;
            proof.projectId = vm.projectId;
            //proof.hash=vm.fileHashValue;
            proof.documentName = vm.FileName;
            var doc = {};
            doc["documentName"] = vm.FileName;
            //doc["documentPath"]=vm.fileHashValue;
            doc["documentPath"] = vm.hash;

            //vm.documentId=null;
            //console.log("vm.fileHashValue",vm.fileHashValue);
            DocumentService.Create(doc)
                .then(function(doc) {
                    console.log("doc=", doc.insertedIds[0]);
                    vm.documentId = doc.insertedIds[0];
                    proof.documentId = doc.insertedIds[0];
                    proof.milestoneId = vm.milestoneId;
                    proof.projectId = vm.projectId;
                    console.log('vm.milestoneId=', vm.milestoneId);
                    ProofService.Create(proof)
                        .then(function() {
                            FlashService.Success('Proof Saved Successfully');
                            //modal.style.display = "none";
                            //$state.go('document');
                        })
                        .catch(function(error) {
                            FlashService.Error(error);
                        });

                })
                .catch(function(error) {
                    FlashService.Error(error);
                });



        }


        vm.fileHashValue = null;
        vm.FileName = null;

        vm.getHashValue = function(proof) {
            var files = document.getElementById('file').files;
            console.log('files = ', files);
            console.log('filename=', files[0].name);
            vm.FileName = files[0].name;
            if (files.length > 0) {
                var reader = new FileReader();
                reader.readAsDataURL(files[0]);
                //reader.readAsText(files[0], MD5);
                reader.onload = function() {
                    console.log("Base64=", reader.result);
                    vm.fileHashValue = reader.result;

                };
                reader.onerror = function(error) {
                    console.log('Error: ', error);
                };
            }

        }

    }

})();