/**
 * Created By :- Akshay
 * Created Date :- 09-06-2017 09:30 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('Mydonation.MydonationController', Controller);

    function Controller(MydonationService,$stateParams,$rootScope,ProjectDonation,$scope) {
        var vm = this;

        var projId=$stateParams.projId;
        var donorId= $stateParams.donorId;
        vm.projectName=$stateParams.projName;
        vm.totalDonation=$stateParams.myDonation;

        //Fetch all the project from the collection and store in the object
        var getAllMyDonation = function(projId,donorId) {
            MydonationService.GetAll(projId,donorId).then(function (mydonation) {
                vm.mydonation = mydonation;
            });
        };
//breadcrumbs
         $scope.doTheBack = function() {
            window.history.back();
        };
        var getAllMyDonationBlockCain = function() {


                      ProjectDonation.BKCGetAllMyDonation().then(function (mydonation) {
                        vm.myDonation= mydonation;
                        console.log("mydonation inside = ",mydonation);
                        var jsonData = [];
                        jsonData.push(mydonation);

                        var myDonationProject=[];

                            for(var j = 0;j<mydonation.length;j++){
                              if($rootScope.role != "foundation"){
                                var donProjectId = mydonation[j].Value.lastDonation.projectId;
                                var amount = mydonation[j].Value.lastDonation.donorCompany;
                                var donationDate = mydonation[j].Timestamp;

                                if(projId == donProjectId){
                                    var myDonationSingle = {};
                                    myDonationSingle['donationDate'] = donationDate;
                                    myDonationSingle['amount'] = amount;
                                    //myDonationSingle
                                    myDonationProject.push(myDonationSingle);
                                }
                              }


                            }

                            vm.mydonation = myDonationProject;

                      })


            };

        getAllMyDonationBlockCain();
        //getAllMyDonation(projId,donorId);
    }
})();
