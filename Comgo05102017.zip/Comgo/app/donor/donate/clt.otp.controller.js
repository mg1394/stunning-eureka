/**
 * Created By :- Madhura
 * Created Date :- 12-06-2017 13:13 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Created Date :- 20-06-2017 04:13 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('Donate.otpController', Controller);

    function Controller($window,$state,$stateParams, DonateService,BankService, FlashService,$scope,$http,$rootScope) {
        var vm = this;
        var cardInfo;
        var val1=$stateParams.cardDetails;
        vm.cardInfo=$rootScope.master;
        var amountInfo;
        vm.amountInfo=$rootScope.masterAmt1;
        $scope.today = new Date();
        vm.model = {selected: {}}

       //Decides what to show based on user input
        vm.getTemplate = function (don) {
            if ( don._id === vm.model.selected._id ){
                return 'editDonate';
            }
            else return 'displayDonate';
        };
    }
})();
