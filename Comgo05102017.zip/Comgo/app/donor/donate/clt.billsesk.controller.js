(function () {
    'use strict';

    angular
        .module('app')
        .controller('Donate.BilldeskController', Controller);

    function Controller($state,FlashService,$scope,$http,$timeout) {
      $timeout(function() {
            $state.go('donor');
          }, 3000);
    }

})();
