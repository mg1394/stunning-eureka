/**
 * Created By :- Madhura
 * Created Date :- 12-06-2017 13:13 pm
 * Version :- 1.0
 * Created By :- Akshay
 * Created Date :- 20-06-2017 03:13 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('Donate.ccgatewayController', Controller);

    function Controller($window,$state,$stateParams, DonateService,BankService, FlashService,$scope,$http,$rootScope) {
        $rootScope.master={};
        $rootScope.update = function(user) {
            $rootScope.master = angular.copy(user);
            $rootScope.masterAmt1 = angular.copy(vm.amountInfo);
        };

        $rootScope.reset = function() {
            $scope.user = angular.copy($rootScope.master);
        };

        $rootScope.reset();

        var vm = this;
        var amountInfo;
        vm.amountInfo=$rootScope.masterAmt;
        vm.model = {selected: {}};

       //Decides what to show based on user input
       vm.getTemplate = function (don) {
           if ( don._id === vm.model.selected._id ){
               return 'editDonate';
           }
           else return 'displayDonate';
       };

      var getAllBankDetails = function() {
          BankService.GetAll().then(function (bankDetails) {
              $scope.bankDetails = bankDetails;
          });
      };

     vm.alert=function(){
       alert('You wish to make a payment of *AMOUNT* to *ORGANIZATION*');
     };
     getAllBankDetails();
    }

})();
