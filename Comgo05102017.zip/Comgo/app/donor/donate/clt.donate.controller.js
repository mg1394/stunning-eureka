/**
 * Created By :- Madhura
 * Created Date :- 08-06-2017 13:13 pm
 * Version :- 1.0
 * Created By :- Akshay
 * Created Date :- 20-06-2017 12:37 pm
 * Version :- 1.0
 * Updated By :- Girijashankar
 * Updated Date :- 23-06-2017 14:37 pm
 * Version :- 1.0.1 - Bug fixed while adding amount 0 as donation
 * Updated By :- Akshay
 * Updated Date :- 06-07-2017 11:30 pm
 * Version :- 1.0.1 - Bug fixed Donation amount should not be greater than fund goal
 * Updated By :- Mamta
 * Updated Date :- 30-07-2017 1:30 pm
 * Version :- 1.0.1 - prevent negative number
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('Donate.DonateController', Controller);

    function Controller($window, $state, SessionService, $stateParams, DonateService, BankService, donationType, ModeOfPayment, currency, ProjectService, frequency, FlashService, $scope, $http, $rootScope) {

        //breadcrumbs
        $scope.doTheBack = function() {
            window.history.back();
        };

        var vm = this;
        $rootScope.master = {};

        vm.donationAmount = $stateParams.donationAmount;

        vm.projectName = $stateParams.projName;
        vm.projectId = $stateParams.projId;
        vm.fundGoal = $stateParams.fundGoal;
        vm.fundRaised = $stateParams.fundRaised;
        vm.fundBalance = $stateParams.fundBalance;
        console.log('fundGoal= ', vm.fundGoal);
        $rootScope.update = function(user) {
            $rootScope.master = angular.copy(user);
            var donationData = angular.copy(vm.addDonate);
            $rootScope.masterAmt = angular.copy(vm.addDonate);
        };

        $rootScope.reset = function() {
            $scope.user = angular.copy($rootScope.master);
        };

        $rootScope.reset();

        vm.sentAmount = $rootScope.sendAmt;
        console.log('vm.sentAmount=', vm.sentAmount);

        var vm = this;
        vm.model = { selected: {} }
        var amountInfo;
        vm.amountInfo = $rootScope.masterAmt;

        //Decides what to show based on user input
        vm.getTemplate = function(donation) {
            if (donation._id === vm.model.selected._id) {
                return 'editDonate';
            } else return 'displayDonate';
        };

        //Gets the donate details for which edit is to be done
        vm.editDonate = function(donation) {
            vm.model.selected = angular.copy(donation);
        };


        //Deletes the selected donate
        vm.deleteDonate = function(donation) {
            DonateService.Delete(donation)
                .then(function() {
                    FlashService.Success('Donation Deleted');
                    $state.go('donate');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
        };

        //Reset the edit donate details
        vm.reset = function() {
            vm.model.selected = {};
        };

        //Updates the selected project details
        vm.updateDonate = function(donation) {

            DonateService.Update(donation)
                .then(function() {
                    FlashService.Success('Donation updated');
                    vm.reset();
                    $state.go('donate');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
        };
        //# mamta :- 30-07-2017 prevent negative value.
        $scope.restrictNegativeNo = function(e) {
                if (e.keyCode == 45) {
                    e.preventDefault();
                }
            }
            //Save new donate
        vm.saveDonate = function(val1, val2, element) {
            SessionService.GetSessionDetails().then(function(username) {
                var donorId = username;
                console.log('donorId=', donorId);
                var donationDate = new Date();
                var fromDate = new Date();
                var toDate = new Date();
                var donation = val1;
                donation.donationDate = donationDate;
                donation.fromDate = fromDate;
                donation.toDate = toDate;
                donation.donorId = donorId;
                donation.projectName=vm.projectName
                donation.projectId = $stateParams.projId;
                if (!donation.amount || donation.amount == '') {
                    donation.amount = val2;
                }
                // donation.amount = val2;
                console.log("val2 = ", val2);
                $scope.paymentTypeSelection = element.currentTarget.value;
                console.log('$scope.paymentTypeSelection = ', donation);
                var amount = Number(donation.amount);
                //console.log(amount>0);

                if (donation.modeOfPayment == "Cryptocurrency") {
                    donation.currencyType = "BitPay";
                }
                if (amount > 0) {
                    // #GM-160617 :- Temporary changes done as later it will be done based on API response
                    DonateService.Create(donation)
                        .then(function() {
                            $state.go($scope.paymentTypeSelection);
                        })
                        .catch(function(error) {
                            FlashService.Error(error);
                        });

                } else {
                    //FlashService.Error('Amount cannot be less than or equal to 0');
                    alert('Amount cannot be less than or equal to 0');
                }

            });

        };

        //Fetch all the donations from the collection and store in the object
        var getAllDonate = function() {
            DonateService.GetAll().then(function(donation) {
                vm.donate = donation;
            });

        };

        var getAllBankDetails = function() {
            BankService.GetAll().then(function(bankDetails) {
                $scope.bankDetails = bankDetails;
            });

        };

        var getAllProjectDetails = function() {
            ProjectService.GetAll().then(function(proj) {
                vm.project = proj;
            });
        };

        var getAllDonationTypeDetails = function() {
            donationType.GetAll().then(function(donation) {
                vm.donation = donation;
            });
        };

        var getAllFrequency = function() {
            frequency.GetAll().then(function(proj) {
                vm.frequencyType = proj;
            });
        };

        var getAllCurrency = function() {
            currency.GetAll().then(function(proj) {
                vm.currency = proj;
            });
        };

        var getAllModeOfPayment = function() {
            ModeOfPayment.GetAll().then(function(proj) {
                vm.modeOfPayment = proj;
            });
        };

        $scope.checkselection = function() {
            if ($scope.vm.addDonate.donationType != "" && $scope.vm.addDonate.donationType != undefined)
                $scope.msg = 'Selected Value: ' + $scope.vm.addDonate.donationType;
            else
                $scope.msg = 'Please Select Dropdown Value';
        };

        //check();
        getAllModeOfPayment();
        getAllCurrency();
        getAllFrequency();
        getAllDonationTypeDetails();
        getAllProjectDetails();
        getAllBankDetails();
        getAllDonate();
    }

})();