/**
 * Created By :- Akshay
 * Created Date :- 26-07-2017 08:40 pm
 * Version :- 1.0.0
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('Project.PrePublishProject', Controller);
    //inject services
    function Controller($rootScope, $window, ProjectService, SessionService, ProjectDonation, $scope, $state, FlashService) {
        var vm = this;
        vm.fromDB = 'fromDB';
        //$window.location.reload();
        // var donorId = null;
        SessionService.GetSessionDetails().then(function(session) {
            $scope.donorId = session.username;
        });

        //Go to milestone screen and pass projName and projId
        $scope.showMilestones = function(val1, val2, val3, val4, val5, val6, val7,val8,val9,val10,val11) {

            var fundRaised = vm.fundRaised;
            for (var i = 0; i < fundRaised.length; i++) {
                var fundId = fundRaised[i].projectId;
                if (fundId == val2) {
                    val3 = fundRaised[i].sum;
                }

            }
            if (typeof val4 === 'undefined') {
                val4 = 0;
            }
            console.log("call show mil from db2  = = ", vm.fromDB);
            var val11 = 'DB';
            console.log('val7=', val7);
            $state.go('milestone', { projName: val1, projId: val2, fundRaised: val3, myDonation: val4, fundGoal: val5, description: val6, status: val7, projectOwner:val8, startDate:val9, endDate:val10, getDataFrom: val11 });
        };

        $scope.showProjects = function(val1, val2, val3, val4, val5, val6, val7, val8, val9, val10, val11) {
            console.log('ngo = ', val6);
            console.log('country = ', val8);
            $state.go('addproject', { projName: val1, projId: val2, fundGoal: val3, description: val4, projectType: val5, ngo: val6, currency: val7, country: val8, startDate: val9, endDate: val10, toDo: val11 });
        };

        $scope.addMilestone = function(val1, val2, val3, val4, val5, val6, val7, val8, val9) {
            console.log('startDate before substring==', val8);
            $state.go('addmilestone', { projName: val1, projId: val2, fundGoal: val3, description: val4, projectType: val5, ngo: val6, status: val7, startDate: val8, endDate: val9 });
        };

        $scope.publishProject = function(val1) {
            var status = 'Fund Allocated';
            var projid = val1;
            console.log('val1===', val1);
            ProjectService.Update(projid, status)
                .then(function(result) {
                    FlashService.Success('Milestone updated');
                    //vm.reset();
                    //$state.go('project');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });

            //getAllProject();
            getOtherProject();
        }
        $scope.sort = function(keyname) {
            $scope.sortKey = keyname; //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        }

        $scope.doTheBack = function() {
            window.history.back();
        };

        //Go to myDonation screen and pass donorid and projId
        $scope.myDonation = function(val1, val2, val4) {
            var val3 = $scope.donorId;

            $state.go('mydonation', { projId: val1, donorId: val3, projName: val2, myDonation: val4 });
        };

        //Go to fundraised screen and pass donorid and projId
        $scope.fundRaised = function(val1, val2, val3) {
            $state.go('fundraised', { projId: val1, projName: val2, fundRaised: val3 });
        };
        $scope.showAudit = function(val1, val2, val3, val4, val5) {
            var getDataFrom = 'Database';
            var projectId = val1;
            $state.go('audit', { getDataFrom: getDataFrom, projectId: val1, projectName: val2, fundGoal: val3, projectType: val4, currency: val5 });
        };

        //Fetch data from the collection(project) and store in the object
        var getAllProject = function() {
            ProjectService.GetAll().then(function(proj) {
                vm.fundRaised = proj; //for $scope.showMilestones
                vm.project = proj;
            });
        };

        //Fetch data from the collection(projectdonation) based on projId and store in the objects
        /*            var getFundRaised = function() {
                        ProjectDonation.GetAllFundDetails().then(function (funds) {
                            vm.fundRaised = funds;
                            var obj ={};
                            var fundRaisedDetails = [];
                            //console.log('funds  = ',funds);
                            ProjectService.GetAll().then(function (proj) {
                                //console.log('Project  = ',proj);
                                if(proj.length > funds.length ){
                                    for (var i = 0; i < proj.length; i++) {
                                        var projectId = proj[i]._id;
                                        var fundsProjId = '';
                                        var amount = 0.00;

                                        for(var j = 0; j < funds.length; j++){
                                            var fundsProjId = funds[j].projectId;
                                            var amount = funds[j].sum;

                                            if(i==0){
                                                obj[fundsProjId] = amount;
                                            } else if(fundsProjId == projectId){
                                                obj[projectId] = amount;
                                            } else if(!obj[projectId]){
                                                obj[projectId] = 0.00;
                                            }
                                        }
                                        if(funds.length==0){
                                            obj[projectId] = 0.00;
                                        }

                                    }

                                    for (var k = 0; k < proj.length; k++) {
                                        var projectId = proj[k]._id;
                                        var mySingleFund = {};

                                        if(obj[projectId]){
                                            mySingleFund['projectId'] = proj[k]._id;
                                            mySingleFund['sum'] = obj[projectId];

                                            fundRaisedDetails.push(mySingleFund);
                                        }else if(obj[projectId] == 0){
                                            mySingleFund['projectId'] = proj[k]._id;
                                            mySingleFund['sum'] = obj[projectId];

                                            fundRaisedDetails.push(mySingleFund);
                                        }
                                     }
                                    vm.fundRaised = fundRaisedDetails;
                                } else {
                                    vm.fundRaised = funds;
                                }
                                //console.log('Funds  = ',vm.fundRaised);
                            });

                        });
                    };*/
        //# Akky : 24.06.2017 get data from blockchain
        var getFundRaised = function() {
            ProjectDonation.GetAllFundDetails().then(function(project) {
                vm.fundRaised = project;
                console.log("All projects = ", project);
                var jsonData = [];
                jsonData.push(project);
                //console.log("jsonData = ",jsonData);
                //console.log("jsonData length = ",jsonData.length);
                //#madhura: 11.07.2017 get my donations
                ProjectDonation.GetAllMyDonation().then(function(mydonation) {
                    vm.myDonation = mydonation;
                    //console.log("mydonation inside = ",mydonation);
                    var jsonData = [];
                    jsonData.push(mydonation);

                    var obj = {};
                    for (var i = 0; i < project.length; i++) {
                        var projectId = project[i].Key;
                        console.log('mydonation', mydonation);
                        var sum = 0;
                        for (var j = 0; j < mydonation.length; j++) {
                            if ($rootScope.role != "foundation") {
                                if ($rootScope.role != "ngo") {
                                    var donProjectId = mydonation[j].Value.lastDonation.projectId;
                                    var amount = mydonation[j].Value.lastDonation.donorCompany;
                                    //console.log("projectId = ",projectId);
                                    //console.log("donProjectId = ",donProjectId);
                                    //console.log("amount = ",amount);
                                    //console.log("obj = ",obj);
                                    if (projectId == donProjectId) {
                                        //console.log(obj[projectId]);
                                        if (obj[projectId]) {
                                            sum = obj[projectId];
                                            sum = sum + amount;
                                            obj[projectId] = sum;
                                            //console.log("obj = ",obj);
                                        } else {
                                            sum = sum + amount;
                                            obj[projectId] = sum;
                                        }

                                        //console.log("donProjectId = ",donProjectId);
                                        //console.log("myDonation = ",sum);
                                    }
                                } //ngo
                            } //foundation


                        }
                        //console.log("obj = ",obj);
                    }
                    console.log("obj = ", obj);
                    console.log('project = ', project);
                    var myProjectDetails = [];
                    var otherProjectDetails = [];
                    for (var i = 0; i < project.length; i++) {
                        var projectId = project[i].Key;
                        if (obj[projectId]) {
                            var mySingleProject = {};
                            mySingleProject['projectId'] = project[i].Key;
                            mySingleProject['projectName'] = project[i].Record.projectName;
                            mySingleProject['myDonation'] = obj[projectId];
                            mySingleProject['projectType'] = project[i].Record.projectType;
                            mySingleProject['fundGoal'] = project[i].Record.fundRequired;
                            mySingleProject['fundRaised'] = project[i].Record.fundReceived;
                            //mySingleProject['status'] = project[i].Record.projectStatus;
                            mySingleProject['owner'] = project[i].Record.projectOwner;
                            mySingleProject['curr'] = project[i].Record.currency;
                            mySingleProject['country'] = project[i].Record.country;
                            mySingleProject['startDate'] = project[i].Record.startDate;
                            mySingleProject['endDate'] = project[i].Record.endDate;
                            mySingleProject['status'] = "In Progress";
                            console.log('$rootScope.role = ', $rootScope.role);
                            if ($rootScope.role == "ngo") {
                                console.log('project[i].Record.projectOwner = ', project[i].Record.projectOwner);
                                console.log('$rootScope.username = ', $rootScope.username);
                                if ($rootScope.username.toLowerCase() == project[i].Record.projectOwner.toLowerCase()) {
                                    myProjectDetails.push(mySingleProject);
                                }
                            } else {
                                myProjectDetails.push(mySingleProject);
                            }

                        } else {
                            var otherSingleProject = {};
                            otherSingleProject['projectId'] = project[i].Key;
                            otherSingleProject['projectName'] = project[i].Record.projectName;
                            otherSingleProject['projectType'] = project[i].Record.projectType;
                            otherSingleProject['fundGoal'] = project[i].Record.fundRequired;
                            otherSingleProject['fundRaised'] = project[i].Record.fundReceived;
                            //otherSingleProject['status'] = project[i].Record.projectStatus;
                            otherSingleProject['owner'] = project[i].Record.projectOwner;
                            otherSingleProject['curr'] = project[i].Record.currency;
                            otherSingleProject['country'] = project[i].Record.country;
                            otherSingleProject['startDate'] = project[i].Record.startDate;
                            otherSingleProject['endDate'] = project[i].Record.endDate;
                            otherSingleProject['status'] = "In Progress";
                            if ($rootScope.role == "ngo") {
                                console.log('project[i].Record.projectOwner = ', project[i].Record.projectOwner);
                                console.log('$rootScope.username = ', $rootScope.username);
                                if ($rootScope.username.toLowerCase() == project[i].Record.projectOwner.toLowerCase()) {
                                    otherProjectDetails.push(otherSingleProject);
                                }
                            } else {
                                otherProjectDetails.push(otherSingleProject);
                            }
                            //otherProjectDetails.push(otherSingleProject);
                        }
                    }
                    vm.myProject = myProjectDetails;
                    vm.otherProject = otherProjectDetails;
                    console.log('vm.myProject = ', vm.myProject);
                    console.log('vm.otherProject = ', vm.otherProject);
                    /*for(var i=0;i<vm.otherProject.length;i++){

                    }*/
                    //console.log("jsonData inside= ",jsonData);
                    /*for(var j=0; j<mydonation.length; j++){
                      if(mydonation[j]){
                        var mySingleProject = {};
                        mySingleProject['projectId'] = mydonation[j].Key;
                        //mySingleProject['projectName'] = mydonation[j].Record.projectName;
                        mySingleProject['projectId'] = mydonation[j].Record.projectID;
                        mySingleProject['projectType'] = mydonation[j].Record.projectType;
                        mySingleProject['fundGoal'] = mydonation[j].Record.fundRequired;
                        mySingleProject['fundRaised'] = mydonation[j].Record.fundReceived;
                        mySingleProject['status'] = mydonation[j].Record.projectStatus;
                        myProjectDetails.push(mySingleProject);
                        //console.log('mySingleProject==@@@',mySingleProject);
                      }
                    }*/


                })

            })
        };

        //Fetch amount from the Project donation collection and store in the object
        var getMyProject = function() {

            ProjectDonation.GetAllMyProjects().then(function(myProj) {

                vm.projectdonation = myProj;
                var myProjectDetails = [];
                var obj = {};
                var mySingleProject = {};
                SessionService.GetSessionDetails().then(function(session) {
                    var donorId = session.username;
                    for (var j = 0; j < myProj.length; j++) {
                        //console.log("ProjectId = ",myProj[j].projectId._id.toString());
                        //console.log("ProjectAmount = ",myProj[j].amount);

                        if (j == "0") {
                            var key = myProj[j].projectId._id;
                            var value = myProj[j].amount;
                            obj[key] = value;
                            //console.log("Obj All IF = ",obj);
                        } else {
                            var key = myProj[j].projectId._id;
                            //console.log(obj.hasOwnProperty(key));
                            if (obj[key]) {

                                var amountExisting = obj[key];
                                var amount = myProj[j].amount;

                                var value = amountExisting + amount;
                                delete obj[key];

                                obj[key] = value;
                                //console.log("Obj All Else = ",obj);
                            } else {
                                var value = myProj[j].amount;
                                obj[key] = value;
                            }
                        }
                    }
                    //console.log('All Obj = ',obj);
                    for (var j = 0; j < myProj.length; j++) {
                        var key = myProj[j].projectId._id;

                        if (obj[key]) {
                            var mySingleProject = {};
                            mySingleProject['projectName'] = myProj[j].projectId.projectName;
                            mySingleProject['projectType'] = myProj[j].projectId.projectType;
                            mySingleProject['description'] = myProj[j].projectId.description;
                            mySingleProject['fundGoal'] = myProj[j].projectId.fundGoal;
                            mySingleProject['myDonation'] = obj[key];
                            mySingleProject['status'] = myProj[j].projectId.status;
                            mySingleProject['projectId'] = myProj[j].projectId._id;

                            if (myProjectDetails.length > 0) {
                                var len = myProjectDetails.length;
                                if (myProjectDetails[len - 1].projectId != key) {
                                    myProjectDetails.push(mySingleProject);
                                }
                            } else if (myProjectDetails.length == 0) {
                                myProjectDetails.push(mySingleProject);
                            }
                        }
                    }
                    //vm.projectdonation = myProjectDetails;
                    vm.myProject = myProjectDetails;
                });

            });
        };



        var getOtherProject = function() {
            ProjectService.GetAll().then(function(proj) {
                vm.otherproject = proj;
                var myProjectDetails = [];
                console.log('GetAll proj = ', proj);
                ProjectDonation.GetAllProjectDonation().then(function(projDonation) {
                    //console.log('GetAllProjectDonation = ',projDonation);
                    var obj = {};
                    var tempObj = {};
                    SessionService.GetSessionDetails().then(function(session) {
                        var donorId = session.username;
                        for (var i = 0; i < proj.length; i++) {
                            var projectId = proj[i]._id;

                            for (var j = 0; j < projDonation.length; j++) {
                                var projectIdDon = projDonation[j].projectId;
                                var donorIdDon = projDonation[j].donorId;
                                //console.log('projectIdDon = ',projectIdDon,' donorIdDon = ',donorIdDon);
                                //console.log('projectId = ',projectId,' donorId = ',donorId);
                                if (projectIdDon == projectId && donorIdDon == donorId) {
                                    tempObj[projectIdDon] = donorIdDon;
                                } else if (projectIdDon == projectId && donorIdDon != donorId) {
                                    if (tempObj.length == 0) {
                                        tempObj[projectIdDon] = donorIdDon;
                                    } else {
                                        if (!tempObj[projectIdDon]) {
                                            obj[projectIdDon] = donorIdDon;
                                        } else {
                                            delete obj[projectIdDon];
                                        }
                                    }

                                } else {
                                    //console.log(projectIdDon);
                                    //console.log(tempObj[projectIdDon]);
                                    if (!tempObj[projectIdDon]) {
                                        obj[projectIdDon] = donorIdDon;
                                    } else {
                                        delete obj[projectIdDon];
                                    }
                                }

                                if (obj[projectIdDon] == donorId) {
                                    //console.log(projectIdDon, '  Deleted');
                                    delete obj[projectIdDon];
                                }

                                if (tempObj[projectIdDon] && obj[projectIdDon]) {
                                    delete obj[projectIdDon];
                                }

                                //console.log('tempObj = ',tempObj);
                                //console.log('obj = ',obj);
                            }
                        }

                        for (var k = 0; k < proj.length; k++) {
                            var projectId = proj[k]._id;
                            //console.log('proj[k]=',proj[k]);
                            //console.log('getAllProject = ',proj);
                            if (!tempObj[projectId]) {
                                if (obj[projectId]) {
                                    var mySingleProject = {};
                                    mySingleProject['projectName'] = proj[k].projectName;
                                    mySingleProject['projectType'] = proj[k].projectType;
                                    mySingleProject['description'] = proj[k].description;
                                    mySingleProject['fundGoal'] = proj[k].fundGoal;
                                    mySingleProject['status'] = proj[k].status;
                                    mySingleProject['projectId'] = proj[k]._id;
                                    mySingleProject['bkcProjectId'] = proj[k].projectId;
                                    mySingleProject['currency'] = proj[k].currency;
                                    mySingleProject['projectOwner'] = proj[k].projectOwner;
                                    myProjectDetails.push(mySingleProject);
                                } else {
                                    var mySingleProject = {};
                                    mySingleProject['projectName'] = proj[k].projectName;
                                    mySingleProject['projectType'] = proj[k].projectType;
                                    mySingleProject['description'] = proj[k].description;
                                    mySingleProject['fundGoal'] = proj[k].fundGoal;
                                    mySingleProject['status'] = proj[k].status;
                                    mySingleProject['projectId'] = proj[k]._id;
                                    mySingleProject['bkcProjectId'] = proj[k].projectId;
                                    mySingleProject['currency'] = proj[k].currency;
                                    mySingleProject['projectOwner'] = proj[k].projectOwner;
                                    mySingleProject['country'] = proj[k].country;
                                    mySingleProject['startDate'] = proj[k].startDate;
                                    mySingleProject['endDate'] = proj[k].endDate;
                                    myProjectDetails.push(mySingleProject);
                                }
                            }
                        }
                    });
                });
                vm.otherProject = myProjectDetails;
                console.log('vm.otherProject DB==', vm.otherProject);
            });
        };

        //call my project's data
        getMyProject();

        //call other project's data
        getOtherProject();

        //call function getAllProject();
        getAllProject();
    }
})();