/**
 * Created By :- Akshay
 * Created Date :- 09-06-2017 09:30 pm
 * Version :- 1.0.0
 * Updated By :- Girijashankar
 * Updated Date :- 16-06-2017 12:10 pm
 * Version :- 1.0.1
 * Updated By :- Girijashankar
 * Updated Date :- 23-06-2017 10:00 am
 * Version :- 1.0.2 - Bug fix in Pie Chart
 * Updated By :- Akshay
 * Updated Date :- 05-07-2017 12:44 pm
 * Version :- 1.0.3 - add submit proof functionality
 * Updated By :- Girijashankar
 * Created Date :- 06-07-2017 06:44 pm
 * Version :- 1.0.4 - send milestoneId and projectId in requestfund screen
 * Updated By :- Madhura
 * Created Date :- 11-07-2017 02:00 pm
 * Version :- 1.0.5
 * Updated By :- Akshay
 * Created Date :- 27-07-2017 01:00 am
 * Version :- 1.0.5
 * Updated By :- Akshay
 * Updated Date :- 29-07-2017 10:00 pm
 * Version :- 2.0.0 #akshay BKCpublishProject to blockchain
 * Updated By :- Mamta
 * Updated Date :- 30-07-2017 08:25 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Updated Date :- 17-08-2017 01:43 pm
 * Version :- 2.0.0 #project validation to blockchain
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('Milestone.MilestoneController', Controller);

    function Controller($window, $state, $rootScope, ActivityService, MilestoneService, ImageService, $scope, $stateParams, ProjectService, FlashService, currency) {
        var vm = this;
        var val1 = $stateParams.projName;
        var val2 = $stateParams.projId;
        var val3 = $stateParams.fundGoal;
        var val4 = $stateParams.fundRaised;

        vm.projectId = $stateParams.projId;

        $scope.addMilestone = function(val1, val2, val3, val4, val5, val6) {
            console.log(val5);
            $state.go('addmilestone', { projId: val1, projName: val2, fundGoal: val3, startDate: val4, endDate: val5, status: val6 });
        };

        vm.myDonation = $stateParams.myDonation;

        vm.projectnm = $stateParams.projName;
        var val7 = $stateParams.status;
        var getDataFrom = $stateParams.getDataFrom;
        vm.getDataFrom = $stateParams.getDataFrom;
        console.log("from getDataFrom state param ", vm.getDataFrom);
        vm.status = $stateParams.status;
        vm.currency = $stateParams.currency;
        console.log('$stateParams.currency=*****', $stateParams.currency);
        $scope.sendAmt = {};

        // #GM 160617 :- Data to be fetched from $stateParams, hardcoding to be replaced
        vm.description = $stateParams.description;

        vm.fundRaised = Number($stateParams.fundRaised);
        console.log('vm.fundRaised====', vm.fundRaised);
        var myDonation = $stateParams.myDonation;
        vm.fundGoal = Number($stateParams.fundGoal);
        vm.status = $stateParams.status;
        vm.projectOwnerDB = $stateParams.projectOwner;
        vm.startDate = $stateParams.startDate;
        vm.endDate = $stateParams.endDate;
        console.log(vm.startDate);
        vm.curr = $stateParams.currency;
        console.log('vm.curr====', vm.curr);
        // #GM 210617 :- If fundRaised > fundGoal, fundGoal = vm.fundRaised
        if (vm.fundRaised > vm.fundGoal) {
            vm.fundGoal = vm.fundRaised;
            //console.log('FG In = ',vm.fundGoal);
            //console.log('FR In = ',vm.fundRaised);
        }

        var fundBalance = vm.fundGoal - vm.fundRaised;
        vm.fundBalance = fundBalance;
        console.log('fundBalance======', fundBalance);

        var otherDonation = vm.fundRaised - myDonation;

        //breadcrumbs
        $scope.doTheBack = function() {
            window.history.back();
        };


        //VM 150817 Sorting tables
        $scope.sort = function(keyname) {
            $scope.sortKey = keyname; //set the sortKey to the param passed
            $scope.reverse = !$scope.reverse; //if true make it false and vice versa
        }

        // #GM 210617 :- If fundRaised < 0, otherDonation = vm.fundRaised

        if (vm.fundRaised < 0) {
            fundBalance = vm.fundGoal - myDonation;
            otherDonation = vm.fundRaised;
        }

        $scope.labels = ["Other's Donataion", "My Donation", "To Be Raised"];
        $scope.labelsNgo = ["To Be Raised", "Raised"]; //ngo
        $scope.data = [otherDonation, myDonation, fundBalance];
        $scope.dataNgo = [fundBalance, vm.fundRaised]; //ngo
        $scope.options = { legend: { display: true, position: "bottom" } };
        $scope.colours = ['#337ab7', '#7bf230', '#ff944d'];
        $scope.coloursNgo = ['#ffcc00', '#003366']; //ngo

        //send projname and projid to donate screen
        $scope.donate = function() {
            $state.go('donate', { projName: val1, projId: val2, fundGoal: val3, fundRaised: val4, fundBalance: fundBalance });
        };

        //# mamta :- 30-07-2017 prevent negative value.
        $scope.restrictNegativeNo = function(e) {
            if (e.keyCode == 45) {
                e.preventDefault();
            }
        }

        //go to requestfund page page
        $scope.showRequestFund = function(val1, val2, val3, val4, val5, val6, val7, val8, val9, val10) {
            console.log("activityId 1 = ", val1);
            console.log("milestoneId 2 = ", val2);
            var projId = $stateParams.projId;
            console.log('st date++++++++++==', val8);
            console.log('end date+++++++++++++++==', val9);

            $state.go('requestfund', { activityId: val1, milestoneId: val2, projectId: projId, fundBudgeted: val4, fundAllocated: val5, activityName: val6, projectName: val7, startDate: val8, endDate: val9, status: val10 });
        };

        //go to document page
        $scope.showDocument = function(val1, val2, val3, val4) {
            var projectId = $stateParams.projId;
            $state.go('document', { milestoneId: val1, projectId: projectId, milestoneName: val3, projectName: vm.projectnm, activityId: val4 });
        };

        $scope.showNgoDocument = function(val1, val2, val3, val4, val5, val6, val7, val8, val9) {
            var projectId = $stateParams.projId;
            console.log("val 9 *****= ", val9);
            $state.go('uploadeddocs', { milestoneId: val1, projectId: projectId, milestoneName: val3, milestoneActivity: val4, fundRequested: val5, description: val6, projectName: vm.projectnm, activityId: val7, actfundBudgeted: val8, currency: val9 });
        };

        $rootScope.sendAmount = function(amount) {
            $rootScope.sendAmt = angular.copy(amount);
            //console.log('$rootScope.sendAmt=',$rootScope.sendAmt);
        };

        //Updates the selected milestone details
        vm.updateMilestone = function(status) {
            var status = status;
            var projId = val2;
            if (confirm("Are you sure you want to proceed?")) {
                ProjectService.updateMilestoneStatus(projId, status)
                    .then(function(result) {
                        //FlashService.Success('Milestone updated');
                        //vm.reset();
                        //$state.go('project');
                    }).catch(function(error) {
                        alert('Project successfully');
                        //FlashService.Error(error);
                    });
                setTimeout(function() { $state.go('prePublishProject') }, 1000);
            } else {
                console.log('cancelled');
            }
            // alert('project successfully approved');

        }

        vm.saveRemarks = function(remarks) {
            var remarks = remarks;
            var projId = val2;
            console.log("remarks==", remarks);
            ProjectService.saveRemarks(projId, remarks)
                .then(function(result) {

                }).catch(function(error) {

                });
        }
        var getAllCurrency = function() {
            currency.GetAll().then(function(curr) {
                vm.currency = curr;
                console.log('vm.currency+++++', vm.currency);
            });
        };

        vm.fundAllocate = function(val1, val2, val3) {
            console.log("im in fundAllocateToMilestone ", val1);
            var milestoneId = val1;
            var fundBudgeted = val2;
            var fundBudgetedMil = val3;
            var projectId = $stateParams.projId;
            console.log('vm.fundBudgetedMil=',fundBudgetedMil);
            ///////////////////////////////////
            //FundRaised-FundAllocated=Fund that can be allocated
            // vm.fundRemaining=vm.fundRaised-fundBudgetedMil;
            // console.log('vm.fundRemaining=',vm.fundRemaining);
            // if(vm.fundRemaining>fundBudgetedMil){
            ///////////////////////////////////
            if (confirm("Funds of value "+fundBudgetedMil+" will be allocated to Milestone. All activities will reflect Fund Allocated status. Do you want to allocate funds to the milestone now?")) {
                MilestoneService.fundAllocateToMilestone(projectId, milestoneId, fundBudgetedMil)
                    .then(function(result) {
                        console.log("saved = ", result);
                        FlashService.Success('Fund Allocated');
                        getDetailsByParams();
                    }).catch(function(error) {});
            } else {
                console.log('cancelled');
            }
            // }else{
            //     alert("Insufficient funds. You will have to wait till funds are raised");
            // }
        }
        console.log('vm.status***', vm.status);
        vm.BKCFundReleased = function(val1, val2, val3) {
            var milestoneId = val1;
            console.log("milestoneId id 1 = ", milestoneId);
            var activityId = val2;
            console.log("activity id  2 = ", activityId);
            var projectId = $stateParams.projId;
            console.log("projId  = ", projectId);
            var fundBudgeted = val3;
            console.log("fundBudgeted id 3 = ", fundBudgeted);
            var projectOwner = vm.projectOwner;
            console.log("projectOwner =  ", projectOwner);
            if (confirm("Are you sure you want to release fund?")) {
                MilestoneService.BKCFundReleased(projectId, milestoneId, activityId, fundBudgeted, projectOwner)
                    .then(function(result) {
                        vm.myStatus = "Fund Released";
                        console.log("my status = ", vm.myStatus);
                        FlashService.Success('Fund Released');
                        //# Mamta :- 19-09-2017 Refresh status after fund released
                        getDetailsByParams();
                        // setTimeout(function() { $state.go('milestone') }, 2000);
                    }).catch(function(error) {
                        FlashService.Error(error);
                    });
            } else {
                console.log('cancelled');
            }

        }


        //# akshay :- 29-072017 Add status (fund allocated) and call publish function to the blockchain
        vm.publishProject = function(val1, val2) {
            //var status = 'Approved';
            //# akshay :- i have to change after fund allocation
            var status = 'Fund Allocated';
            var projId = $stateParams.projId;
            console.log("projId id in publish = ", projId);
            var milestoneId = val1;
            console.log("publish project = ", milestoneId);
            var fundBudgeted = val2;
            console.log("vla 1 fund budgeted = ", val2);
            if (confirm("Are you sure you want to publish the project?")) {
                ProjectService.BKCpublishProject(projId, status, milestoneId, fundBudgeted).then(function(result) {
                    FlashService.Success('Milestone updated');
                    //vm.reset();
                }).catch(function(error) {
                    FlashService.Error(error);
                });
                setTimeout(function() { $state.go('donor') }, 5000);
            } else {
                console.log('cancelled');
            }
        }

        // # akshay :- 17-08-2017 project validation by validator to the blockchain
        vm.projectValidation = function(val1, val2) {
            var milestoneId = val1;
            console.log("1 = ", val1);
            var activityId = val2;
            console.log("2 = ", val2);
            var projectId = $stateParams.projId;
            console.log("id = ", projectId);
            if (confirm("   Confirm the validation check")) {
                var check = 'Validation Successful';
                console.log(check);
                ProjectService.BKCProjectValidation(projectId, milestoneId, activityId, check).then(function(result) {
                    FlashService.Success('Project Validated');
                    //vm.reset();
                }).catch(function(error) {
                    FlashService.Error(error);
                });
            } else {
                console.log('cancelled');
                var check = 'Validation failed';
                console.log(check);
                ProjectService.BKCProjectValidation(projectId, milestoneId, activityId, check).then(function(result) {
                    FlashService.Success('Project Validated');
                    //vm.reset();
                }).catch(function(error) {
                    FlashService.Error(error);
                });
            }
        }
        var getByProjectName = function() {
                //console.log('$stateParams.projId = ',$stateParams.projId);
                //console.log("mil id = ",$stateParams.milestoneId);
                MilestoneService.GetByProjname($stateParams.projId).then(function(milestone) {
                    //console.log('milestone milestone == ',milestone);
                    ActivityService.GetByProjname($stateParams.projId).then(function(activity) {
                        var milestoneArray = []
                            //console.log('activity activity == ',activity);
                        for (var i = 0; i < milestone.length; i++) {
                            var milestoneId = milestone[i].milestoneId;

                            for (var j = 0; j < activity.length; j++) {
                                var actMilestoneId = activity[j].milestoneId;
                                if (milestoneId == actMilestoneId) {
                                    var mySingleMilestone = {};
                                    mySingleMilestone["milestoneId"] = milestone[i].milestoneId;
                                    mySingleMilestone["fundBudgetedMil"] = milestone[i].fundBudgeted;//bugdet of whole milestone
                                    mySingleMilestone["fundBudgeted"] = activity[j].activityBudget; //budget of 1 activity
                                    mySingleMilestone["activityId"] = activity[j].activityId;
                                    mySingleMilestone["milestoneName"] = milestone[i].milestone;
                                    mySingleMilestone["activityName"] = activity[j].activityName;
                                    mySingleMilestone["startDate"] = activity[j].startDate;
                                    mySingleMilestone["endDate"] = activity[j].endDate;
                                    mySingleMilestone["validationCheck"] = activity[j].validationCheck;
                                    mySingleMilestone["status"] = activity[j].status;
                                    mySingleMilestone["projectId"] = milestone[i].projectId;


                                    // mySingleMilestone["status"] = "Fund Allocated";


                                    //Please fill all the details as per your requirement to show in screen
                                    milestoneArray.push(mySingleMilestone);

                                }
                            }


                        }
                        vm.milestone = milestoneArray
                            //# mamta :- 31-07-2017 alert on no milestone.
                            // if (vm.milestone == 'null') {

                        //         $("#miltable").hide();
                        //         $("#search").hide();


                        // } else if (vm.milestone.length == 0) {

                        //         $("#miltable").hide();
                        //         $("#search").hide();


                        // }
                        //#MG :- 28-08-2017 hide table if no milestones
                        if (vm.milestone[0].length != 0) {

                            $("#miltable").show();
                            $("#search").show();
                            //$("#btnId").hide();

                        } else {

                            //$("#btnId").show();

                        }
                        console.log("remarks doc cont =  = ", vm.milestone);
                        console.log('=====vm.milestone=====', vm.milestone);
                    })
                })

            }
            //Fetch all milestones from the project milestone collection and store in the object

        //#MG 29-08-2017 show description from db.    
        var getByProjName = function() {
            console.log($stateParams.projId);
            //////////////////////////
            ProjectService.GetByProjID($stateParams.projId).then(function(proj) {
                vm.description = proj;
                vm.projDescription = vm.description[0].description;
                console.log('vm.description=', vm.description[0].description);
            });
            //////////////////////////    
        };
        getByProjName();

        //# Akshay :- 29-07-2017 Not used
        /*  var getActivityByProjName = function() {
              ActivityService.GetByProjname($stateParams.projId).then(function (act) {
                  vm.activities = act;
                  console.log('vm.activities==',vm.activities);
              });
          };*/

        //#Akshay: get milestone details by Params from blockchain
        var getDetailsByParams = function() {
            MilestoneService.BKCGetDetailsByParams($stateParams.projId).then(function(project) {
                var milestoneArray = [];
                console.log("project = ", project);
                var milestones = project.milestones;
                vm.projectOwner = project.projectOwner;
                //  var milestones = project[0].Value.milestones;
                console.log("vm.projectOwner = ", vm.projectOwner);
                if (milestones != 'null') {
                    for (var i = 0; i < milestones.length; i++) {
                        var milestoneId = milestones[i].milestoneId;
                        console.log(" milestone[i] = ", milestones[i]);
                        var activity = milestones[i].activities;
                        console.log("activity in for lopp = ", activity);
                        var sum = 0;
                        for (var j = 0; j < activity.length; j++) {
                            var amount = 0;
                            amount = parseFloat(activity[j].activityBudget);
                            sum = sum + amount;
                            
                            
                        }
                        console.log(milestoneId,' sum&&&& ', sum);
                        for (var j = 0; j < activity.length; j++) {
                            console.log('');
                            var mySingleMilestone = {};
                            
                            mySingleMilestone["milestoneId"] = milestones[i].milestoneId;
                            //mySingleMilestone["fundBudgetedMil"] = milestones[i].fundBudgeted;//bugdet of whole milestone
                            mySingleMilestone["fundBudgetedMil"] = sum;
                            mySingleMilestone["fundBudgeted"] = activity[j].activityBudget;
                            mySingleMilestone["fundAllocated"] = milestones[i].fundAllocated;
                            mySingleMilestone["activityId"] = activity[j].activityId;
                            mySingleMilestone["milestoneName"] = milestones[i].milestoneName;
                            mySingleMilestone["activityName"] = activity[j].activityName;
                            mySingleMilestone["startDate"] = activity[j].startDate;
                            mySingleMilestone["endDate"] = activity[j].endDate;
                            mySingleMilestone["validationCheck"] = activity[j].validation;
                            mySingleMilestone["status"] = activity[j].status;
                            if (milestones[i].fundAllocated > 0 && activity[j].status=='Not Started') {//here
                                mySingleMilestone["status"] = 'Fund Allocated';
                            }
                            




                            // if(activity[j].activityFundRequested > 0 ){
                            //     mySingleMilestone["status"] = 'Fund Requested';
                            //     console.log("mySingleMilestone = ",mySingleMilestone["status"]);
                            // }
                            var activityStatus = String(activity[j].status).trim();
                            //console.log("activityStatus 1 =",activityStatus);
                            //console.log(activityStatus =='Request FundFund Released');
                            if (activityStatus == 'Request FundFund Released') {
                                mySingleMilestone["status"] = 'Fund Released';
                                console.log("mySingleMilestone = ", mySingleMilestone["status"]);
                            } else if (activityStatus == 'Request Fund') {
                                mySingleMilestone["status"] = 'Fund Requested';
                                console.log("mySingleMilestone = ", mySingleMilestone["status"]);
                            }


                            //Please fill all the details as per your requirement to show in screen
                            milestoneArray.push(mySingleMilestone);
                        }
                        //console.log(milestoneId,' sum&&&& ', sum);
                    }
                    vm.milestone = milestoneArray;
                    console.log("final = ", vm.milestone);
                    if (vm.milestone[0].length != 0) {

                        $("#miltable").show();
                        $("#search").show();
                        //$("#btnId").hide();

                    } else {

                        //$("#btnId").show();

                    }
                    console.log("remarks doc cont =  = ", vm.milestone);
                    console.log('=====vm.milestone=====', vm.milestone);
                }
            });
        };
        //fetch image from db
        var getImageByProjId = function() {
            ImageService.GetImageByProjId($stateParams.projId).then(function(image) {
                vm.projectImage = image;
                console.log('$stateParams.projId', $stateParams.projId);
                if (image.length == 0) {
                    var myImageDetails = [];
                    var mySingleImage = {};
                    mySingleImage['imageUrl'] = "img/project" + "/" + $stateParams.projId;
                    mySingleImage['imageUrlDummy'] = "img/project" + "/" + "undefined";
                    mySingleImage['milestoneId'] = $stateParams.projId;
                    mySingleImage['projectId'] = $stateParams.projId;
                    mySingleImage['_id'] = $stateParams.projId;
                    myImageDetails.push(mySingleImage);
                    vm.projectImage = myImageDetails;
                }
            });
        };
        if (getDataFrom == 'DB') {
            // console.log("im from db");
            getByProjectName();
            //getByProjName();
        } else if (getDataFrom == 'BKC') {
            // console.log("im from blockchain");
            getDetailsByParams();
            getByProjName();
        }
        //getByProjectName();
        //getByProjName();
        //getDetailsByParams();
        getImageByProjId();
        getAllCurrency();
    }
})();