/**
 * Created By :- Akshay
 * Created Date :- 12-06-2017 09:30 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Created Date :- 13-06-2017 10:11 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Created Date :- 14-06-2017 01:11 pm
 * Version :- 1.0
 * Updated By :- Girijashankar
 * Created Date :- 15-06-2017 01:11 pm
 * Version :- 1.0
 * Updated By :- Girijashankar
 * Created Date :- 16-06-2017 10:10 am
 * Version :- 1.0
 * Updated By :- Akshay
 * Created Date :- 17-06-2017 08:44 am
 * Version :- 1.0
 * Updated By :- Madhura
 * Updated Date :- 10-07-2017 04:20 pm
 * Version :- 2.0.1
 * Updated By :- Akshay
 * Updated Date :- 27-07-2017 11:20 pm
 * Version :- 2.0.2 get view project data from blockchain
 */
(function() {
    'use strict';
    angular
        .module('app')
        .controller('Donor.DonorController', Controller);
    //inject services
    function Controller($rootScope, ProjectService, SessionService, ProjectDonation, $scope, $state, FlashService) {
        var vm = this;
        vm.fromBKC = 'fromBKC';
        // var donorId = null;

        // VN 2608 FILTER BASED ON PROJECT TYPE
        $scope.projectTypeSearch = "";
        $scope.applySearch = function(e) {

                $scope.projectTypeSearch = e.currentTarget.name;
                if ($scope.projectTypeSearch == "All Data") {
                    $scope.projectTypeSearch = "";
                }
            }
            //FILTER BASED ON PROJECT TYPE ENDS HERE

        SessionService.GetSessionDetails().then(function(session) {
            $scope.donorId = session.username;
        });
        // ****************************************  SORTING *********************************************

        $scope.sort = function(keyname) {
                $scope.sortKey = keyname; //set the sortKey to the param passed
                $scope.reverse = !$scope.reverse; //if true make it false and vice versa
            }
            // **************************************** SORTING ENDS HERE *********************************************



        //Go to milestone screen and pass projName and projId
        $scope.showMilestones = function(val1, val2, val3, val4, val5, val6, val7, val9) {
            console.log("prij id in showmiles = ", val2);
            var fundRaised = vm.fundRaised;
            for (var i = 0; i < fundRaised.length; i++) {
                var fundId = fundRaised[i].projectId;
                if (fundId == val2) {
                    val3 = fundRaised[i].sum;
                }

            }
            if (typeof val4 === 'undefined') {
                val4 = 0;
            }
            var val8 = 'BKC';
            console.log('val9=++', val9);
            $state.go('milestone', { projName: val1, projId: val2, fundRaised: val3, myDonation: val4, fundGoal: val5, description: val6, status: val7, getDataFrom: val8, currency: val9 });
        };

        $scope.showProjects = function(val1, val2, val3, val4, val5, val6, val7) {
            console.log('ngo======= ', val7);
            $state.go('addproject', { projName: val1, projId: val2, fundGoal: val3, description: val4, projectType: val5, ngo: val6, currency: val7 });
        };

        $scope.addMilestone = function(val1, val2, val3, val4, val5, val6, val7) {
            console.log('ngo = ', val6);
            $state.go('addmilestone', { projName: val1, projId: val2, fundGoal: val3, description: val4, projectType: val5, ngo: val6, status: val7 });
        };

        //send projname and projid to donate screen
        $scope.donate = function(val1, val2, val3, val4) {
            console.log(val1);
            console.log(val2);
            console.log(val3);
            console.log(val4);
            $state.go('donate', { projName: val1, projId: val2, fundGoal: val3, fundRaised: val4 });
        };

        $scope.publishProject = function(val1) {
            var status = 'Fund Allocated';
            var projid = val1;
            console.log('val1===', val1);
            ProjectService.Update(projid, status)
                .then(function(result) {
                    FlashService.Success('Milestone updated');
                    //vm.reset();
                    //$state.go('project');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });

            //getAllProject();
            getOtherProject();
        }

        $scope.addProj = function() {
            //console.log('projId = ',val2);
            $state.go('addproject');
        };

        $scope.doTheBack = function() {
            window.history.back();
        };

        //Go to myDonation screen and pass donorid and projId
        $scope.myDonation = function(val1, val2, val4) {
            var val3 = $scope.donorId;

            $state.go('mydonation', { projId: val1, donorId: val3, projName: val2, myDonation: val4 });
        };

        //Go to fundraised screen and pass donorid and projId
        $scope.fundRaised = function(val1, val2, val3) {
            $state.go('fundraised', { projId: val1, projName: val2, fundRaised: val3 });
        };
        $scope.showAudit = function(val1, val2, val3, val4, val5) {
            var getDataFrom = 'Blockchain';
            var projectId = val1;
            console.log(val3);
            console.log(val5);
            $state.go('audit', { getDataFrom: getDataFrom, projectId: val1, projectName: val2, fundGoal: val3, fundRaised: val4, currency: val5 });
        };

        //# Akky : 26.07.2017 get data from blockchain
        var getFundRaised = function() {
            ProjectDonation.BKCGetAllFundDetails().then(function(project) {
                vm.fundRaised = project;
                console.log("All projects = ", project);
                var jsonData = [];
                jsonData.push(project);

                //#madhura: 11.07.2017 get my donations
                ProjectDonation.BKCGetAllMyDonation().then(function(mydonation) {
                    vm.myDonation = mydonation;
                    //console.log("mydonation inside = ",mydonation);
                    var jsonData = [];
                    jsonData.push(mydonation);

                    var obj = {};
                    for (var i = 0; i < project.length; i++) {
                        var projectId = project[i].Key;
                        console.log('mydonation', mydonation);
                        var sum = 0;
                        for (var j = 0; j < mydonation.length; j++) {
                            if ($rootScope.role != "foundation") {
                                if ($rootScope.role != "ngo") {
                                    var donProjectId = mydonation[j].Value.lastDonation.projectId;
                                    var amount = mydonation[j].Value.lastDonation.donorCompany;
                                    //console.log("projectId = ",projectId);
                                    //console.log("donProjectId = ",donProjectId);
                                    //console.log("amount = ",amount);
                                    //console.log("obj = ",obj);
                                    if (projectId == donProjectId) {
                                        //console.log(obj[projectId]);
                                        if (obj[projectId]) {
                                            sum = obj[projectId];
                                            sum = sum + amount;
                                            obj[projectId] = sum;
                                            //console.log("obj = ",obj);
                                        } else {
                                            sum = sum + amount;
                                            obj[projectId] = sum;
                                        }

                                        //console.log("donProjectId = ",donProjectId);
                                        //console.log("myDonation = ",sum);
                                    }
                                } //ngo
                            } //foundation


                        }
                        //console.log("obj = ",obj);
                    }
                    console.log("obj = ", obj);
                    console.log('project = ', project);
                    var myProjectDetails = [];
                    var otherProjectDetails = [];
                    for (var i = 0; i < project.length; i++) {
                        var projectId = project[i].Key;
                        if (obj[projectId]) {
                            var mySingleProject = {};
                            mySingleProject['projectId'] = project[i].Key;
                            mySingleProject['projectName'] = project[i].Record.projectName;
                            mySingleProject['myDonation'] = obj[projectId];
                            mySingleProject['projectType'] = project[i].Record.projectType;
                            mySingleProject['fundGoal'] = project[i].Record.fundRequired;
                            mySingleProject['fundRaised'] = project[i].Record.fundReceived;
                            //mySingleProject['status'] = project[i].Record.projectStatus;
                            mySingleProject['owner'] = project[i].Record.projectOwner;
                            mySingleProject['status'] = "In Progress";
                            console.log('$rootScope.role = ', $rootScope.role);
                            if ($rootScope.role == "ngo") {
                                console.log('project[i].Record.projectOwner = ', project[i].Record.projectOwner);
                                console.log('$rootScope.username = ', $rootScope.username);
                                if ($rootScope.username.toLowerCase() == project[i].Record.projectOwner.toLowerCase()) {
                                    myProjectDetails.push(mySingleProject);
                                }
                            } else {
                                myProjectDetails.push(mySingleProject);
                            }

                        } else {
                            var otherSingleProject = {};
                            otherSingleProject['projectId'] = project[i].Key;
                            otherSingleProject['projectName'] = project[i].Record.projectName;
                            otherSingleProject['projectType'] = project[i].Record.projectType;
                            otherSingleProject['fundGoal'] = project[i].Record.fundRequired;
                            otherSingleProject['fundRaised'] = project[i].Record.fundReceived;
                            //otherSingleProject['status'] = project[i].Record.projectStatus;
                            otherSingleProject['owner'] = project[i].Record.projectOwner;
                            otherSingleProject['status'] = "In Progress";
                            if ($rootScope.role == "ngo") {
                                console.log('project[i].Record.projectOwner = ', project[i].Record.projectOwner);
                                console.log('$rootScope.username = ', $rootScope.username);
                                if ($rootScope.username.toLowerCase() == project[i].Record.projectOwner.toLowerCase()) {
                                    otherProjectDetails.push(otherSingleProject);
                                }
                            } else {
                                otherProjectDetails.push(otherSingleProject);
                            }
                            //otherProjectDetails.push(otherSingleProject);
                        }
                    }
                    vm.myProject = myProjectDetails;
                    vm.otherProject = otherProjectDetails;
                    console.log('vm.myProject = ', vm.myProject);
                    console.log('vm.otherProject = ', vm.otherProject);
                    for (var i = 0; i < vm.otherProject.length; i++) {

                    }
                    //console.log("jsonData inside= ",jsonData);
                    for (var j = 0; j < mydonation.length; j++) {
                        if (mydonation[j]) {
                            var mySingleProject = {};
                            mySingleProject['projectId'] = mydonation[j].Key;
                            //mySingleProject['projectName'] = mydonation[j].Record.projectName;
                            mySingleProject['projectId'] = mydonation[j].Record.projectID;
                            mySingleProject['projectType'] = mydonation[j].Record.projectType;
                            mySingleProject['fundGoal'] = mydonation[j].Record.fundGoal;
                            mySingleProject['fundRaised'] = mydonation[j].Record.fundRaised;
                            mySingleProject['status'] = mydonation[j].Record.projectStatus;
                            myProjectDetails.push(mySingleProject);
                            //console.log('mySingleProject==@@@',mySingleProject);
                        }
                    }


                })
                var myProjectDetails = [];
                /*   for(var i =0; i<funds.length; i++){
                       if(funds[i]){
                         var mySingleProject = {};
                         mySingleProject['projectName']=funds[i].Value.lastDonation.projectName;
                         mySingleProject['myDonation']=funds[i].Value.lastDonation.donorCompany;
                         mySingleProject['TxnId']=funds[i].TxId;
                         myProjectDetails.push(mySingleProject);
                         //console.log('mySingleProject==@@@@###',mySingleProject);

                       }
                   }*/
                //console.log("myProjectDetails = ",myProjectDetails);
                vm.fundRaised = myProjectDetails;
                //console.log('vm.fundRaised',vm.fundRaised);

            })
        };

        var getMyDonation = function() {
            ProjectDonation.BKCGetAllMyDonation().then(function(mydonation) {
                vm.myDonation = mydonation;
                console.log("mydonation = ", mydonation);
                var jsonData = [];
                jsonData.push(mydonation);
                console.log("jsonData = ", jsonData);
                var myProjectDetails = [];
                for (var i = 0; i < mydonation.length; i++) {
                    //console.log (i, funds[i])
                    //console.log('funds[i].id = ',jsonData[i].id);
                    if (mydonation[i].Key) {
                        var mySingleProject = {};
                        mySingleProject['projectId'] = mydonation[i].Key;
                        mySingleProject['projectName'] = mydonation[i].Record.projectName;
                        mySingleProject['projectId'] = mydonation[i].Record.projectID;
                        mySingleProject['projectType'] = mydonation[i].Record.projectType;
                        mySingleProject['fundGoal'] = mydonation[i].Record.fundGoal;
                        mySingleProject['fundRaised'] = mydonation[i].Record.fundRaised;
                        mySingleProject['status'] = mydonation[i].Record.projectStatus;
                        myProjectDetails.push(mySingleProject);
                        console.log("myProjectDetails = ", myProjectDetails);
                    }
                }
            })
        };

        //# Akky : 24.06.2017 get data from blockchain
        var getFundRaiseds = function() {

            ProjectDonation.BKCGetAllFundDetails().then(function(project) {
                vm.fundRaised = project;
                console.log("All projects = ", project);
                var jsonData = [];
                jsonData.push(project);
                //console.log("jsonData = ",jsonData);
                //console.log("jsonData length = ",jsonData.length);
                //#madhura: 11.07.2017 get my donations
                ProjectDonation.BKCGetAllMyDonation().then(function(mydonation) {
                        vm.myDonation = mydonation;
                        //console.log("mydonation inside = ",mydonation);
                        var jsonData = [];
                        jsonData.push(mydonation);

                        var obj = {};
                        for (var i = 0; i < project.length; i++) {
                            var projectId = project[i].Key;
                            console.log('mydonation', mydonation);
                            var sum = 0;
                            for (var j = 0; j < mydonation.length; j++) {
                                if ($rootScope.role != "foundation") {
                                    if ($rootScope.role != "ngo") {
                                        if ($rootScope.role != "validator") {


                                            var donProjectId = mydonation[j].Value.lastDonation.projectId;
                                            var donorCompany = parseInt(mydonation[j].Value.lastDonation.donorCompany);
                                            var donationAmount = parseInt(mydonation[j].Value.lastDonation.donationAmount);
                                            if (donationAmount) {
                                                var amount = donationAmount;
                                            } else {
                                                var amount = donorCompany;
                                            }
                                            console.log('amount', amount);
                                            //console.log("projectId = ",projectId);
                                            //console.log("donProjectId = ",donProjectId);
                                            //console.log("amount = ",amount);
                                            //console.log("obj = ",obj);
                                            if (projectId == donProjectId) {
                                                //console.log(obj[projectId]);
                                                if (obj[projectId]) {
                                                    sum = obj[projectId];
                                                    sum = sum + amount;
                                                    obj[projectId] = sum;
                                                    //console.log("obj = ",obj);
                                                } else {
                                                    sum = sum + amount;
                                                    obj[projectId] = sum;
                                                }

                                                //console.log("donProjectId = ",donProjectId);
                                                //console.log("myDonation = ",sum);
                                            }
                                        } //validator
                                    } //ngo
                                } //foundation


                            }
                            //console.log("obj = ",obj);
                        }
                        console.log("obj = ", obj);
                        console.log('project = ', project);
                        var myProjectDetails = [];
                        var otherProjectDetails = [];
                        for (var i = 0; i < project.length; i++) {
                            var projectId = project[i].Key;
                            if (obj[projectId]) {
                                var mySingleProject = {};
                                mySingleProject['projectId'] = project[i].Key;
                                mySingleProject['projectName'] = project[i].Record.projectName;
                                mySingleProject['myDonation'] = obj[projectId];
                                mySingleProject['projectType'] = project[i].Record.projectType;
                                mySingleProject['fundGoal'] = project[i].Record.fundGoal;
                                mySingleProject['fundRaised'] = project[i].Record.fundRaised;
                                //mySingleProject['status'] = project[i].Record.projectStatus;
                                mySingleProject['owner'] = project[i].Record.projectOwner;
                                mySingleProject['status'] = "Published";
                                mySingleProject['currency'] = project[i].Record.currency;
                                mySingleProject['imageUrl'] = "img/project" + "/" + project[i].Key;
                                mySingleProject['imageUrlDummy'] = "img/project" + "/" + "undefined";
                                //mySingleProject['status'] = project[i].Record.status;
                                console.log('$rootScope.role = ', $rootScope.role);
                                if ($rootScope.role == "ngo") {
                                    console.log('project[i].Record.projectOwner = ', project[i].Record.projectOwner);
                                    console.log('$rootScope.username = ', $rootScope.username);
                                    if ($rootScope.username.toLowerCase() == project[i].Record.projectOwner.toLowerCase()) {
                                        myProjectDetails.push(mySingleProject);
                                    }
                                } else {
                                    myProjectDetails.push(mySingleProject);
                                }

                            } else {
                                var otherSingleProject = {};
                                otherSingleProject['projectId'] = project[i].Key;
                                otherSingleProject['projectName'] = project[i].Record.projectName;
                                otherSingleProject['projectType'] = project[i].Record.projectType;
                                otherSingleProject['fundGoal'] = project[i].Record.fundGoal;
                                otherSingleProject['fundRaised'] = project[i].Record.fundRaised;
                                //otherSingleProject['status'] = project[i].Record.projectStatus;
                                otherSingleProject['owner'] = project[i].Record.projectOwner;
                                otherSingleProject['status'] = "Published";
                                otherSingleProject['currency'] = project[i].Record.currency;
                                otherSingleProject['imageUrl'] = "img/project" + "/" + project[i].Key;
                                otherSingleProject['imageUrlDummy'] = "img/project" + "/" + "undefined";
                                //otherSingleProject['status'] = project[i].Record.status;
                                if ($rootScope.role == "ngo") {
                                    console.log('project[i].Record.projectOwner = ', project[i].Record.projectOwner);
                                    console.log('$rootScope.username = ', $rootScope.username);
                                    if ($rootScope.username.toLowerCase() == project[i].Record.projectOwner.toLowerCase()) {
                                        otherProjectDetails.push(otherSingleProject);
                                    }
                                } else {
                                    otherProjectDetails.push(otherSingleProject);
                                }
                                //otherProjectDetails.push(otherSingleProject);
                            }
                        }
                        vm.myProject = myProjectDetails;
                        vm.otherProject = otherProjectDetails;

                        vm.allProjectTypeData = {};

                        //  vm.allProjectTypeData = otherProjectDetails;
                        console.log("All Data Here :" + vm.allProjectTypeData);

                        //REMOVING DUPLICATES FOR PROJECT TYPES VN 2608

                        var array = otherProjectDetails;

                        var seenNames = {};

                        array = array.filter(function(currentObject) {
                            if (currentObject.projectType in seenNames) {
                                return false;
                            } else {
                                seenNames[currentObject.projectType] = true;
                                return true;
                            }
                        });

                        vm.allProjectTypeData = array;
                        vm.allProjectTypeData.push({ "projectType": "All Data" });
                        //console.log("SHOW ENDS HERE :"+JSON.stringify(array));

                        //REMOVING DUPLICATES ENDS HERE

                        console.log('vm.myProject = ', vm.myProject);
                        console.log('vm.otherProject = ', vm.otherProject);
                        /*for(var i=0;i<vm.otherProject.length;i++){

                        }*/
                        //console.log("jsonData inside= ",jsonData);
                        /*for(var j=0; j<mydonation.length; j++){
                          if(mydonation[j]){
                            var mySingleProject = {};
                            mySingleProject['projectId'] = mydonation[j].Key;
                            //mySingleProject['projectName'] = mydonation[j].Record.projectName;
                            mySingleProject['projectId'] = mydonation[j].Record.projectID;
                            mySingleProject['projectType'] = mydonation[j].Record.projectType;
                            mySingleProject['fundGoal'] = mydonation[j].Record.fundRequired;
                            mySingleProject['fundRaised'] = mydonation[j].Record.fundReceived;
                            mySingleProject['status'] = mydonation[j].Record.projectStatus;
                            myProjectDetails.push(mySingleProject);
                            //console.log('mySingleProject==@@@',mySingleProject);
                          }
                        }*/


                    })
                    /*var myProjectDetails = [];
                    for(var i =0; i<funds.length; i++){
                        if(funds[i]){
                          var mySingleProject = {};
                          mySingleProject['projectName']=funds[i].Value.lastDonation.projectName;
                          mySingleProject['myDonation']=funds[i].Value.lastDonation.donorCompany;
                          mySingleProject['TxnId']=funds[i].TxId;
                          myProjectDetails.push(mySingleProject);
                          //console.log('mySingleProject==@@@@###',mySingleProject);

                        }
                    }
                    //console.log("myProjectDetails = ",myProjectDetails);
                    vm.fundRaised = myProjectDetails;
                    //console.log('vm.fundRaised',vm.fundRaised);
                    */
            })
        };

        getMyDonation();
        getFundRaiseds(); //bc code commented

        //# Akshay :-26-07-2017 call my project's data from db
        // getMyProject();

        //call other project's data
        //getOtherProject();

        //call function getAllProject();
        // getAllProject();
    }
})();