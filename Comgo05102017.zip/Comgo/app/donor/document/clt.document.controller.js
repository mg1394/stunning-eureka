/**
 * Created By :- Mamta Bhardwaj
 * Created Date :- 09-06-2017 11:00 am
 * Version :- 1.0
 * Created By :- Akshay
 * Created Date :- 09-06-2017 03:00 pm
 * Version :- 1.0
 * Updated By :- Madhura
 * Created Date :- 23-06-2017 10:30 am
 * Version :- 1.0
 * Updated By :- Mamta
 * Created Date :- 23-06-2017 03:05 pm
 * Version :- 1.1.1
 * Updated By :- Madhura
 * Created Date :- 26-06-2017 5:30 pm
 * Version :- 1.1.2
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('Document.DocumentController', Controller);

    function Controller($stateParams, $rootScope, $state, Upload, FileUpload, $timeout, DocumentService, SessionService, ProofService, FlashService, $scope, $http, currency) {
        var vm = this;

        vm.role = null;
        SessionService.GetSessionDetails().then(function(session) {
                $rootScope.role = session.role;
                console.log("document cont $rootScope.role=", $rootScope.role);

            },
            function(error) {

            });

        //breadcrumbs
        $scope.doTheBack = function() {
            window.history.back();
        };

        vm.hash = null;
        vm.uploadFile = function(myFile) {
            console.log('file=', myFile);
            var file = myFile;
            var uploadUrl = "/savedata";
            FileUpload.uploadFileToUrl(file, uploadUrl).then(function(response) {
                console.log('hashed Data = ', response);
                console.log('hashed Data = ', response.data);
                vm.hash = response.data;
            });
        };

        vm.model = { selected: {} };
        vm.projectName = $stateParams.projectName;
        vm.milestoneName = $stateParams.milestoneName;
        vm.milestoneId = $stateParams.milestoneId;
        vm.projectId = $stateParams.projectId;
        vm.documentName = vm.fileHashValue;
        vm.activityId = $stateParams.activityId;
        //Fetch all the document from the collection and store in the object
        var getAllDocument = function() {
            //var val1 = $stateParams.milestoneId;
            var val1 = $stateParams.activityId;
            var val2 = $stateParams.projectId;

            DocumentService.GetAllDocument(val1, val2).then(function(doc) {
                vm.document = doc;
            });
            vm.projectId = $stateParams.projectId;
            //vm.milestoneId = $stateParams.milestoneId;
            vm.activityId = $stateParams.activityId;
            ProofService.GetAllProof(val1, val2).then(function(doc) {
                vm.proof = doc;
                //# mamta :- 27-07-2017 alert on no proof.
                if (vm.proof == 'null') {
                    FlashService.Error('No proof submitted');
                    //alert('No proof submitted');
                } else if (vm.proof.length == 0) {
                    FlashService.Error('No proof submitted');
                    //alert('No proof submitted');
                }
                console.log("remarks doc cont =  = ", vm.proof);
            });
        };

        var getAllCurrency = function() {
            currency.GetAll().then(function(proj) {
                vm.currency = proj;
            });
        };

        getAllDocument();
        getAllCurrency();
        //Decides what to show based on user input
        vm.getTemplate = function(doc) {
            if (proj._id === vm.model.selected._id) {
                return 'editDocument';
            } else return 'displayDocument';
        };

        //Gets the documentdetails for which edit is to be done
        vm.editDocument = function(doc) {
            vm.model.selected = angular.copy(doc);
        };


        //Deletes the selected ocument
        vm.deleteDocument = function(doc) {
            DocumentService.Delete(doc)
                .then(function() {
                    FlashService.Success('Document Deleted');
                    $state.go('document');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
        };

        //Reset the edit documentdetails
        vm.reset = function() {
            vm.model.selected = {};
        };

        //Updates the selected documentdetails
        vm.updateDocument = function(doc) {
            DocumentService.Update(doc)
                .then(function() {
                    FlashService.Success('Document updated');
                    vm.reset();
                    $state.go('document');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
        };

        //Save new document
        vm.saveDocument = function(doc) {

            DocumentService.Create(doc)
                .then(function() {
                    FlashService.Success('Document Saved Successfully');
                    modal.style.display = "none";
                    $state.go('document');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
        };

        vm.saveProof = function(proof) {
            proof.milestoneId = vm.milestoneId;
            proof.projectId = vm.projectId;
            //proof.hash=vm.fileHashValue;
            proof.documentName = vm.FileName;
            var doc = {};
            doc["documentName"] = vm.FileName;
            //doc["documentPath"]=vm.fileHashValue;
            doc["documentPath"] = vm.hash;
            //console.log("vm.fileHashValue",vm.fileHashValue);
            DocumentService.Create(doc)
                .then(function(doc) {
                    console.log("doc=", doc.insertedIds[0]);
                    proof.documentId = doc.insertedIds[0];
                    ProofService.Create(proof)
                        .then(function() {

                            FlashService.Success('Proof Saved Successfully');
                            modal.style.display = "none";
                            //$state.go('document');
                        })
                        .catch(function(error) {
                            FlashService.Error(error);
                        });

                })
                .catch(function(error) {
                    FlashService.Error(error);
                });



        }

        //#Edited by:- Madhura for base64 conversion
        vm.fileHashValue = null;
        vm.FileName = null;

        vm.getHashValue = function(proof) {
            var files = document.getElementById('file').files;
            console.log('files = ', files);
            console.log('filename=', files[0].name);
            vm.FileName = files[0].name;
            if (files.length > 0) {
                var reader = new FileReader();
                reader.readAsDataURL(files[0]);
                //reader.readAsText(files[0], MD5);
                reader.onload = function() {
                    console.log("Base64=", reader.result);
                    vm.fileHashValue = reader.result;

                };
                reader.onerror = function(error) {
                    console.log('Error: ', error);
                };
            }

        }

    }

})();