/**
 * Created By :- Mamta Bhardwaj
 * Created Date :- 09-06-2017 11:00 am
 * Version :- 1.0
 * Created By :- Akshay
 * Created Date :- 09-06-2017 03:00 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('Document.DocumentController', Controller);

    function Controller($stateParams,$state, DocumentService, FlashService,$scope,$http) {
        var vm = this;


       vm.model = {selected: {}};
       vm.projectName = $stateParams.projectName;
       vm.milestoneName = $stateParams.milestoneName;
        //Fetch all the document from the collection and store in the object
        var getAllDocument = function() {
            var val1 =  $stateParams.milestoneId;
            var val2 =  $stateParams.projectId;
            
            DocumentService.GetAllDocument(val1,val2).then(function (doc) {
                vm.document = doc;
            });
        };

        getAllDocument();

       //Decides what to show based on user input
       vm.getTemplate = function (doc) {
           if ( proj._id === vm.model.selected._id ){
               return 'editDocument';
           }
           else return 'displayDocument';
       };

       //Gets the documentdetails for which edit is to be done
       vm.editDocument = function (doc) {
           vm.model.selected = angular.copy(doc);
       };


       //Deletes the selected ocument
       vm.deleteDocument = function (doc) {
           DocumentService.Delete(doc)
               .then(function () {
                   FlashService.Success('Document Deleted');
                   $state.go('document');
               })
               .catch(function (error) {
                   FlashService.Error(error);
               });
       };

       //Reset the edit documentdetails
       vm.reset = function () {
          vm.model.selected = {};
       };

       //Updates the selected documentdetails
       vm.updateDocument = function (doc) {
           DocumentService.Update(doc)
               .then(function () {
                   FlashService.Success('Document updated');
                   vm.reset();
                   $state.go('document');
               })
               .catch(function (error) {
                   FlashService.Error(error);
               });
       };

       //Save new document
       vm.saveDocument = function (doc) {
          DocumentService.Create(doc)
               .then(function () {
                   FlashService.Success('Document Saved Successfully');
                   modal.style.display = "none";
                   $state.go('document');
               })
               .catch(function (error) {
                   FlashService.Error(error);
               });
       };


    }

})();
