/**
 * Created By :- Akshay
 * Created Date :- 14-06-2017 06:51 pm
 * Version :- 1.0
 */
(function () {
    'use strict';

    angular
        .module('app')
        .controller('FundRaised.FundRaisedController', Controller);



    function Controller(FundRaisedService,$stateParams,$scope) {

      //breadcrumbs
      $scope.doTheBack = function() {
          window.history.back();
      };

        var vm = this;
        var projId=$stateParams.projId;
        vm.projectName=$stateParams.projName;
        vm.totalFund=$stateParams.fundRaised;
        console.log('$stateParams.fundRaised in fund ra cont=',$stateParams.fundRaised);

        //Fetch all the project from the collection and store in the object
        var getAllFundRaised = function(projId) {
            FundRaisedService.GetAll(projId).then(function (fundRaised) {
                vm.fundRaised = fundRaised;
            });
        };
        //getAllFundRaised(projId);

        var getFundRaisedblockChain = function(){
            FundRaisedService.GetAllFundRaisedDetails(projId).then(function (fundRaised) {
                console.log('fundRaised = ',fundRaised);
                //var obj = {};
                var fundRaisedProject=[];
                for(var i=0;i<fundRaised.length;i++){
                    var donationDate = fundRaised[i].Timestamp;
                    var donorId = fundRaised[i].Value.lastDonation.donorId;
                    var donationAmount = fundRaised[i].Value.lastDonation.donationAmount;

                    if(donationAmount != "" && donationAmount>0){
                        var fundRaisedSingle = {};
                        fundRaisedSingle['donationDate'] = donationDate;
                        fundRaisedSingle['amount'] = donationAmount;
                        fundRaisedSingle['donorId'] = donorId;
                        fundRaisedProject.push(fundRaisedSingle);
                        console.log('fundRaisedProject in=',fundRaisedProject);
                        //var dateStr = donationDate.substring(0, 10);
                        //$scope.lineChartYData=
                        //$scope.lineChartXData=donationDate
                        //console.log('$scope.lineChartXData=',$scope.lineChartXData);
                    }

                }
                vm.fundRaised = fundRaisedProject;
                console.log('fundRaisedProject out=',fundRaisedProject);

                var donArray=[];
                var donAmt=[];
                var donId=[];

                for(var i=0;i<fundRaised.length;i++){
                var donationDate = fundRaised[i].Timestamp;
                  var donationAmount = fundRaised[i].Value.lastDonation.donationAmount;
                    var donorId =fundRaised[i].Value.lastDonation.donorId;
                var donationDateArray={};
                  var donAmtArray={};
                    var donorIdArray={};
                donationDateArray=donationDate.substring(0, 10);
                  donAmtArray=donationAmount;
                    donorIdArray=donorId;
                //console.log('donationDateArray=',donationDateArray);
                donArray.push(donationDateArray);
                  donAmt.push(donAmtArray);
                    donId.push(donorIdArray);
                //console.log('donArray=',donArray);

              }
              console.log('donArray out=',donArray);
              console.log('donId out=',donId);
              //console.log('donorIdArray out=',donorIdArray);
              var tempObj = [];
              tempObj['data'] = donAmt;
              //tempObj['name'] = ["1","2","3","4"];
              tempObj['name']=donId;
              //$scope.lineChartXData=donArray
              //$scope.lineChartYData=tempObj
              console.log('tempObj=',tempObj);
              /*var yData=[{
                  "name": donId,//donorId
                  "data": donAmt//donAmt based on donorId
                },{
                "name": donId,
                "data": donAmt
                },{
                "name": donId,
                "data": donAmt
                },{
                "name": donId,
                "data": donAmt
              }];*/
              for(var i=0;i<fundRaised.length;i++){
                console.log('donId[i]',donId[i]);
                var yData=[{"name":donId[i], "data":donAmt}];
            }
          $scope.lineChartYData=yData
          $scope.lineChartXData=donArray
          console.log('yData=',yData);

            });
        };
        getFundRaisedblockChain();

       /* var charts=function (){
            var data = {"xData": ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],"yData":[{
                "name": "Tokyo",
                "data": [7.0, 6.9, 9.5, 14.5, 18.2, 21.5, 25.2, 26.5, 23.3, 18.3, 13.9, 9.6]
            }, {
                "name": "New York",
                "data": [-0.2, 0.8, 5.7, 11.3, 17.0, 22.0, 24.8, 24.1, 20.1, 14.1, 8.6, 2.5]
            }, {
                "name": "Berlin",
                "data": [-0.9, 0.6, 3.5, 8.4, 13.5, 17.0, 18.6, 17.9, 14.3, 9.0, 3.9, 1.0]
            }, {
                "name": "London",
                "data": [3.9, 4.2, 5.7, 8.5, 11.9, 15.2, 17.0, 16.6, 14.2, 10.3, 6.6, 4.8]
            },{
                "name": "Mumbai",
                "data": [4.9, 5.2, 6.7, 9.5, 12.9, 16.2, 18.0, 17.6, 15.2, 11.3, 7.6, 5.8]
            }]}

            //$scope.lineChartYData=data.yData
            //$scope.lineChartXData=data.xData
            console.log('data.yData=',data.yData);
        };*/
        /*var charts= function(){
            FundRaisedService.GetAllFundRaisedDetails(projId).then(function (fundRaised) {
            console.log('fundRaised in charts func = ',fundRaised);
            });
        };*/
       // charts();
    }
})();
