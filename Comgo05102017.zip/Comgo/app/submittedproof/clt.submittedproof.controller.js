/**
 * Created By :- Madhura
 * Created Date :- 01-07-2017 11:00 am
 * Version :- 1.0
 * Updated By :- Akshay
 * Updated Date :- 05-07-2017 04:00 pm
 * Version :- 1.0.1
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('Submittedproof.SubmittedproofController', Controller);

    function Controller($stateParams, $http, ProofService, $scope, $state) {

        var vm = this;
        vm.projectId = null;
        vm.milestoneId = null;
        vm.activityName = $stateParams.milestoneActivity;
        $scope.submitProof = function(val1, val2, val3, val4) {
            val1 = $stateParams.milestoneId;
            val2 = $stateParams.projectId
            console.log('milestoneId = ', val1);
            console.log('projectId = ', val2);
            val4 = $stateParams.milestoneActivity;
            $state.go('ngoproof', { milestoneId: val1, projectId: val2, milestoneName: val3, milestoneActivity: val4, projectName: vm.projectnm });
        };

        $scope.back = function() {
            $state.go('milestone');
        }

        //breadcrumbs
        $scope.doTheBack = function() {
            window.history.back();
        };

        //#Akshay :(05-07-2017) Get all documents based on projId and milestoneId
        var getAllDocument = function() {
            var val1 = $stateParams.activityId;
            console.log("activity id = ", val1);
            var val2 = $stateParams.projectId;
            vm.projectId = $stateParams.projectId;
            vm.milestoneId = $stateParams.milestoneId;
            ProofService.GetAllProof(val1, val2).then(function(proof) {
                vm.proof = proof;
                console.log("remarks subproof cont =  = ", vm.proof);
            });
        };
        getAllDocument();
    }
})();