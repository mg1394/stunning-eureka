/**
 * Created By :- Mamta Bhardwaj
 * Created Date :- 25-07-2017 2:00 pm
 * Version :- 1.0
 * Updated By :- Mamta Bhardwaj
 * Updated Date :- 30-07-2017 11:00 pm
 * Version :- 1.1
 * Updated By :- Madhura
 * Updated Date :- 31-07-2017 04:00 pm
 * Version :- 1.2 #inline edit
 */
(function() {
    'use strict';

    angular
        .module('app')
        .controller('AddMilestone.AddMilestoneController', Controller);

    function Controller($stateParams, $state, currency, $rootScope, $timeout, MilestoneService, ActivityService, SessionService, ProjectService, FlashService, $scope, $http, $filter) {
        //#Mamta :- 04-09-2017 show and hide legends
        //This will hide the DIV by default.
        $scope.IsVisible = false;
        $scope.visible = true;
        $scope.ShowHide = function() {
            //If DIV is visible it will be hidden and vice versa.
            $scope.IsVisible = $scope.IsVisible ? false : true;
            $scope.visible = $scope.visible ? false : true;
        }
        var vm = this;
        $scope.addNew = function(personalDetail) {
            $scope.vm.milestone.push({
                'milestone': "",
                'startDate': "",
                'endDate': "",
                'completionCriteria': "",
            });

            getAllMilestoneById($stateParams.projId);
        };

        $scope.doTheBack = function() {
            window.history.back();
        };

        $scope.reset = function(data) {
            $scope.myForm.$setPristine();
        };

        $scope.addActivityPerMil = function(val1, val2, val3, val4, val5, val6, val7, val8) {
            console.log('addActivityPerMil called');
            console.log('mil id==', val1);
            console.log('p id==', val2);
            console.log('mil name==', val3);
            console.log('sd==', val4);
            console.log('ed==', val5);
            console.log('Budgeted==', val6);
            console.log('fund goal==', val7);
            console.log('vm.milestoneTotal-mil.fundBudgeted==', val8);
            $state.go('addactivity', { milestoneId: val1, projectId: val2, milestone: val3, startDate: val4, endDate: val5, fundBudgeted: val6, fundGoal: val7, remainingBal: val8 });
        };

        var refresh = function() {
            $http.get('/addmilestone').success(function(response) {
                //console.log("I got the data I requested");
                $scope.vm.milestone = response;
                $scope.mil = "";
            });
            getAllMilestoneById($stateParams.projId);
        };


        //# mamta :- 30-07-2017 show projectName and milestoneName.
        vm.model = { selected: {} };
        vm.projName = $stateParams.projName;
        $rootScope.projName = vm.projName;
        //vm.milestone = $stateParams.milestone;
        //console.log('vm.milestone====================',vm.milestone);
        //$rootScope.milestone=vm.milestone;
        vm.projId = $stateParams.projId;
        //console.log('vm.projId==',vm.projId);
        vm.fundGoal = $stateParams.fundGoal;
        vm.description = $stateParams.description;
        vm.status = $stateParams.status;
        $rootScope.Projstatus = vm.status;

        // # Akshay 14-08-2917 : date filter
        vm.startDt = $stateParams.startDate;
        vm.projStartDate = $filter('date')(vm.startDt, "yyyy-MM-dd");
        console.log("vm.dateAsString = ", vm.startDate);

        vm.endDt = $stateParams.endDate;
        vm.projEndDate = $filter('date')(vm.endDt, "yyyy-MM-dd");
        console.log("vm.endDate = ", vm.endDate);

        console.log('vm.projStartDate=', vm.projStartDate);
        console.log('vm.projEndDate=', vm.projEndDate);

        //#MG startDate validation
        vm.startDate = new Date().toISOString().slice(0, 10);;
        console.log('mil cont st date==', vm.startDate);

        //Decides what to show based on user input
        vm.getTemplate = function(mil) {
            if (mil._id === vm.model.selected._id) {
                return 'editDocument';
            } else return 'displayDocument';
        };

        //Gets the documentdetails for which edit is to be done
        vm.editDocument = function(mil) {
            mil.startDate = new Date(mil.startDate);
            mil.endDate = new Date(mil.endDate);
            vm.model.selected = angular.copy(mil);
            //console.log('mil test',mil.startDate.substring(0, 10));
        };

        //Deletes the selected ocument
        vm.deleteDocument = function(mil) {
            var projectId = mil.projectId;
            var milestoneId = mil.milestoneId;
            var milestone = mil.milestone;
            // var activityId = mil.activityId; 
            var _id = mil._id;
            console.log("project id = ", milestoneId);
            if (confirm("Are you sure you want to delete?")) {
                MilestoneService.Delete(_id, projectId, milestoneId, milestone)
                    .then(function(doc) {
                        FlashService.Success('Milestone Deleted');
                        //$state.go('addMilestone');
                    })
                    .catch(function(error) {
                        FlashService.Error(error);
                    });
            } else {
                console.log('cancelled');
            }

            getAllMilestoneById(vm.projId);
        };

        //Updates the selected documentdetails
        vm.updateDocument = function(mil) {

            MilestoneService.Update(mil)
                .then(function() {
                    FlashService.Success('Milestone updated');
                    vm.reset();
                    getAllMilestoneById($stateParams.projId);
                    //$state.go('requestfund');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });

            getAllMilestoneById(vm.projId);
        };

        //Reset the edit documentdetails
        vm.reset = function() {
            vm.model.selected = {};
            getAllMilestoneById(vm.projId); //#MG refresh view
        };


        vm.saveProject = function(result) {
            ProjectService.Create(result)
                .then(function(result) {
                    FlashService.Success('project saved');
                });
        }

        function validateDate(getDate) {
            //chkdate = $('#txndt').val();
            var chkDate = getDate;
            var year = chkDate.getFullYear();
            var month = chkDate.getMonth();
            var date = chkDate.getDate();
            //month = month-1;

            var today = new Date();
            var todYear = today.getFullYear();
            var todMon = today.getMonth();
            var todDay = today.getDate();

            if (year <= todYear) {
                //   console.log(todYear,' = ',year);
                //   console.log(todMon,' = ',month);
                //   console.log(todDay,' = ',date);
                //   console.log(year == todYear && month <=todMon);
                //   console.log(year == todYear && month == todMon && date<= todDay);
                //console.log(year == todYear && month <=todMon);
                if (year == todYear && month <= todMon) {
                    if (month == todMon && date <= todDay) {
                        return true;
                    } else if (month < todMon) {
                        return true;
                    } else {
                        return false;
                        //console.log("1 Input date cannot be greater than today's date");
                    }
                } else if (year == todYear && month == todMon && date <= todDay) {
                    return true;
                } else if (year < todYear) {
                    return true;
                } else {
                    return false;
                    //console.log("2 Input date cannot be greater than today's date");
                }
            } else {
                return false;
                //console.log("3 Input date cannot be greater than today's date");
            }
            // return false;
        }
        //new

        vm.saveMilestone = function(result) {
                result.fundBudgeted = 0;
                result.projectId = vm.projId;

                result.fundAllocated = vm.addMilestone.fundBudgeted;
                MilestoneService.Create(result)
                    .then(function(result) {
                        //console.log('result=',result);
                        FlashService.Success('New milestone saved');
                        $scope.vm.addMilestone.milestone = '';
                        $scope.vm.addMilestone.startDate = '';
                        $scope.vm.addMilestone.endDate = '';
                        $scope.vm.addMilestone.activityName = '';
                        $scope.vm.addMilestone.fundBudgeted = '';
                        $scope.vm.addMilestone.validationCheck = '';
                        getAllMilestoneById(vm.projId); //#MG function called for instant refresh
                    })
                    .catch(function(error) {
                        FlashService.Error(error);
                    });
                getAllMilestoneById(vm.projId);

                //getAllMilestone();
            }
            //# mamta :- 30-07-2017 prevent negative value.
        $scope.restrictNegativeNo = function(e) {
                if (e.keyCode == 45) {
                    e.preventDefault();
                }
            }
            /*var getActivityById= function(id){
              ActivityService.GetActivityById(id).then(function(act){
                vm.activity = act;
                console.log('vm.activity by ID=',vm.activity);
                vm.noOfActivities=vm.activity.length;
                console.log('vm.noOfActivities==',vm.noOfActivities);
              });
            };
            getActivityById($stateParams.milestoneId);*/
            //Updates the selected milestone details
        vm.updateMilestoneStatus = function() {
            var status = 'Budgeted';
            var projId = vm.projId;
            if (confirm("Are you sure you want to send for approval?")) {
                ProjectService.updateMilestoneStatus(projId, status)
                    .then(function(result) {
                        FlashService.Success('Project sent for Approval');
                        getAllMilestoneById(vm.projId);
                        //vm.reset();
                        //$state.go('donor');
                    }).catch(function(error) {
                        FlashService.Error(error);
                    });
            } else {
                console.log('cancelled');
            }
            getAllMilestoneById(vm.projId);
            setTimeout(function() { $state.go('prePublishProject') }, 1000);
        }

        vm.saveActivity = function(result) {
            result.projectId = vm.projId;
            result.milestoneId = $stateParams.milestoneId;
            ActivityService.Create(result)
                .then(function(result) {
                    //console.log('result=',result);
                    FlashService.Success('activity saved');
                    $scope.vm.addActivity.activityName = '';
                    $scope.vm.addActivity.startDate = '';
                    $scope.vm.addActivity.endDate = '';
                    $scope.vm.addMilestone.activityName = '';
                    $scope.vm.addMilestone.fundBudgeted = '';
                    $scope.vm.addMilestone.validationCheck = '';
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });
            getActivityById($stateParams.milestoneId);
        }

        var getAllCurrency = function() {
            currency.GetAll().then(function(proj) {
                vm.currency = proj;
            });
        };

        var getAllMilestone = function() {
            MilestoneService.GetAllMilestone().then(function(mil) {
                vm.milestone = mil;
                //console.log('vm.milestone =',vm.milestone);
            });
        };

        vm.milestoneTotal = null;
        var getAllMilestoneById = function(projectId) {
            MilestoneService.GetMilestoneById(projectId).then(function(mil) {
                var editFlag = 0;
                console.log('GetMilestoneById NEW= ', mil);

                ActivityService.GetAllActivityByProjectId(projectId).then(function(activity) {
                    console.log('GetAllActivityByProjectId ACT=', activity);
                    var obj = {};

                    var sum = 0;
                    var amount = 0;
                    for (var i = 0; i < mil.length; i++) {
                        var milestoneId = mil[i].milestoneId;
                        //#MG get milestone amount total
                        amount = parseFloat(mil[i].fundBudgeted);
                        sum = sum + amount;


                        var actCount = 0;
                        //console.log('activity.length = ',activity.length);
                        for (var j = 0; j < activity.length; j++) {
                            //console.log('activity[j] = ',j);
                            var actMilestoneId = activity[j].milestoneId;
                            //console.log('getAllMilestoneById actMilestoneId = ',actMilestoneId);
                            if (actMilestoneId == milestoneId) {
                                if (obj[milestoneId]) {
                                    //actCount ++;
                                    var temp = obj[milestoneId] + actCount;
                                    obj[milestoneId] = temp;
                                } else {
                                    actCount = 1;
                                    obj[milestoneId] = actCount;
                                }

                            }
                        }

                    }
                    console.log('===========================================');
                    console.log('obj Before ===== ', obj);
                    vm.milestoneTotal = sum; //#MG milestone amount total
                    $rootScope.tempFundAllocated = vm.milestoneTotal;
                    console.log('vm.milestoneTotal===', vm.milestoneTotal);
                    console.log('===========================================');
                    for (var i = 0; i < mil.length; i++) {

                        //console.log('mil.length=',mil.length);
                        var milestoneId = mil[i].milestoneId;
                        //console.log('milestoneId=',milestoneId);
                        var keys = Object.keys(obj);
                        if (obj[milestoneId]) {
                            mil[i]['activityLength'] = obj[milestoneId];
                            console.log('mil[i] == ', mil[i]);
                            if (vm.enableBtn != 0) {
                                console.log("in working function");
                                vm.enableBtn = 1;
                            }

                        } else {
                            mil[i]['activityLength'] = 0;
                            console.log('mil[i] == ', mil[i]);
                            vm.enableBtn = 0;
                        }
                        //console.log('keys=',keys);
                        /*for (var j = 0; j < keys.length; j++) {

                            if (typeof keys[i]!= 'undefined' && milestoneId == keys[i]) {
                              console.log('keys[i] =',keys[i]);
                                if (obj[keys[i]]) {
                                    //console.log('keys[i]',keys[i]);
                                    //console.log('obj[keys[i]',obj[keys[i]]);
                                    mil[i]['activityLength'] = obj[keys[i]];
                                    console.log('mil[i] == ',mil[i]);
                                    vm.enableBtn = 1;
                                }

                            } else {
                                if (typeof keys[i]== 'undefined' ) {
                                  console.log('!keys[i] milestoneId === ',milestoneId);
                                    mil[i]['activityLength'] = 0;
                                    vm.enableBtn = 0;
                                }
                            }

                        }*/
                        //console.log('mil[i]=',mil[i]);
                    }
                    console.log('===========================================');
                    console.log('obj ===== ', obj);

                });


                /*ActivityService.GetActivityById(id).then(function(act){
                  vm.activity = act;
                  console.log('vm.activity by ID=',vm.activity);
                  vm.noOfActivities=vm.activity.length;
                  console.log('vm.noOfActivities==',vm.noOfActivities);
                });*/
                vm.milestone = mil;
                //console.log('vm.milestone +++++++++=', vm.milestone);

            });

        };

        var getAllActivity = function() {
            ActivityService.GetAllActivity().then(function(act) {
                vm.activity = act;
                //console.log('vm.activity =',vm.activity);
            });
        };

        var getActivityById = function(id) {
            ActivityService.GetActivityById(id).then(function(act) {
                vm.activity = act;
                //console.log('vm.activity by ID=',vm.activity);
                vm.noOfActivities = vm.activity.length;
                //console.log('vm.noOfActivities==',vm.noOfActivities);
            });
        };
        //getAllActivity();
        getActivityById($stateParams.milestoneId);
        getAllMilestoneById($stateParams.projId);
        getAllCurrency();

        var activityDetail = null
        $(document).on('click', '.addActivity', function() {
            // your function here
            var id = $(this).attr('id');

            $stateParams.milestoneId = id;
            getAllMilestoneById($stateParams.projId);
            getActivityById(id);

            $("#activity").show();
        });

    }


})();