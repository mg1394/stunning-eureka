/*
 - Updated By :- Mamta
 - Updated Date :- 30-07-2017 11:30 pm
 - Version :- 1.1 Refresh activity and prevent negative value
*/

(function() {
    'use strict';

    angular
        .module('app')
        .controller('AddActivity.AddActivityController', Controller);

    function Controller($stateParams, $state, $rootScope, ActivityService, ProjectService, InvoiceService, MilestoneService, Upload, FileUpload, $timeout, DocumentService, SessionService, ProofService, FlashService, $scope, $http, currency, $filter) {

        //#Mamta :- 04-09-2017 show and hide legends
        //This will hide the DIV by default.
        $scope.IsVisible = false;
        $scope.visible = true;
        $scope.ShowHide = function() {
                //If DIV is visible it will be hidden and vice versa.
                $scope.IsVisible = $scope.IsVisible ? false : true;
                $scope.visible = $scope.visible ? false : true;
            }
            /*$scope.show = false;
            $scope.addMember = function() {
                    $scope.show = true;
                    $scope.new = {};
                    console.log('$scope.show',$scope.show);
                  };*/
        var vm = this;
        vm.projName1 = $rootScope.projName;
        vm.milestone1 = $rootScope.milestone;
        //console.log('vm.projectName============',vm.projName);
        $scope.doTheBack = function() {
            window.history.back();
        };

        $scope.reset = function(data) {
            $scope.myForm.$setPristine();
        };
        $scope.addNew = function(personalDetail) {
            $scope.vm.invoices.push({
                'expenseItem': "",
                'description': "",
                'unitCost': "",
                'quantity': "",

            });
            refresh();
            //getAllInvoices();
            getAllInvoicesById($stateParams.milestoneId);
        };
        $scope.remove = function() {
            var newDataList = [];
            $scope.selectedAll = false;
            angular.forEach($scope.vm.invoices, function(selected) {
                if (!selected.selected) {
                    newDataList.push(selected);
                }
            });
            $scope.vm.invoices = newDataList;
            refresh();
            //getAllInvoices();
            getAllInvoicesById($stateParams.milestoneId);
        };

        $scope.checkAll = function() {
            if (!$scope.selectedAll) {
                $scope.selectedAll = true;
            } else {
                $scope.selectedAll = false;
            }
            angular.forEach($scope.vm.invoices, function(personalDetail) {
                vm.invoices.selected = $scope.selectedAll;
            });
        };
        $scope.doTheBack = function() {
            window.history.back();
        };

        $scope.restrictNegativeNo = function(e) {
            if (e.keyCode == 45) {
                e.preventDefault();
            }
        }
        var refresh = function() {
            $http.get('/requestfund').success(function(response) {
                //console.log("I got the data I requested");
                $scope.vm.invoices = response;
                $scope.inv = "";
            });
            //getAllInvoices();
            getAllInvoicesById($stateParams.milestoneId);
        };

        var vm = this;
        vm.role = null;
        SessionService.GetSessionDetails().then(function(session) {
                vm.role = session.role;

            },
            function(error) {

            });

        vm.hash = null;
        vm.uploadFile = function(myFile) {
            //console.log('file=',myFile);
            var file = myFile;
            var uploadUrl = "/savedata";
            FileUpload.uploadFileToUrl(file, uploadUrl).then(function(response) {
                //console.log('hashed Data = ',response);
                //console.log('hashed Data = ',response.data);
                vm.hash = response.data;
            });
        };
        vm.model = { selected: {} };


        vm.status = $rootScope.Projstatus;
        //console.log('vm.status addactivity cont=',vm.status);

        //console.log('$stateParams.milestoneId=',$stateParams.milestoneId);
        //console.log('$stateParams.projectId=',$stateParams.projectId);
        vm.milestoneId = $stateParams.milestoneId;
        vm.projectId = $stateParams.projectId;
        vm.mileName = $stateParams.milestone;

        //Akshay 14-08-2917 : Date filter
        vm.startDt = $stateParams.startDate;
        vm.milStartDate = $filter('date')(vm.startDt, "yyyy-MM-dd");
        console.log("vm.dateAsString = ", vm.startDate);

        vm.endDt = $stateParams.endDate;
        vm.milEndDate = $filter('date')(vm.endDt, "yyyy-MM-dd");
        console.log("vm.endDate = ", vm.endDate);


        vm.fundBudgeted = $stateParams.fundBudgeted;
        console.log('vm.milStartDate==', vm.milStartDate);
        console.log('vm.milEndDate==', vm.milEndDate);
        console.log('vm.fundBudgeted in activity cont==', vm.fundBudgeted);
        vm.activityName = $stateParams.milestoneActivity;
        vm.documentName = vm.fileHashValue;
        vm.fundAllocated = $stateParams.fundAllocated;
        vm.balance = $stateParams.remainingBal;
        console.log('$stateParams.remainingBal==', $stateParams.remainingBal);

        vm.totalFundGoal = $stateParams.fundGoal;
        console.log('vm.totalFundGoal=', vm.totalFundGoal)


        $scope.submitProof = function(val1, val2, val3) {
            val1 = $stateParams.milestoneId;
            val2 = $stateParams.projectId
            console.log('milestoneId = ', val1);
            console.log('projectId = ', val2);

            $state.go('ngoproof', { milestoneId: val1, projectId: val2, milestoneName: val3, projectName: vm.projectnm });
        };
        //Fetch all the document from the collection and store in the object
        var getAllDocument = function() {
            var val1 = $stateParams.milestoneId;
            var val2 = $stateParams.projectId;

            DocumentService.GetAllDocument(val1, val2).then(function(doc) {
                vm.document = doc;
            });
            ProofService.GetAllProof(val1, val2).then(function(doc) {
                vm.proof = doc;
            });
        };

        var getAllCurrency = function() {
            currency.GetAll().then(function(proj) {
                vm.currency = proj;
            });
        };




        getAllDocument();
        getAllCurrency();
        //vm.expense=$rootScope.vm.invoices.expenseItem


        vm.updateMilestone = function() {
                var status = 'Budgeted';
                var projid = vm.projectId;
                ProjectService.Update(projid, status)
                    .then(function(result) {
                        FlashService.Success('Milestone updated');
                        //vm.reset();
                        $state.go('donor');
                    })
                    .catch(function(error) {
                        FlashService.Error(error);
                    });
                $state.go('donor');
            }
            //Decides what to show based on user input
        vm.getTemplate = function(act) {
            if (act._id === vm.model.selected._id) {
                return 'editDocument';
            } else return 'displayDocument';
        };

        //Gets the documentdetails for which edit is to be done
        vm.editDocument = function(act, bal) {
            act.startDate = new Date(act.startDate);
            act.endDate = new Date(act.endDate);
            if (act.proofRqd == true) {
                act.proofRqd == "Yes";
            } else {
                act.proofRqd == "No";
            }
            vm.model.selected = angular.copy(act);
            vm.bal = bal;
            console.log('vm.bal==', vm.bal);
        };

        vm.updateActivity = function(activity) {
            activity.projectId = vm.projectId;
            activity.milestone = vm.mileName;
            console.log('activity to be updated==', activity);
            ActivityService.UpdateActivity(activity)
                .then(function() {
                    FlashService.Success('activity updated');

                });
        }

        vm.checkAgainstFundGoal = function(activity, action) {
            //activity.activityBudget+vm.grandTotal     = NAT
            //NMT vm.balance
            //vm.amount=NMT+NAT
            //if vm.amount < vm.totalFundGoal true
            console.log(vm.addActivity.proofRqd);
            vm.amount = parseFloat(vm.balance) + parseFloat(activity.activityBudget) + parseFloat(vm.grandTotal);
            console.log('vm.amount=', vm.amount);
            console.log(vm.amount <= vm.totalFundGoal);
            if (vm.amount <= vm.totalFundGoal) {
                if (action == 'ADD') {
                    vm.saveActivity(activity);
                } else {
                    vm.updateDocument(activity);
                }
            } else {
                FlashService.Error('Activity budget cannot exceed fund goal');
            }

        }

        vm.checkAgainstFundGoal1 = function(act) {
            //activity.activityBudget+vm.grandTotal     = NAT
            //NMT vm.balance
            //vm.amount=NMT+NAT
            //if vm.amount < vm.totalFundGoal true
            vm.amount1 = parseFloat(vm.bal) + parseFloat(vm.balance) + parseFloat(act.activityBudget);
            console.log('vm.amount1=', vm.amount1);
            console.log(vm.amount1 <= vm.totalFundGoal);
            if (vm.amount1 <= vm.totalFundGoal) {
                vm.updateDocument(act);
            } else {
                FlashService.Error('Activity budget cannot exceed fund goal');
            }

        }

        vm.saveActivity = function(activity) {
            if (vm.flag == 1) {
                activity.projectId = vm.projectId;
                activity.milestoneId = vm.milestoneId;
                activity.milestone = vm.mileName;
                //activity.status='Not Started';
                MilestoneService.CreateActivity(activity)
                    .then(function() {
                        console.log('inside save inv create');
                        FlashService.Success('New Activity saved');
                        $scope.vm.addActivity.activityName = '';
                        $scope.vm.addActivity.startDate = '';
                        $scope.vm.addActivity.endDate = '';
                        $scope.vm.addActivity.completionCriteria = '';
                        $scope.vm.addActivity.validationCheck = '';
                        $scope.vm.addActivity.activityBudget = '';
                        $scope.vm.addActivity.proofRqd = '';
                        getActivityById($stateParams.milestoneId); //#MG function called for instant refresh

                    })
                    .catch(function(error) {
                        FlashService.Error(error);
                    });

                //getActivityById($stateParams.milestoneId);
            } else {
                FlashService.Error('Activity budget cannot exceed fund goal');
            }
        }

        vm.grandTotal = null;
        var getActivityById = function(id) {
            ActivityService.GetActivityById(id).then(function(act) {
                vm.activity = act;
                console.log('vm.activity by ID=', vm.activity);
                var sum = 0;
                var amount = 0;
                for (var i = 0; i < act.length; i++) {
                    amount = parseFloat(act[i].activityBudget);
                    sum = sum + amount;
                }
                vm.grandTotal = sum;
                console.log('sum===', sum);
                console.log(vm.grandTotal <= vm.totalFundGoal);
                console.log(vm.grandTotal);
                console.log(vm.totalFundGoal);
                if (vm.grandTotal <= vm.totalFundGoal) {
                    console.log('MATCH FOUND');
                    vm.flag = 1;
                    console.log('vm.flag', vm.flag);
                }
                if (vm.grandTotal != vm.fundBudgeted) {
                    //if (confirm("Requested amount is" + vm.grandTotal + ". If you click ok," + vm.grandTotal + " will be set as your milestone budget")) {
                    MilestoneService.UpdateFundBudget($stateParams.milestoneId, vm.grandTotal).then(function() {
                        console.log('Fund Budeget updated');
                    });
                    // } else {
                    //     console.log('cancelled');
                    // }
                }
            });
        };
        getActivityById($stateParams.milestoneId);


        //Deletes the selected ocument
        vm.deleteActivity = function(act) {
            var _id = act._id;

            var projectId = act.projectId;
            var milestoneId = act.milestoneId;
            var activityId = act.activityId;
            var milestoneName = vm.mileName;
            var activityName = act.activityName;
            if (confirm("Are you sure you want to delete?")) {
                ActivityService.Delete(_id, projectId, milestoneId, activityId, milestoneName, activityName)
                    .then(function() {
                        FlashService.Success('Activity Deleted');
                        getActivityById($stateParams.milestoneId);
                        //$state.go('addMilestone');
                    })
                    .catch(function(error) {
                        FlashService.Error(error);
                    });
            } else {
                console.log('cancelled');
            }


        };

        //Reset the edit documentdetails
        vm.reset = function() {
            vm.model.selected = {};
            getActivityById($stateParams.milestoneId); //#MG refresh view
        };

        //Updates the selected documentdetails
        vm.updateDocument = function(act) {
            act.milestone = vm.mileName;
            ActivityService.UpdateActivity(act)
                .then(function() {
                    FlashService.Success('Activity updated');
                    vm.reset();
                    getActivityById($stateParams.milestoneId); //#MG function called for instant refresh
                    //$state.go('requestfund');
                })
                .catch(function(error) {
                    FlashService.Error(error);
                });

            //getActivityById($stateParams.milestoneId);
        };


        vm.saveProof = function(proof) {

            proof.milestoneId = vm.milestoneId;
            proof.projectId = vm.projectId;
            //proof.hash=vm.fileHashValue;
            proof.documentName = vm.FileName;
            var doc = {};
            doc["documentName"] = vm.FileName;
            //doc["documentPath"]=vm.fileHashValue;
            doc["documentPath"] = vm.hash;

            //vm.documentId=null;
            //console.log("vm.fileHashValue",vm.fileHashValue);
            DocumentService.Create(doc)
                .then(function(doc) {
                    console.log("doc=", doc.insertedIds[0]);
                    vm.documentId = doc.insertedIds[0];
                    proof.documentId = doc.insertedIds[0];
                    proof.milestoneId = vm.milestoneId;
                    proof.projectId = vm.projectId;
                    console.log('vm.milestoneId=', vm.milestoneId);
                    ProofService.Create(proof)
                        .then(function() {
                            FlashService.Success('Proof Saved Successfully');
                            //modal.style.display = "none";
                            //$state.go('document');
                        })
                        .catch(function(error) {
                            FlashService.Error(error);
                        });

                })
                .catch(function(error) {
                    FlashService.Error(error);
                });



        }


        vm.fileHashValue = null;
        vm.FileName = null;

        vm.getHashValue = function(proof) {
            var files = document.getElementById('file').files;
            console.log('files = ', files);
            console.log('filename=', files[0].name);
            vm.FileName = files[0].name;
            if (files.length > 0) {
                var reader = new FileReader();
                reader.readAsDataURL(files[0]);
                //reader.readAsText(files[0], MD5);
                reader.onload = function() {
                    console.log("Base64=", reader.result);
                    vm.fileHashValue = reader.result;

                };
                reader.onerror = function(error) {
                    console.log('Error: ', error);
                };
            }

        }

    }

})();