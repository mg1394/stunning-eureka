﻿/**
 * Created By :- Akshay
 * Created Date :- 13-06-2017 10:11 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Updated Date :- 06-07-2017 03:11 pm
 * Version :- 1.0.0 pass role
 */
var express = require('express');
var router = express.Router();
var request = require('request');
var config = require('config.json');
router.get('/', function (req, res) {
    // log user out
    req.session.destroy();
    res.render('login');
});

router.post('/', function (req, res) {
    // authenticate using api to maintain clean separation between layers
    request.post({
        url: config.apiUrl + '/users/authenticate',
        form: req.body,
        json: true
    }, function (error, response, body) {
        if (error) {
            return res.render('login', { error: 'An error occurred' });
        }

        if (!body.token) {
            return res.render('login', { error: body, username: req.body.username });
        }

        // save JWT token in the session to make it available to the angular app
        // This token will be used in Blockchain Api calls and will be attached in the header
        console.log('body.token.role = ',body.token.role);
        req.session.token = body.token.userToken;
        req.session.blockChainToken = body.token.token;
        req.session.username=req.body.username;
	      req.session.role=body.token.role;
	      console.log("role in sesiojn =",req.session.role);
        // redirect to returnUrl
        var returnUrl = req.query.returnUrl && decodeURIComponent(req.query.returnUrl) || '/';
        var usr = req.body.username;

        res.redirect(returnUrl);
    });
});

module.exports = router;
