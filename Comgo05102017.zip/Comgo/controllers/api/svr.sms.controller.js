var express = require('express');
var app = express();

const Nexmo = require('nexmo');
const nexmo = new Nexmo({
  apiKey: '428f569f',
  apiSecret: '4c63166461b8a296'
}, {debug: true});

app.post('/send', (req, res) => {
  // Send SMS
  nexmo.message.sendSms(
    '919969507545', req.body.toNumber, req.body.message, {type: 'unicode'},
    (err, responseData) => {if (responseData) {console.log(responseData)}}
  );
});
