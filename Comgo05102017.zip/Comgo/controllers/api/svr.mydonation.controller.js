/**
 * Created By :- Akshay
 * Created Date :- 10-06-2017 01:00 pm
 * Version :- 1.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var mydonation = require('services/svr.mydonation.service');

router.get('/all/:projId/:donorId', getAll);

module.exports = router;

function getAll(req,res) {
    var projId=req.params.projId;
    var donorId=req.params.donorId;

    mydonation.getAll(projId,donorId)
        .then(function (proj) {
            //console.log('The Projects are ' + proj);
            res.send(proj)
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}