/**
 * Created By :- Akshay
 * Created Date :- 12-06-2017 02:30 pm
 * Version :- 1.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var imageService = require('services/svr.projectimage.service');

router.get('/allByProjId/:_projId', GetImageByProjId);

module.exports = router;


function GetImageByProjId(req,res) {
    var projectId = req.params._projId;

    imageService.GetImageByProjId(projectId)
        .then(function (projectDet) {
            res.send(projectDet);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}