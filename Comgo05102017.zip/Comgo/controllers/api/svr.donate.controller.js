/**
 * Created By :- Madhura
 * Created Date :- 08-06-2017 13:13 pm
 * Version :- 1.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var donationService = require('services/svr.donate.service');

// routes
router.post('/create', createDonate);
router.get('/current', getCurrentDonate);
//router.put('/:_id', updateDonate);
router.delete('/:_id', deleteDonate);
router.get('/all', getAll);
module.exports = router;


function createDonate(req, res) {
    donationService.create(req,res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
        //console.log("req.body==",req.body);
}


function getCurrentDonate(req, res) {
    donationService.getById(req.body._id)
        .then(function (project) {
            if (project) {
                res.send(project);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

/*function updateDonate(req, res) {
    var projId = req.body._id;

    donationService.update(projId, req.body)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}*/

function deleteDonate(req, res) {
    var donId = req.url;
    donId = donId.replace("/", "")
    donationService.delete(donId)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getAll(req,res) {
  donationService.getAll()
    .then(function (don) {
      res.send(don)
    })
    .catch(function (err) {
      res.status(400).send(err);
    });
}
