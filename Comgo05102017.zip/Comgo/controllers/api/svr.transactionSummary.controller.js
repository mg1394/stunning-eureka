var config = require('config.json');
var express = require('express');
var router = express.Router();
var userService = require('services/svr.transactionSummary.service');

// routes
router.get('/all/:txnId', BKCGetTransactionDetails);

module.exports = router;

///////////////////////////////////////////////////////////////////////////////////////////////////////
//# Akshay :- 17-07-2017 save project to blockchain///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
function BKCGetTransactionDetails(req, res) {
    console.log("BKCGetTransactionDetails body = ", req.params);
    userService.BKCGetTransactionDetails(req, res).then(function(transaction) {
            res.send(transaction);
        })
        .catch(function(err) {
            res.status(400).send(err);
        });
}