/**
 * Created By :- Madhura
 * Created Date :- 24-08-2017 04:30 pm
 * Version :- 1.1
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var multer = require('multer');
var mkdirp = require('mkdirp');
//var os = require('os');



var storage = multer.diskStorage({

    destination: function(req, file, cb) {
        var dir = './images/' + req.query.projectId + '/';
        mkdirp(dir, function(err) {
            if (err) {
                console.error(err);
            }
            // move cb to here
            cb(null, dir);
            //cb(null, os.tmpdir());
        });
        //console.log('os.tmpdir() ',os.tmpdir());
        console.log("Upload: saved to " + dir + file.originalname );
    },
    filename: function(req, file, cb) {
        cb(null, "img1");
    }

})

var upload = multer({ storage: storage })

router.post('/', upload.single('file'), imageUpload );

module.exports = router;

function imageUpload(req,res) {
  console.log('svr imgupload cont',req.file);
    var projectId = req.params._projId;
}
