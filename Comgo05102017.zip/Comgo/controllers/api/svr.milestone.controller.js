/**
 * Created By :- Akshay
 * Created Date :- 09-06-2017 04:30 pm
 * Version :- 1.0
 * Updated By :- Madhura
 * Created Date :- 06-07-2017 12:30 pm
 * Version :- 1.1
 * Updated By :- Madhura
 * Created Date :- 11-07-2017 02:00 pm
 * Version :- 1.2
 * Updated By :- Akshay
 * Updated Date :- 22-07-2017 11:00 pm
 * Version :- 2.0.0 Add blockchain function
 * Updated By :- Madhura
 * Created Date :- 30-07-2017 12:00 pm
 * Version :- 1.0.4 send status on request fund
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var milService = require('services/svr.milestone.service');

router.get('/allByName/:_projId', getByProjname);
router.get('/getAllAudit/:_projId', getAllAudit);
router.post('/create', createMilestone);
router.post('/createAct', createActivity);
router.get('/all', getAll);
router.get('/allById/:_projId', getAllById);
router.put('/:_id', updateMilestone);
// #GM 060717 :- Update FundRequested in ProjectMilestone
router.get('/updateFundReq/:milestoneId/:fundReq', updateFundReq);
// #Akshay 27-07-2017 :- Update release in blockchain
router.get('/BKCFundReleased/:projectId/:milestoneId/:activityId/:fundBudgeted/:projectOwner', BKCFundReleased);

// #Akshay 27-07-2017 :- Update FundRequested in blockchain
// #Madhura :- 30-07-2017 send status
router.get('/BKCFundRequest/:milestoneId/:projectId/:activityId/:fundReq/:status', BKCFundRequest);

// #GM 060717 :- Update FundReleased in ProjectMilestone
router.get('/updateFundRel/:milestoneId/:fundRel', updateFundRel);

// #GM 060717 :- Update proof status in ProjectMilestone
router.get('/updateProofStatus/:milestoneId/:status', updateProofStatus);

//#MG :- Update fundBudgeted
router.get('/updateFundBudget/:milestoneId/:fundBudgeted', updateFundBudget);

router.get('/BKCAllByParams/:projectId', BKCGetAllDetailsByParams);

// #Akshay 07-08-2017 :- get all project details
router.get('/BKCGetAll/:projectId', BKCGetAllDetails);

// #Akshay 08-08-2017 :- fund allocate
router.post('/fundAllocate/:projectId/:milestoneId/:fundBudgeted', fundAllocateToMilestone);

router.delete('/:_id/:projectId/:milestoneId/:milestone', deleteDocument);

module.exports = router;

function BKCGetAllDetailsByParams(req,res) {

    milService.BKCGetAllDataByParams(req,res).then(function (data) {
      //console.log('data=',data);
        res.send(data);
        //res.sendStatus(200);
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// #Akshay 07-08-2017 :- get all project details 
function BKCGetAllDetails(req,res) {
    milService.BKCGetAllDetails(req,res).then(function (data) {
      //console.log('data=',data);
        res.send(data);
        //res.sendStatus(200);
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function updateMilestone(req, res) {
    var _id = req.body._id;
    console.log('req.body in mile cont = ',req.body);
    milService.update(req,res).then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getByProjname(req,res) {
    var projectId = req.params._projId;
    var milestoneId = req.params.milestoneId;
    console.log("mil id in cnntrl = ",milestoneId);

    milService.GetByProjname(projectId)
        .then(function (projectDet) {
            res.send(projectDet);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getAllAudit(req,res) {
    var projectId = req.params._projId;
    var milestoneId = req.params.milestoneId;
    console.log("mil id in get all audit = ",milestoneId);
    milService.getAllAudit(projectId)
        .then(function (projectDet) {
            res.send(projectDet);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// #GM 060717 :- Update FundRequested in ProjectMilestone
function updateFundReq(req,res) {
    var milestoneId = req.params.milestoneId;
    var fundReq = req.params.fundReq;
    milService.UpdateFundReq(milestoneId,fundReq)
        .then(function (projectDet) {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
// #Akshay 27-07-2017 :- Update release in blockchain
function BKCFundReleased(req,res) {
    var milestoneId = req.params.milestoneId;
    var projectId = req.params.projectId;
    var activityId = req.params.activityId;
    var projectOwner = req.params.projectOwner;
    console.log("activityId api-ser = = ",activityId);
    console.log("milestone api-ser = = ",milestoneId);
    console.log("project id api-ser = = ",projectId);
    console.log("projectOwner re api-ser = = ",projectOwner);
    milService.BKCFundReleased(req,res)
        .then(function (projectDet) {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// #Akshay 27-07-2017 :- Update FundRequested in blockchain
// #Madhura :- 30-07-2017 send status
function BKCFundRequest(req,res) {
    var milestoneId = req.params.milestoneId;
    var projectId = req.params.projectId;
    var activityId = req.params.activityId;
    var fundReq = req.params.fundReq;
    var status = req.params.status;
    console.log("activityId api-ser = = ",activityId);
    console.log("milestone api-ser = = ",milestoneId);
    console.log("project id api-ser = = ",projectId);
    console.log("fund re api-ser = = ",fundReq);
    console.log("fund req status= =", status);
    milService.BKCFundRequest(req,res)
        .then(function (projectDet) {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// #Akshay :- 22-07-2017 Add milestone to mongodb
function createMilestone(req, res) {
  console.log('milestone in svr cont=',req.body);
    milService.create(req,res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function createActivity(req, res) {
  console.log('activity in svr cont=',req.body);
    milService.createActivity(req,res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function fundAllocateToMilestone(req, res) {
  console.log('activity in svr cont=',req.params);
    milService.fundAllocateToMilestone(req,res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
// #GM 060717 :- Update FundReleased in ProjectMilestone
function updateFundRel(req,res) {
    var milestoneId = req.params.milestoneId;
    var fundRel = req.params.fundRel;
    milService.UpdateFundRel(milestoneId,fundRel)
        .then(function (projectDet) {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function updateProofStatus(req,res) {
    var milestoneId = req.params.milestoneId;
    var status = req.params.status;
    milService.UpdateProofStatus(milestoneId,status)
        .then(function (projectDet) {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

//#MG update fundBudgeted
function updateFundBudget(req,res) {
    var milestoneId = req.params.milestoneId;
    var fundBudgeted = req.params.fundBudgeted;
    milService.updateFundBudget(milestoneId,fundBudgeted)
        .then(function (projectDet) {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


function getAll(req,res) {

  milService.getAll()
    .then(function (doc) {
      //console.log('The Document are ' + doc);
      res.send(doc)
    })
    .catch(function (err) {
      res.status(400).send(err);
    });
}

function getAllById(req,res) {
    var projectId = req.params._projId;
    //console.log('projectId cont = ',projectId);
    milService.GetAllById(projectId)
        .then(function (projectDet) {
            res.send(projectDet);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function deleteDocument(req, res) {
    
    milService.delete(req,res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            console.log(err);
            res.status(400).send(err);
        });
}
