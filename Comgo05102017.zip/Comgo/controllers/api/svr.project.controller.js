/**
 * Created By :- Girijashankar Mishra
 * Created Date :- 08-05-2017 15:45 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Updated Date :- 17-07-2017 02:00 pm
 * Version :- 2.0.0 #akshay add project to blockchain
 * Updated By :- Akshay
 * Updated Date :- 29-07-2017 10:00 pm
 * Version :- 2.0.1 #akshay BKCpublishProject to blockchain
 * Updated By :- Akshay
 * Updated Date :- 17-08-2017 01:43 pm
 * Version :- 2.0.2 #project validation to blockchain
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var projService = require('services/svr.project.service');

// routes
router.post('/create', createProject);
router.put('/updateMilestoneStatus/:projId/:status',updateMilestoneStatus);
router.put('/saveRemarks/:projId/:remarks',saveRemarks);
router.post('/updateProject', updateProject);
router.post('/BKCProjectValidation/:projectId/:milestoneId/:activityId/:check',BKCProjectValidation);
router.get('/current', getCurrentProject);
router.put('/BKCpublishProject/:projId/:status/:milestoneId/:fundBudgeted', BKCpublishProject);
router.delete('/:_id', deleteProject);
router.get('/all', getAll);
router.get('/allByName/:_projectName', getByProjname);
router.get('/allById/:projId', getByProjId);

module.exports = router;


///////////////////////////////////////////////////////////////////////////////////////////////////////
//# Akshay :- 17-07-2017 save project to blockchain///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
/*function createProject(req,res) {
    projService.create(req,res).then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}*/

//#akshay :- 17-07-2017 add project by db using db function
function createProject(req, res) {
    projService.create(req,res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getCurrentProject(req, res) {
    projService.getById(req.body._id)
        .then(function (project) {
            if (project) {
                res.send(project);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function BKCpublishProject(req, res) {
     console.log("fundBudgeted in publish = ",req.params.fundBudgeted);
     projService.BKCpublishProject(req,res).then(function () {
     res.sendStatus(200);
     })
     .catch(function (err) {
     res.status(400).send(err);
     });
}

function updateMilestoneStatus(req, res) {
    projService.updateMilestoneStatus(req,res).then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

// Akshay :- 17-08-2017 project validation at blockchain
function BKCProjectValidation(req, res) {
    projService.BKCProjectValidation(req,res).then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function saveRemarks(req, res) {
    projService.saveRemarks(req,res).then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function updateProject(req, res) {
console.log('project in svr cont=',req.body);
    projService.updateProject(req, res).then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function deleteProject(req, res) {
    var projId = req.url;
    projId = projId.replace("/", "");
    projService.delete(projId)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getAll(req,res) {
  projService.getAll()
    .then(function (proj) {
      //console.log('The Projects are ' + proj);
      res.send(proj)
    })
    .catch(function (err) {
      res.status(400).send(err);
    });
}

function getByProjname(req,res) {
    var projectName = req.params._projectName;
    projService.GetByProjname(projectName)
        .then(function (projectDet) {
            //console.log('The Projects are ' + proj);
            res.send(projectDet);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getByProjId(req,res) {
    var projId = req.params.projId;
    projService.GetByProjId(projId)
        .then(function (projectDet) {
            console.log('The Projects are ' + projectDet);
            res.send(projectDet);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
