/**
 * Created By :- Akshay
 * Created Date :- 12-06-2017 04:00 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Created Date :- 13-06-2017 10:11 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Created Date :- 14-06-2017 01:00 pm
 * Version :- 1.0
 * Updated By :- Girijashankar
 * Created Date :- 15-06-2017 04:10 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Updated Date :- 24-06-2017 12:10 pm
 * Version :- 2.0.0
 * Updated By :- Madhura
 * Created Date :- 11-07-2017 09:00 am
 * Version :- 2.1.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var projectdonation = require('services/svr.projectdonation.service');

router.get('/allMyProject', getMyProject);
router.get('/allOtherProject', getOtherProject);
router.get('/allFunds', getAllFundDetails);
router.get('/allGroupBy', getAllProjectDonation);
router.get('/BKCMyFunds', BKCgetAllMyDonationDetails);

module.exports = router;

//#Akky : 24/06/2017//////////////////////////////////////
////////////////Blockchain Service Controller////////////
////////////////////////////////////////////////////////
//Get myproj data
function getAllFundDetails(req, res) {
    var token = req.session.blockChainToken;
    projectdonation.getAllFundDetails(token).then(function (data) {
      //console.log('data=',data);
        res.send(data);
        //res.sendStatus(200);
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
//#Madhura : Get my donation from blockchain
function BKCgetAllMyDonationDetails(req, res) {
    var token = req.session.blockChainToken;
    projectdonation.getAllMyFundDetails(token,req.session.username).then(function (data) {
      //console.log('data=',data);
        res.send(data);
        //res.sendStatus(200);
    })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
//send donorid and fuction call to db function and get responce from services/projectdonation.service
function getMyProject(req,res) {
    var donorId = req.session.username;
    projectdonation.getAllMyProject(donorId)
        .then(function (projectDet) {
            res.send(projectDet);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

//send donorid and fuction call to db function and get responce from services/projectdonation.service
function getOtherProject(req,res) {
    var donorId = req.session.username;
    projectdonation.getAllOtherProject(donorId)
        .then(function (projectDet) {
            res.send(projectDet);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

//send projid and fuction call to db function and get responce from services/projectdonation.service
/*function getAllFundDetails(req,res) {
    projectdonation.getAllFundDetails()
        .then(function (proj) {
            res.send(proj)
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}*/

function getAllProjectDonation(req,res) {
    projectdonation.getAllProjectDonation()
        .then(function (proj) {
            res.send(proj)
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
