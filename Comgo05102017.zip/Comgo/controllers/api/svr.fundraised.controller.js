/**
 * Created By :- Akshay
 * Created Date :- 14-06-2017 07:00 pm
 * Version :- 1.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var fundRaised = require('services/svr.fundraised.service');

router.get('/all/:projId', getAll);
router.get('/allFundRaisedByProjectId/:projId', getAllFromBlockChain)

module.exports = router;

function getAll(req,res) {
    var projId=req.params.projId;
    fundRaised.fundRaised(projId)
        .then(function (proj) {
            //console.log('The Projects are ' + proj);
            res.send(proj)
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getAllFromBlockChain(req,res) {
    var projId=req.params.projId;
    fundRaised.fundRaisedByBlockChain(req,res)
        .then(function (proj) {
            //console.log('The Projects are ' + proj);
            res.send(proj)
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}