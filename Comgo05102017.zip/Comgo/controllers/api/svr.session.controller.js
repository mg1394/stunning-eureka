/**
 * Created By :- Akshay
 * Created Date :- 17-06-2017 08:44 pm
 * Version :- 1.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();

router.get('/name', getSessionDetails);

module.exports = router;

function getSessionDetails(req,res) {
    //var name = req.session.username;
    var session = req.session;
    //console.log('req.session.role=',req.session.role);
            res.send(session);
            //res.send(role);
}
