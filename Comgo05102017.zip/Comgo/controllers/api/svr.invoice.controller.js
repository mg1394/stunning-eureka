/**
 * Created By :- Girijashankar Mishra
 * Created Date :- 08-05-2017 15:45 pm
 * Version :- 1.0
 * Updated By :- Madhura
 * Created Date :- 27-06-2017 11:30 am
 * Version :- 1.0
 * Updated By :- Madhura
 * Created Date :- 08-07-2017 04:11 pm
 * Version :- 1.0.1
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();

// routes
router.post('/create', createInvoice);
router.get('/current', getCurrentDocument);
router.put('/:_id', updateDocument);
router.delete('/:_id', deleteDocument);
router.get('/all', getAll);
router.get('/allById/:milestoneId', getAllById);//get expense items by milestoneId
module.exports = router;
var invoiceService = require('services/svr.invoice.service');


function createInvoice(req, res) {
  console.log('req.body==',req.body);
    invoiceService.create(req.body)
        .then(function (doc) {
            res.send(doc);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });

        /*docIdService.create(req.body)
            .then(function (doc) {
                res.sendStatus(doc);
            })
            .catch(function (err) {
                res.status(400).send(err);
            });*/

}

function getCurrentDocument(req, res) {
    invoiceService.getById(req.body._id)
        .then(function (document) {
            if (document) {
                res.send(document);
            } else {
                res.sendStatus(404);
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function updateDocument(req, res) {
    var docId = req.body._id;
    console.log('inv api cont');
console.log('docId=',docId);
console.log('req.body=',req.body);
    invoiceService.update(docId, req.body)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function deleteDocument(req, res) {
    var docId = req.url;
    docId = docId.replace("/", "");
    invoiceService.delete(docId)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function getAll(req,res) {

  invoiceService.getAll()
    .then(function (doc) {
      //console.log('The Document are ' + doc);
      res.send(doc)
    })
    .catch(function (err) {
      res.status(400).send(err);
    });
}

function getAllById(req,res) {
    var activityId = req.params.milestoneId;
    //console.log('activityId api cont = ',activityId);
    invoiceService.GetAllById(activityId)
        .then(function (activityDet) {
          //console.log('response api cont =',activityDet);
            res.send(activityDet);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
