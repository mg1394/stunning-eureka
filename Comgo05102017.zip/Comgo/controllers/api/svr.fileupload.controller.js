/**
 * Created By :- Madhura
 * Created Date :- 29-06-2017 04:30 pm
 * Version :- 1.0
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();

// routes
router.post('/create', createHash);

module.exports = router;
var fileService = require('services/svr.fileupload.service');


function createHash(req, res) {
  console.log('hash1 in api controller=',hash1);
    fileService.create(req.body)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
