var config = require('config.json');
var express = require('express');
var router = express.Router();
var userService = require('services/svr.user.service');

// routes
router.post('/authenticate', authenticateUser);
router.post('/register', registerUser);
/*router.put('/:_id', logoutUser);*/
module.exports = router;

function authenticateUser(req, res) {
    userService.authenticate(req.body.username, req.body.password)
        .then(function (token) {
            if (token) {
                // authentication successful
                res.send({ token: token });

            } else {
                // authentication failed
                res.status(401).send('Username or password is incorrect');
            }
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


function registerUser(req,res) {
    var username = req.body.username;
    console.log("params 1 = ",username);
    userService.create(req,res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

/*

function logoutUser(req, res) {
    var userId = req.user.sub;
    if (req.params._id !== userId) {
        // can only update own account
        return res.status(401).send('You can only update your own account');
    }

    userService.logout(userId, req.body)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}


}*/
