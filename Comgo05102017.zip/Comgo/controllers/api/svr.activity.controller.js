/**
 * Created By :- Madhura
 * Created Date :- 06-07-2017 05:30 pm
 * Version :- 1.1
 */
var config = require('config.json');
var express = require('express');
var router = express.Router();
var activityService = require('services/svr.activity.service');

router.get('/allByName/:_projId', getByProjname);
router.post('/create', createActivity);
router.get('/all', getAll);
router.get('/activityById/:milestoneId', getActivityById);
router.post('/updateActivity', updateActivity);
router.get('/activityByProjectId/:projectId', getActivityByProjectId);
router.delete('/:_id/:projectId/:milestoneId/:activityId/:milestoneName/:activityName', deleteDocument);

module.exports = router;


function getByProjname(req,res) {
    var projectId = req.params._projId;

    activityService.GetByProjname(projectId)
        .then(function (projectDet) {
            res.send(projectDet);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
function createActivity(req, res) {
    activityService.create(req.body)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}
function getAll(req,res) {

  activityService.getAll()
    .then(function (doc) {
      //console.log('The Document are ' + doc);
      res.send(doc)
    })
    .catch(function (err) {
      res.status(400).send(err);
    });
}

function getActivityById(req,res) {
  var milestoneId=req.params.milestoneId;
  activityService.getActivityById(milestoneId)
    .then(function (doc) {
      //console.log('The Document are ' + doc);
      res.send(doc)
    })
    .catch(function (err) {
      res.status(400).send(err);
    });
}

function getActivityByProjectId(req,res) {
  var projectId=req.params.projectId;
  activityService.getActivityByProjectId(projectId)
    .then(function (doc) {
      //console.log('The Document are ' + doc);
      res.send(doc)
    })
    .catch(function (err) {
      res.status(400).send(err);
    });
}

function updateActivity(req, res) {
  var _id = req.body._id;
console.log('activity in activity svr cont=',req.body);
    activityService.updateAct(req,res).then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

function deleteDocument(req, res) {
    activityService.delete(req,res)
        .then(function () {
            res.sendStatus(200);
        })
        .catch(function (err) {
            res.status(400).send(err);
        });
}

