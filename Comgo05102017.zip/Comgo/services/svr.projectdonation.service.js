/**
 * Created By :- Akshay
 * Created Date :- 12-06-2017 04:00 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Created Date :- 13-06-2017 10:12 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Created Date :- 14-06-2017 01:10 pm
 * Version :- 1.0
 * Updated By :- Girijashankar
 * Created Date :- 15-06-2017 04:20 pm
 * Version :- 1.0
 * Updated By :- Akshay
 * Updated Date :- 26-06-2017 02:20 pm
 * Version :- 2.0.0
 * Updated By :- Madhura
 * Updated Date :- 10-07-2017 04:20 pm
 * Version :- 2.0.1 #Change in BlockChain API
 */
var config = require('config.json');
var Join = require('mongo-join').Join;
var mongodb = require('mongodb');
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
const express = require('express');
const rp = require('request-promise');
const app = express();
var Promise = require("bluebird");
var request = Promise.promisifyAll(require("request"), {multiArgs: true});
var bodyParser = require('body-parser');
db.bind('ProjectDonation');

var service = {};

service.getAllMyProject = getAllMyProject;
service.getAllOtherProject = getAllOtherProject;
service.getAllFundDetails = getAllFundDetails;
service.getAllMyFundDetails = getAllMyFundDetails;
service.getAllProjectDonation = getAllProjectDonation;
module.exports = service;

////////////////////////////////////////////////////////
////////////////Blockchain Service//////////////////////
////////////////////////////////////////////////////////

//# akky : get all fund details


function getAllFundDetails(token) {
  //  var token = req.session.blockChainToken;
  //console.log("token in srv = ",token);
    var deferred = Q.defer();
    //# Akky : get myproj details from blockchain
    rp({
      //uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest?peer=peer1&fcn=invoke&args=%5B%22getHistory%22%2C%22donor%22%5D',
    uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest?peer=peer1&fcn=invoke&args=%5B%22getProjectsByRange%22%2C%22Project0%22%2C%22Project99%22%5D',
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+token
        }
    }).then(function (data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        //console.log('data====',data);
        deferred.resolve(data);
       // res.send(data,len);
    });
    return deferred.promise;
}

function getAllMyFundDetails(token,user) {
  //  var token = req.session.blockChainToken;
  //console.log("token in srv = ",token);
    var deferred = Q.defer();
    //# Akky : get myproj details from blockchain
    rp({
      uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest?peer=peer1&fcn=invoke&args=%5B%22getHistory%22%2C%22'+user+'%22%5D',
           headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+token
        }
    }).then(function (data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
       // console.log('data 2====',data);
        deferred.resolve(data);
       // res.send(data,len);
    });
    return deferred.promise;
}


//search by donorid and join function retrive data from ProjectDonation and Project collection
function getAllMyProject(donorId){
    var deferred = Q.defer();
    db.open(function(err, db) {
        db.collection('ProjectDonation', function (err, ProjectDonation) {
            ProjectDonation.find({donorId:donorId}, function (err, Project) {
                //for sorting based on projectId
                Project.sort(['projectId','asc']);
                var join = new Join(db).on({
                    field: 'projectId', // <- field in ProjectDonation doc
                    to: '_id',         // <- field in project doc. treated as ObjectID automatically.
                    from: 'Project'  // <- collection name for project doc
                });
                join.toArray(Project, function(err, joinedDocs) {
                    deferred.resolve(joinedDocs);
                    // handle array of joined documents here
                });

            });
        });

    });
    return deferred.promise;
}


//search by donorid and join function retrive data from ProjectDonation and Project collection
function getAllOtherProject(donorId){
    var deferred = Q.defer();
    db.open(function(err, db) {
        db.collection('ProjectDonation', function (err, ProjectDonation) {
            //console.log(ProjectDonation.projectId);
            //ProjectDonation.find({$and: [ { projectId: { $ne: ProjectDonation.projectId } }, { donorId: ProjectDonation.donorId  } ]}, function (err, Project) {
            ProjectDonation.find({donorId:{$ne : donorId}}, function (err, Project) {
                //for sorting based on projectId
                Project.sort(['projectId','asc']);
                var join = new Join(db).on({
                    field: 'projectId', // <- field in ProjectDonation doc
                    to: '_id',         // <- field in project doc. treated as ObjectID automatically.
                    from: 'Project'  // <- collection name for project doc
                });
                join.toArray(Project, function(err, joinedDocs) {
                    deferred.resolve(joinedDocs);
                    //console.log(joinedDocs);
                    // handle array of joined documents here
                });
            });
        });

    });
    return deferred.promise;
}

//get fund details
/*function getAllFundDetails() {
    var deferred = Q.defer();
    db.ProjectDonation.aggregate(
        { $group: { _id : {projectId : "$projectId"}, sum : { $sum: "$amount" },
                          projectId:{$first:'$projectId'}
                  }
        },
        {
            $sort:{projectId:1}
        },
        function (err,result) {
            deferred.resolve(result);
        }
    );
    return deferred.promise;
}
*/

//get fund details
function getAllProjectDonation() {
    var deferred = Q.defer();
     db.ProjectDonation.aggregate(
        { $group: { _id : {projectId : "$projectId",donorId:'$donorId'}, sum : { $sum: "$amount" },
                          projectId:{$first:'$projectId'},donorId:{$first:'$donorId'}
                  }
        },
        {
            $sort:{projectId:1}
        },
        function (err,result) {
            deferred.resolve(result);
        }
    );
    return deferred.promise;
}
