/**
 * Created By :- Akshay
 * Created Date :- 09-06-2017 04:30 pm
 * Version :- 1.0
 */
var config = require('config.json');
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('ProjectImage');

var service = {};

service.GetImageByProjId = GetImageByProjId;

module.exports = service;


function GetImageByProjId(_projectId) {
    var deferred = Q.defer();
    db.ProjectImage.find({projectId : mongo.helper.toObjectID(_projectId)}).toArray(function (err, milestone) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(milestone);
    });
    return deferred.promise;
}

