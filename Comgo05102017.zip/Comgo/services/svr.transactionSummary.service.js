/**
 * Created By :- Akshay
 * Created Date :- 31-07-2017 21:28 pm
 * Version :- 1.0.0
 */
var config = require('config.json');
var Join = require('mongo-join').Join;
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var mongodb = require('mongodb');
var Db = mongodb.Db;
var Server = mongodb.Server;
var random = require("random-js")(); // uses the nativeMath engine
var rp = require('request-promise');
var db = mongo.db(config.connectionString, { native_parser: true });

var service = {};

service.BKCGetTransactionDetails = BKCGetTransactionDetails;

module.exports = service;


///////////////////////////////////////////////////////////////////////////////////////////////////////
//# Akshay :- 31-07-2017 get transaction history from blockchain///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
function BKCGetTransactionDetails(req,res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    // console.log("blockChainToken in proj serv  =  ",blockChainToken);
    // console.log("body in final 2= ",req.params);
    var txnId = req.params.txnId;
    rp({
        uri:'http://104.199.170.142/channels/mychannel/transactions/'+txnId+'?peer=peer1',
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+blockChainToken
        }
    }).then(function (err,data) {
        if(typeof data == 'undefined'){
            data=err;
            console.log("data 2 =",data);
        }       
        deferred.resolve(data);
    }).catch(function (error) {
        // POST failed...
        console.log('err = ',error);
    });
     return deferred.promise;
}