/**
 * Created By :- Akshay
 * Created Date :- 08-06-2017 05:0 pm
 * Version :- 1.0.0
 * Updated By :- Akshay
 * Updated Date :- 17-07-2017 10:0 am
 * Version :- 1.0.0
 * Updated By :- Akshay
 * Updated Date :- 29-07-2017 10:00 pm
 * Version :- 2.0.1 #akshay BKCpublishProject to blockchain
 * Updated By :- Akshay
 * Updated Date :- 17-08-2017 01:43 pm
 * Version :- 2.0.2 #project validation to blockchain
 * Updated By :- Akshay
 * Updated Date :- 17-08-2017 01:43 pm
 * Version :- 2.0.3 #audit trail go to blockchain
 */
var config = require('config.json');
var Join = require('mongo-join').Join;
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var mongodb = require('mongodb');
var Db = mongodb.Db;
var Server = mongodb.Server;
var random = require("random-js")(); // uses the nativeMath engine
var rp = require('request-promise');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('Project');
db.bind('AuditTable');
var service = {};
var ftuc =0;


service.getById = getById;
service.getAll = getAll;
//service.create = create;
//service.create = checkProjectID;//bc code commented
service.create =insertProjectToMongo;
service.updateMilestoneStatus = updateMilestoneStatus;
service.saveRemarks = saveRemarks;
service.BKCpublishProject = BKCpublishProject;
service.BKCProjectValidation = BKCProjectValidation;
service.updateProject = updateProject;
service.delete = _delete;
service.getAll = getAll;
service.GetByProjname = getByProjname;
service.GetByProjId = getByProjid;

module.exports = service;

function getById(_id) {
    var deferred = Q.defer();
    db.Project.findById(_id, function (err, project) {
        if (err) deferred.reject(err.name + ': ' + err.message);

        if (project) {
            // return user (without hashed password)
            deferred.resolve(_.omit(project, 'hash'));
        } else {
            // user not found
            deferred.resolve();
        }
    });

    return deferred.promise;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////
//# Akshay :- 17-07-2017 save project to blockchain///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
function checkProjectID(req,res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    console.log("blockChainToken in proj serv  =  ",blockChainToken);
    var uuid = random.integer(0000001,9999999);
    var projectName = req.body.projectName;
    var projectId = "Project"+uuid;
    rp({
        uri:'http://104.199.170.142/channels/mychannel/chaincodes/mycc?peer=peer1&args=%5B%22read%22%2C%22'+projectId+'%22%5D',
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+blockChainToken
        }
    }).then(function (err,data) {
        console.log("data 2 =",data);
        if(!data){
            req.params.projectId=projectId;
            create(req,res);
        }else{
            deferred.resolve(data);
        }
    }).catch(function (error) {
        // POST failed...
        console.log('err = ',error);
    });
     return deferred.promise;
}

function create(req,res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    console.log("token  =  ",blockChainToken);
    var projectId = req.params.projectId;
    var projectName = req.body.projectName;
    var projectType = req.body.projectType;
    var fundGoal =req.body.fundgoal;

    var body ="{"+
            "\"peers\": [\"localhost:7051\", \"localhost:7056\"],"+
            "\"fcn\":\"invoke\","+
            "\"args\":[\"init_project\",\""+projectId+"\",\""+projectName+"\",\""+projectType+"\"]"+
        "}";
        console.log("body 1 = ",body);
    rp({
        method:'POST',
        uri:'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
        body:body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+blockChainToken
        }
    }).then(function (data) {
        console.log("data 3 =",data);
        if(!data){
            //deferred.reject(err.name + ': ' + err.message);
            deferred.resolve(res);
            res.send(data);
        }else{
            transferProjectToNgo(req,res);
        }
    });
    return deferred.promise;
}

function transferProjectToNgo(req,res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    var projectId = req.params.projectId;
    var projectName = req.body.projectName;
    var projectType = req.body.projectType;

    var body ="{"+
            "\"peers\": [\"localhost:7051\", \"localhost:7056\"],"+
            "\"fcn\":\"invoke\","+
            "\"args\":[\"transfer_project\",\""+projectId+"\",\"ngo\"]"+"}";
        console.log("body =",body);
    rp({
        method:'POST',
        uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
        body:body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+blockChainToken
        }
    }).then(function (data) {
        if (!data){
            console.log("data in transfer to ngo = ",data);
            //if (err) deferred.reject(err.name + ': ' + err.message);
            deferred.resolve(res);
            res.send(data);
        }else{
            insertProjectToMongo(req,res);
        }

    });
    return deferred.promise;
}

// #Akshay :- 17-07-2017 add project by using db
function insertProjectToMongo(req,res) {
    var deferred = Q.defer();
    var project = req.body;
    console.log('project 1 =',project);
    var uuid = random.integer(0000001,9999999);
    //var projectName = req.body.projectName;
    var projectId = "Project"+uuid;
    project.projectId = projectId;
    
        db.Project.insert(
            project,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                console.log("doc = ",doc);
                auditTrail(req,res);
                deferred.resolve();
            });
    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail go to db
function auditTrail(req,res){
    console.log('project=',req.body);
    // var temp = JSON.stringify(doc.ops[0].projectId);
    var projectId = req.body.projectId;
    var role = req.session.role;
    var username = req.session.username;
    var deferred = Q.defer();
    var set = {
        updatedDate : Date(),
        projectId : projectId,
        role : role,
        username : username,
        currentStatus : 'Project Created'
    };
    console.log("set = ",set);
        db.AuditTable.insert(
            set,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                deferred.resolve();
        });
    return deferred.promise;
}

function updateProject(req, res) {
    var deferred = Q.defer();
    console.log('req.body.projectId=',req.body.projectId);
    var projectId = req.body.projectId;
    // validation
    db.Project.findById(projectId, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateProjectDetails();

    });

    function updateProjectDetails() {
        // fields to update
        var set = {

            projectOwner: req.body.projectOwner,
            projectType: req.body.projectType,
            projectName: req.body.projectName,
            description: req.body.description,
            fundGoal: parseFloat(req.body.fundGoal),
            currency: req.body.currency,
            country: req.body.country,
            startDate: req.body.startDate,
            endDate: req.body.endDate,
        };
        db.Project.update(
            { projectId: projectId },
            { $set: set },
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                auditTrailForUpdateProject(req,res);
                deferred.resolve();
            });
    }
    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail go to db
function auditTrailForUpdateProject(req,res){
    var deferred = Q.defer();
    var projectId = req.body.projectId;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate : Date(),
        projectId : projectId,
        role : role,
        username : username,
        currentStatus : 'Project Updated'
    };
    console.log("set = ",set);
        db.AuditTable.insert(
            set,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                deferred.resolve();
        });
    return deferred.promise;
}

function updateMilestoneStatus(req, res) {
    var deferred = Q.defer();
    var projectId = req.params.projId;
    var status = req.params.status;
    // validation
    db.Project.findById(projectId, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateProject();

    });

    function updateProject() {
      console.log("status=  = ",status);
        // fields to update
        var set = {
            status:status,
        };
        console.log("set in update function = ",set)
        db.Project.update(
            { projectId: projectId },
            { $set: set },
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                auditTrailUpdateMilestoneStatus(req,res);
                deferred.resolve();
            });
    }

    return deferred.promise;
}


// Akshay :- 02-08-2017 Audit trail for update milestone go to db
function auditTrailUpdateMilestoneStatus(req,res){
    var deferred = Q.defer();
    var projectId =  req.params.projId;
    var status = req.params.status;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate : Date(),
        projectId : projectId,
        role : role,
        username : username,
        currentStatus : 'Milestone Updated',
        previousStatus : status
    };
    console.log("set = ",set);
        db.AuditTable.insert(
            set,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                deferred.resolve();
        });
    return deferred.promise;
}


function saveRemarks(req, res) {
    var deferred = Q.defer();
    var projectId = req.params.projId;
    var remarks = req.params.remarks;
    // validation
    db.Project.findById(projectId, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateProject();

    });

    function updateProject() {
      console.log("remarks=  = ",remarks);
        // fields to update
        var set = {
            remarks:remarks,
        };
        console.log("set in update function = ",set)
        db.Project.update(
            { projectId: projectId },
            { $set: set },
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                deferred.resolve();
            });
    }

    return deferred.promise;
}


function BKCpublishProject(req, res) {
    var deferred = Q.defer();
    var projectId = req.params.projId;
    var status = req.params.status;
    // validation
    db.Project.findById(projectId, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateProject();

    });

    function updateProject() {
      console.log("status=  = ",status);
        // fields to update
        var set = {
            status:status,
        };
        console.log("set in update function = ",set)
        db.Project.update(
            { projectId: projectId },
            { $set: set },
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                publishProject(req,res);
                //deferred.resolve();
            });
    }

    return deferred.promise;
}

// # Akshay :- 26-07-2017 call invoke function and send projectid to blockchain published project
function publishProject(req,res) {
 var deferred = Q.defer();
 var blockChainToken = req.session.blockChainToken;
 var projectId = req.params.projId;
 var milestoneId = req.params.milestoneId;
 console.log("proj id fund in publish = ",milestoneId);

 var fundBudgeted = req.params.fundBudgeted;
 console.log("proj id fund in publish = ",fundBudgeted);

 console.log("proj id publish = ",req.params.projId);
 var body ="{"+
    "\"peers\": [\"localhost:7051\", \"localhost:7056\"],"+
    "\"fcn\":\"invoke\","+
    "\"args\":[\"invke\",\""+projectId+"\"]"+"}";
console.log('publish body ===',body);
    rp({
           method:'POST',
           uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
           body:body,
           headers: {
           'User-Agent': 'Request-Promise',
           'Content-Type': 'application/json',
           'Authorization': 'Bearer '+blockChainToken
           }
    }).then(function (data) {
 //if (err) deferred.reject(err.name + ': ' + err.message);
    console.log("res after publish = ",data);
        if(data){
            auditTrailPublishProject(req,res);
        } else{
        deferred.resolve(data);
        // res.send(data);
     }
    });
    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail go to db
function auditTrailPublishProject(req,res){
    var deferred = Q.defer();
    var projectId = req.params.projId;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate : Date(),
        projectId : projectId,
        currentStatus : 'Project Published',
        previousStatus : 'Approved'
    };
    console.log("set = ",set);
        db.AuditTable.insert(
            set,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                deferred.resolve();
        });
    return deferred.promise;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
//# Akshay :- 27-07-2017 project validation at blockchain///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
function BKCProjectValidation(req, res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    console.log("token  =  ", blockChainToken);
    var projectId = req.params.projectId;
    console.log("projectId= ", projectId);
    var milestoneId = req.params.milestoneId;
    console.log("milestoneId= ", milestoneId);
    var activityId = req.params.activityId;
    console.log("activityId= ", activityId);
    var validationCheck  = req.params.check; 
    console.log("validation check = ",validationCheck);
    // var test = 'test';
    var body = "{" +
        "\"peers\": [\"localhost:7051\", \"localhost:7056\"]," +
        "\"fcn\":\"invoke\"," +
        "\"args\":[\"validate_docs\",\"" + projectId + "\",\"" + milestoneId + "\",\"" + activityId + "\",\"" + validationCheck + "\"]" +
        "}";
    console.log("project validation body = ", body);
    rp({
        method: 'POST',
        uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + blockChainToken
        }
    }).then(function(data) {
        console.log("project validation responce  =", data);
        deferred.resolve(res);
    });
    return deferred.promise;
}

function _delete(_id, userParam) {
    var deferred = Q.defer();
    db.Project.remove(
        { _id: mongo.helper.toObjectID(_id) },
        function (err) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            deferred.resolve();
        });

    return deferred.promise;
}


function getAll() {
  var deferred = Q.defer();

  db.Project.find().toArray(function (err, cust) {
    if (err) deferred.reject(err.name + ': ' + err.message);
    deferred.resolve(cust);
  });

  return deferred.promise;
}

function getByProjname(_projectName) {
    var deferred = Q.defer();
    db.Project.find({projectName : mongo.helper.toObjectID(_projectName) }).toArray(function (err, project) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(project);
    });
    return deferred.promise;
}

function getByProjid(projId) {
    var deferred = Q.defer();
    db.Project.find({projectId : mongo.helper.toObjectID(projId) }).toArray(function (err, project) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(project);
    });
    return deferred.promise;
}
