/**
 * Created By :- Girijashankar Mishra
 * Created Date :- 08-05-2017 15:30 pm
 * Version :- 1.0
 * Created By :- Akshay
 * Updated Date :- 16-08-2017 10:30 pm
 * Version :- 1.0.1
 */

var config = require('config.json');
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
var rp = require('request-promise');
var http = require('http');
var MessagingResponse = require('twilio').twiml.MessagingResponse;
var accountSid = 'AC249e01d68e120daaef74c4d9c8a0228c';
//var accountSid = 'ACf97a290c33c2107fb3b1e4317aef0266';
var authToken = 'b56b2d1c6b5a1e1c1bddacfce7ff92f8';
//var authToken = 'cbb0d86f36af3697403c755cc1802dee';
var twilioNumber = '+16194859251';
//var twilioNumber = '+14125047607';
//var toNumber = '+918828564967';
var express = require('express');
var replace = require("replace");
// var datetime = require('node-datetime');
var app = express();

// require the Twilio module and create a REST client
var client = require('twilio')(accountSid, authToken);
db.bind('Document');
db.bind('MessageTemplate');
db.bind('AuditTable');
db.bind('User');

var service = {};
var ftuc = 0;

service.getById = getById;
service.getAll = getAll;
service.create = create;
service.update = update;
service.delete = _delete;
service.getAll = getAll;

module.exports = service;


function getById(_id) {
    var deferred = Q.defer();
    db.Document.findById(_id, function(err, document) {
        if (err) deferred.reject(err.name + ': ' + err.message);

        if (document) {
            // return user (without hashed password)
            deferred.resolve(_.omit(document, 'hash'));
        } else {
            // user not found
            deferred.resolve();
        }
    });

    return deferred.promise;
}

function create(req, res) {
    var deferred = Q.defer();
    //console.log(" in bc submit proof = ",req.body);
    var document = {
        documentName: req.body.documentName,
        documentPath: req.body.documentPath,
        documentHash: req.body.documentHash
    }
    console.log("documrnt  = ", document);
    db.Document.insert(
        document,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            console.log('this goes in document table=', doc);
            if (doc) {
                BKCSubmitProof(req, res);
                // GetSMSByType(req,res);
                deferred.resolve(doc);
            }

        });
    return deferred.promise;
}

function BKCSubmitProof(req, res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    var projectId = req.body.allId.projectId;
    var milestoneId = req.body.allId.milestoneId;
    var activityId = req.body.allId.activityId;
    var documentHash = req.body.documentHash;
    var body = "{" +
        "\"peers\": [\"localhost:7051\", \"localhost:7056\"]," +
        "\"fcn\":\"invoke\"," +
        "\"args\":[\"submit_proof\",\"" + projectId + "\",\"" + milestoneId + "\",\"" + activityId + "\",\"" + documentHash + "\"]" + "}";
    // console.log("proof body = ",body);
    rp({
        method: 'POST',
        uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + blockChainToken
        }
    }).then(function(data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        console.log("res after proof submit = ", data);
        auditTrailSubmitProof(req,res);
        
        deferred.resolve(data);

    });
    return deferred.promise;
}


// Akshay :- 02-08-2017 Audit trail for fund request go to db
function auditTrailSubmitProof(req,res){
    var deferred = Q.defer();
    var projectId = req.params.projectId;
    var milestoneId = req.params.milestoneId;
    console.log("milestoneId= ", milestoneId);
    var activityId = req.params.activityId;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate : Date(),
        projectId : projectId,
        milestoneId : milestoneId,
        activityId : activityId,  
        role : role,
        username : username,
        currentStatus : 'Fund Requested',
        previousStatus : 'Fund Allocated'
    };
    console.log("set = ",set);
        db.AuditTable.insert(
            set,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                GetSMSByType(req, res);
                deferred.resolve();
        });
    return deferred.promise;
}
////////////////////////////////////////////////////////////////////
//////////////////#Akshay : - get sms by type ////////////////////
////////////////////////////////////////////////////////////////
function GetSMSByType(req, res) {
    var deferred = Q.defer();

    var type = req.body.allId.role;
    console.log('type==',type.trim());
    type=type.trim();
    db.MessageTemplate.find({ messageType:type }).toArray(function(err, SMS) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        console.log("get all err = ",err);
        console.log("get all sms = ", SMS);
        console.log("body = ", req.body);
        var projectName = req.body.allId.projectName;
        var activityName = req.body.allId.activityName;

        console.log("name = ", projectName);
        var SMSBody = SMS[0].smsBody;
        console.log("sms body = ", SMSBody);
        var temp2 = SMSBody.replace("*****", activityName);
        console.log("temp = ", temp2);
        var temp3 = temp2.replace("####", projectName);
        var date = Date();
        console.log("date = ", date);
        req.finalSMS = temp3.replace("----", date);
        console.log("temp4 = ", req.finalSMS);
        sendSMS(req, res);
        deferred.resolve(SMS);
    });
    return deferred.promise;
}

////////////////////////////////////////////////////////////////////
//////////////////#Akshay :-get GetContactInfo ///////////////////
////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////
//////////////////#Akshay : - send sms ///////////////////////////
////////////////////////////////////////////////////////////////
function sendSMS(req,res) {
    var deferred = Q.defer();
    var body =  req.finalSMS;
    console.log("getting sms = ", body);
    var username = req.session.username;
    console.log("username = ",username);
    db.User.find({ username: username }).toArray(function(err, contactDetails) {
        console.log("get contact = ",contactDetails);
        var mobilleNumber = contactDetails[0].phone;
        console.log("mob num = ",'+91'+mobilleNumber);
        client.messages
        .create({
            to: '+91'+mobilleNumber,
            from: twilioNumber,
            body: body,
            //   mediaUrl: 'https://c1.staticflickr.com/3/2899/14341091933_1e92e62d12_b.jpg',
        })
        .then(message => console.log(message.sid));
    })
    return deferred.promise;
}

// #Akshay : - 15-08-2017
app.post('/sms', (req, res) => {
    var twiml = new MessagingResponse();

    twiml.message('Thanku You!');

    res.writeHead(200, { 'Content-Type': 'text/xml' });
    res.end(twiml.toString());
});

/*
function BKCValidateProof(req,res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    var projectId = req.body.allId.projectId;
    var milestoneId = req.body.allId.milestoneId;
    var activityId =req.body.allId.activityId;
    var body ="{"+
            "\"peers\": [\"localhost:7051\", \"localhost:7056\"],"+
            "\"fcn\":\"invoke\","+
            "\"args\":[\"validate_docs\",\""+projectId+"\",\""+milestoneId+"\",\""+activityId+"\"]"+"}";
           // console.log("proof body = ",body);
    rp({
        method:'POST',
        uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
        body:body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+blockChainToken
        }
    }).then(function (data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        console.log("res after proof submit = ",data);
        deferred.resolve(data);
        res.send(data);
    });
    return deferred.promise;
}
*/


function update(_id, userParam) {
    var deferred = Q.defer();

    // validation
    db.Document.findById(_id, function(err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateDocument();

    });

    function updateDocument() {
        // fields to update
        var set = {
            ProofType: userParam.ProofType,
            DocumentName: userParam.DocumentName,
            Amount: userParam.Amount,
            Currency: userParam.Currency,
            Remarks: userParam.Remarks,
        };
        db.Document.update({ _id: mongo.helper.toObjectID(_id) }, { $set: set },
            function(err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
    }

    return deferred.promise;
}

function _delete(_id, userParam) {
    var deferred = Q.defer();
    db.Document.remove({ _id: mongo.helper.toObjectID(_id) },
        function(err) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            deferred.resolve();
        });

    return deferred.promise;
}


function getAll(milestoneId, projectId) {
    //console.log("im in svr doc 1 = ",milestoneName);
    var deferred = Q.defer();
    db.Document.find({ $and: [{ milestoneId: milestoneId }, { projectId: projectId }] }).toArray(function(err, doc) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(doc);
    });
    return deferred.promise;
}