/**
 * Created By :- Madhura
 * Created Date :- 08-06-2017 13:13 pm
 * Version :- 1.0
 */

var config = require('config.json');
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
const rp = require('request-promise');
db.bind('ProjectDonation');
db.bind('AuditTable');

var service = {};
var ftuc =0;

service.getById = getById;
service.getAll = getAll;
//service.create = create;
service.update = update;
service.delete = _delete;
service.getAll = getAll;
//#AM : 24.06.2017 call blockchain function
service.create = saveDonate;

module.exports = service;

//#AM : 24.06.2017 Save donation details//////////
////////////////Blockchain Service//////////////////////
///////////////////////////////////////////////////////
function saveDonate(req,res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    var projectId = req.body.projectId;
    console.log("param proj id donate = ",req.params.projectId);
    var amount = req.body.amount;
    console.log('blockChainToken in donserv= ',blockChainToken);
    console.log('projectId = ',projectId);
    console.log('amount = ',amount);
    var body ="{"+
            "\"peers\": [\"localhost:7051\", \"localhost:7056\"],"+
            "\"fcn\":\"invoke\","+
            "\"args\":[\"fund_project\",\""+projectId+"\",\"Donation9\",\""+amount+"\"]"+
        "}";
    console.log('body = ',body);
    rp({
        method:'POST',
        uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
        body:body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+blockChainToken
        }
    }).then(function (data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);

        console.log("res = ",data);
        auditTrailSaveDonation(req,res)
        deferred.resolve(res);
        // res.send(data);
    });
    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail for update milestone go to db
function auditTrailSaveDonation(req,res){
    var deferred = Q.defer();
    var activity = req.body;
    var projectId = activity.projectId;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate : Date(),
        projectId : projectId,
        milestoneId : activity.milestoneId,
        activityId : activity.activityId,
        activityName:activity.activityName,
        milestone : activity.milestone,
        role : role,
        username : username,
        currentStatus : 'Donation',
        previousStatus : 'NA'
    };
    console.log("set = ",set);
        db.AuditTable.insert(
            set,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                deferred.resolve();
        });
    return deferred.promise;
}
function getById(_id) {
    var deferred = Q.defer();
    db.ProjectDonation.findById(_id, function (err, donate) {
        if (err) deferred.reject(err.name + ': ' + err.message);

        if (donate) {
            // return user (without hashed password)
            deferred.resolve(_.omit(project, 'hash'));
        } else {
            // user not found
            deferred.resolve();
        }
    });

    return deferred.promise;
}

function create(donate) {
    var deferred = Q.defer();
    /*function createDonate() {*/

        db.ProjectDonation.insert(
            donate,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
  /*  }*/

    return deferred.promise;
}


function update(_id, userParam) {
    var deferred = Q.defer();

    // validation
    db.ProjectDonation.findById(_id, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateDonate();

    });

    function updateDonate() {
        // fields to update
        var set = {
            projectName  : userParam.projectName,
            description: userParam.description,
            ngo: userParam.ngo,
            fundgoal: userParam.fundgoal,

        };


        db.ProjectDonation.update(
            { _id: mongo.helper.toObjectID(_id) },
            { $set: set },
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
    }

    return deferred.promise;
}

function _delete(_id, userParam) {
    var deferred = Q.defer();
    db.ProjectDonation.remove(
        { _id: mongo.helper.toObjectID(_id) },
        function (err) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            deferred.resolve();
        });

    return deferred.promise;
}


function getAll() {
  var deferred = Q.defer();

  db.ProjectDonation.find().toArray(function (err, cust) {
    if (err) deferred.reject(err.name + ': ' + err.message);
    deferred.resolve(cust);
  });

  return deferred.promise;
}
