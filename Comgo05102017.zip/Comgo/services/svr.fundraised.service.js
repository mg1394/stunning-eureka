/**
 *Created By :- Akshay
 * Created Date :- 14-06-2017 07:05 pm
 * Version :- 1.0
 */
var config = require('config.json');
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
const rp = require('request-promise');

db.bind('ProjectDonation');

var service = {};

service.fundRaised = fundRaised;
service.fundRaisedByBlockChain = fundRaisedByBlockChain;

module.exports = service;

function fundRaised(projId) {
    var deferred = Q.defer();
    db.ProjectDonation.find({projectId: projId}).toArray(function (err, fundraised) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(fundraised);
    });
    return deferred.promise;
}

function fundRaisedByBlockChain(req,res) {
    var projectId=req.params.projId;
    var token = req.session.blockChainToken;
    var deferred = Q.defer();
    //# GM 11072017 : get fundRaised details from blockchain
    rp({
      uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest?peer=peer1&fcn=invoke&args=%5B%22getHistory%22%2C%22'+projectId+'%22%5D',
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+token
        }
    }).then(function (data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        //console.log('data====',data);
        deferred.resolve(data);
       // res.send(data,len);
    });
    return deferred.promise;

}