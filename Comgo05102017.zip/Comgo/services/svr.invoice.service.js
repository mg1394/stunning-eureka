/**
 * Created By :- Girijashankar Mishra
 * Created Date :- 08-05-2017 15:30 pm
 * Version :- 1.0
 * Updated By :- Madhura
 * Created Date :- 08-07-2017 04:11 pm
 * Version :- 1.0.1
 */

var config = require('config.json');
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('ProjectInvoice');

var service = {};
var ftuc =0;

service.getById = getById;
service.getAll = getAll;
service.create = create;
service.update = update;
service.delete = _delete;
service.getAll = getAll;
service.GetAllById = GetAllById;

module.exports = service;


function getById(_id) {
    var deferred = Q.defer();
    db.ProjectInvoice.findById(_id, function (err, document) {
        if (err) deferred.reject(err.name + ': ' + err.message);

        if (document) {
            // return user (without hashed password)
            deferred.resolve(_.omit(document, 'hash'));
        } else {
            // user not found
            deferred.resolve();
        }
    });

    return deferred.promise;
}
//get expense items by milestoneId
function GetAllById(activityId) {
    //console.log('_activityId in invoiceService = ',activityId);
    var deferred = Q.defer();
    db.ProjectInvoice.find({activityId : activityId}).toArray(function (err, milestone) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(milestone);
        //console.log('response invoiceService =',milestone);
    });
    return deferred.promise;
}

function create(document) {
    var deferred = Q.defer();
    /*function createDocument() {*/
console.log('document==',document);
        db.ProjectInvoice.insert(
            document,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                //console.log('this goes in document table=',doc);
                deferred.resolve(doc);
            });
  /*  }*/

    return deferred.promise;
}

function update(_id, userParam) {
    var deferred = Q.defer();

    // validation
    db.ProjectInvoice.findById(_id, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateDocument();

    });

    function updateDocument() {
        // fields to update
        var set = {
            poNumber  : userParam.poNumber,
            poDate: userParam.poDate,
            invoiceNo: userParam.invoiceNo,
            invoiceDate: userParam.invoiceDate,
            expenseItem: userParam.expenseItem,
            description: userParam.description,
            unitCost: userParam.unitCost,
            quantity: userParam.quantity,
            total: userParam.total,
            activityId: userParam.activityId,
        };
        db.ProjectInvoice.update(
            { _id: mongo.helper.toObjectID(_id) },
            { $set: set },
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
    }

    return deferred.promise;
}

function _delete(_id, userParam) {
    var deferred = Q.defer();
    db.ProjectInvoice.remove(
        { _id: mongo.helper.toObjectID(_id) },
        function (err) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            deferred.resolve();
        });

    return deferred.promise;
}


function getAll() {
  var deferred = Q.defer();

db.ProjectInvoice.find().toArray(function (err, cust) {
  if (err) deferred.reject(err.name + ': ' + err.message);
  deferred.resolve(cust);
});

return deferred.promise;
}
