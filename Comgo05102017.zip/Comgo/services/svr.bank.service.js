/**
 * Created By :- Madhura
 * Created Date :- 12-06-2017 13:13 pm
 * Version :- 1.0
 */

var config = require('config.json');
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('Bank');

var service = {};

service.getAll = getAll;

module.exports = service;

function getAll() {
  var deferred = Q.defer();

var bankDetails={'AccountNo':'GP1770000245',
                  'BICNo':'YESB0000001',
                  'cname':'madhura gawde',
                  'cno':'432-987-456-110',
                  'expiry':'06-19',
                  'cvv':'***'};
/*
var cardinfo={'cname':'madhura gawde',
              'cno':'432-987-456-110',
              'expiry':'06-19',
              'cvv':'***'};*/
  /*db.Bank.find().toArray(function (err, cust) {
    if (err) deferred.reject(err.name + ': ' + err.message);
    deferred.resolve(cust);
  });*/
  deferred.resolve(bankDetails);
  //deferred.resolve(cardinfo);

  return deferred.promise;
}
