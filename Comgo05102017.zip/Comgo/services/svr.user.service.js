﻿require('controllers/svr.login.controller.js');
var config = require('config.json');
var _ = require('lodash');
var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');
var Q = require('q');

//Variables are defined for getting details from Blockchain
var express = require('express');
var rp = require('request-promise');
var app = express();
var errors = require('request-promise/errors');
///////////////////////////////////////////////////////////

var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('User');

var service = {};
var ftuc =0;

service.authenticate = authenticate;
service.create = create;

module.exports = service;

function authenticate(username, password) {
    var deferred = Q.defer();

    db.User.findOne({ username: username }, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);

        if (user && bcrypt.compareSync(password, user.hash)) {
            // #GM 260617 :- Generate token for Blockchain API services to work
            var body  = 'username='+username+'&orgName=org1';
            rp({
                method: 'POST',
                uri: 'http://104.199.170.142/users',
                body:body,
                headers: {
                    'User-Agent': 'Request-Promise',
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }).then(function (data) {
                //Token Generated for blockcahin api
                var tokenData = JSON.parse(data);
                // Token Generated for logged in user
                var userToken = jwt.sign({ sub: user._id }, config.secret);
                tokenData["userToken"] = userToken;
                tokenData["role"] = user.role.toLowerCase();
                deferred.resolve(tokenData);
            }).catch(errors.StatusCodeError, function (reason) {
                // The server responded with a status codes other than 2xx.
                // Check reason.statusCode
                deferred.resolve();
            }).catch(errors.RequestError, function (reason) {
                // The request failed due to technical reasons.
                // reason.cause is the Error object Request would pass into a callback.
                deferred.resolve();
            })
        } else {
            // authentication failed
            deferred.resolve();
        }
    });

    return deferred.promise;
}

function create(req,res) {
    var deferred = Q.defer();
 var userParam = req.body;
 console.log("userparam = ",userParam.username);
    // validation
    db.User.findOne(
        { username: userParam.username },
        function (err, user) {
            if (err) deferred.reject(err);

            if (user) {
                // username already exists
                deferred.reject('Username "' + userParam.username + '" is already taken');
            } else {
                createUser();
            }
        });

    function createUser() {
        // set user object to userParam without the cleartext password
        var user = _.omit(userParam, 'password');

        // add hashed password to user object
        user.hash = bcrypt.hashSync(userParam.password, 10);

        db.User.insert(
            user,
            function (err, doc) {
                if (err) deferred.reject(err);
                registration(req, res);
                deferred.resolve();
            });
    }

    return deferred.promise;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
//# Akshay :- 08-08-2017 registration to blockchain///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
function registration(req, res) {
    var deferred = Q.defer();
    var username = req.body.username;
    var body = 'username='+username+'&orgName=org1' ;
    console.log("req body = ", body);
    rp({
        method: 'POST',
        uri: 'http://104.199.170.142/users',
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/x-www-form-urlencoded'
        }
    }).then(function(data) {
        // if (err) deferred.reject(err);
        console.log("parse === ",data);
        req.data = data ;
        initUser(req, res);
        // deferred.resolve(res);
    });
    return deferred.promise;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////
//# Akshay :- 08-08-2017 init user to blockchain///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
function initUser(req, res) {
    var deferred = Q.defer();
    var data = req.data ;
    var data = JSON.parse(data);
    console.log("data in init = ",data);
    var blockChainToken = data.token;
    console.log("token =",blockChainToken);

    var username = req.body.username;
    var role = req.body.role;
    var body = "{" +
       "\"peers\": [\"localhost:7051\", \"localhost:7056\"]," +
       "\"fcn\":\"invoke\"," +
       "\"args\":[\"init_"+role+"\",\"" + username + "\",\"Foundation_Company\"]" +
       "}";
       var bodys ={
                  "peers": ["localhost:7051", "localhost:7056"],
                  "fcn":"invoke",
                  "args":["init_foundation",username,"Foundation_Company"]
                }

    console.log("req body = ", body);

    rp({
        method: 'POST',
        uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + blockChainToken
        }
    }).then(function(data) {
        console.log("after init =", data);
        deferred.resolve(res);
        // res.send(data);
    });
    return deferred.promise;
}

/*
////////////////////////////////////////////////////////////////////////////////////////////////////////
//Akky : 26062017 Create chaincode at blockchain///////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
function createChannel(blockchainToken) {
    var authorization ='Bearer '+blockchainToken;
    var deferred = Q.defer();
        var body =  {
            'channelName':'mychannel',
            'channelConfigPath':'../artifacts/channel/mychannel.tx'
        };
        rp({
            method: 'POST',
            uri: 'http://localhost:4000/channels',
            body: body,
            headers: {
                'User-Agent': 'Request-Promise',
                'Content-Type': 'application/json',
                'Authorization':authorization
            },
            json : true
        }).then(function (data) {
            console.log('create channel data = ',data);
            //joinChannel(blockchainToken);
            //deferred.resolve();

        }).catch(errors.StatusCodeError, function (reason) {
            // The server responded with a status codes other than 2xx.
            // Check reason.statusCode
            //deferred.resolve();
        }).catch(errors.RequestError, function (reason) {
            // The request failed due to technical reasons.
            // reason.cause is the Error object Request would pass into a callback.
            //deferred.resolve();
        });

}

//////////////////////////////////////////////////////////////////////////////////////////////////////
//Akky : 26062017 Join chaincode at blockchain///////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
function joinChannel(blockchainToken) {
    var authorization ='Bearer '+blockchainToken;
    var deferred = Q.defer();
    var body =  {
        'peers': ['localhost:8071','localhost:8056']
    };
    rp({
        method: 'POST',
        uri: 'http://localhost:4000/channels/mychannel/peers',
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization':authorization
        },
        json : true
    }).then(function (data) {
        console.log('join channel data = ',data);
        //installChaincode(blockchainToken);

        deferred.resolve();
    }).catch(errors.StatusCodeError, function (reason) {
        // The server responded with a status codes other than 2xx.
        // Check reason.statusCode
        console.log('join channel data 2= ',reason);
        deferred.resolve();
    }).catch(errors.RequestError, function (reason) {
        // The request failed due to technical reasons.
        // reason.cause is the Error object Request would pass into a callback.
        console.log('join channel data3 = ',reason);
        deferred.resolve();
    });

}

//////////////////////////////////////////////////////////////////////////////////////////////////////
//Akky : 26062017 Install chaincode at blockchain/////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
function installChaincode(blockchainToken) {
    var authorization ='Bearer '+blockchainToken;
    var deferred = Q.defer();
    var body =  {
        'peers': ['localhost:8071','localhost:8056'],
            'chaincodeName':'mycc',
            'chaincodePath':'github.com/comgo',
            'chaincodeVersion':'v0'
    };
    rp({
        method: 'POST',
        uri: 'http://localhost:4000/chaincodes',
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization':authorization
        },
        json : true
    }).then(function (data) {
        console.log('install chaincode data 21 = ',data);
        //instatiateChaincode(blockchainToken);
        deferred.resolve();
    }).catch(errors.StatusCodeError, function (reason) {
        // The server responded with a status codes other than 2xx.
        // Check reason.statusCode
        deferred.resolve();
    }).catch(errors.RequestError, function (reason) {
        // The request failed due to technical reasons.
        // reason.cause is the Error object Request would pass into a callback.
        deferred.resolve();
    });

}

////////////////////////////////////////////////////////////////////////////////////////////////////////
//Akky : 26062017 Instatiate chaincode at blockchain///////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////
function instatiateChaincode(blockchainToken) {
    var authorization ='Bearer '+blockchainToken;
    var deferred = Q.defer();
    var body =  {
        'peers': ['localhost:8071'],
        'chaincodeName':'mycc',
        'chaincodeVersion':'v0',
        'functionName':'init',
        'args':['44444']
    };
    rp({
        method: 'POST',
        uri: 'http://localhost:4000/channels/mychannel/chaincodes',
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization':authorization
        },
        json : true
    }).then(function (data) {
        console.log('Instatiate channel data 31 = ',data);
        deferred.resolve();
    }).catch(errors.StatusCodeError, function (reason) {
        // The server responded with a status codes other than 2xx.
        // Check reason.statusCode
        deferred.resolve();
    }).catch(errors.RequestError, function (reason) {
        // The request failed due to technical reasons.
        // reason.cause is the Error object Request would pass into a callback.
        deferred.resolve();
    });

}*/
