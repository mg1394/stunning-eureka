/**
 * Created By :- Madhura
 * Created Date :- 27-06-2017 11:30 am
 * Version :- 1.0
 */

var config = require('config.json');
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('Proof');
const Nexmo = require('nexmo');
const nexmo = new Nexmo({
    apiKey: '428f569f',
    apiSecret: '4c63166461b8a296'
}, { debug: true });


var service = {};
var ftuc = 0;

service.create = create;
service.getAll = getAll;

module.exports = service;

function create(proof) {
    var deferred = Q.defer();
    /*function createDocument() {*/

    db.Proof.insert(
        proof,
        function(err, proof) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            console.log('this goes in proof table=', proof);
            // nexmo.message.sendSms(
            //     '919969507545', '919819775480', 'Proof submitted successfully='+proof._id, {type: 'unicode'},
            //     (err, responseData) => {if (responseData) {console.log(responseData)}}
            // );
            deferred.resolve(proof);
        });
    /*  }*/

    return deferred.promise;
}

function getAll(activityId, projectId) {
    console.log("im in svr doc 1 = ", activityId);
    var deferred = Q.defer();
    db.Proof.find({ $and: [{ activityId: activityId }, { projectId: projectId }] }).toArray(function(err, doc) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(doc);
    });
    return deferred.promise;
}