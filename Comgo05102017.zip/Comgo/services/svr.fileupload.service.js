/**
 * Created By :- Girijashankar Mishra
 * Created Date :- 08-05-2017 15:30 pm
 * Version :- 1.0
 */

var config = require('config.json');
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('Document');

var service = {};
var ftuc =0;

service.create = create;

module.exports = service;


function create(document) {
    var deferred = Q.defer();
    /*function createDocument() {*/

        db.Document.insert(
            document,
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                console.log('this goes in document table as hash=',doc);
                deferred.resolve(doc);
            });
  /*  }*/

    return deferred.promise;
}
