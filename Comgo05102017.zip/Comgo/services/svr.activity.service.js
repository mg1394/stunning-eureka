/**
 * Created By :- Madhura
 * Created Date :- 06-07-2017 05:30 pm
 * Version :- 1.1
 * Updated By :- Akshay
 * Updated Date :- 17-08-2017 04:30 pm
 * Version :- 1.0.1 # Add audit trail into db
 */
var config = require('config.json');
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var db = mongo.db(config.connectionString, { native_parser: true });
db.bind('ProjectActivity');
db.bind('AuditTable');

var service = {};

service.GetByProjname = GetByProjname;
service.create = create;
service.getAll = getAll;
service.getActivityById = getActivityById;
service.getActivityByProjectId = getActivityByProjectId;
service.updateAct = updateAct;
service.delete = _delete;

module.exports = service;

/*function updateAct(_id, userParam) {
    var deferred = Q.defer();
    //console.log('req.body.projectId=',req.body.projectId);
    //var projectId = req.body.projectId;
    // validation
    db.ProjectActivity.findById(_id, function (err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateActivityDetails();

    });

    function updateActivityDetails() {
        // fields to update
        var set = {

            activityName:userParam.activityName,
            completionCriteria:userParam.completionCriteria,
            validationCheck:userParam.validationCheck,
            startDate:userParam.startDate,
            endDate:userParam.endDate,


        };


        db.ProjectActivity.update(
            { _id: mongo.helper.toObjectID(_id) },
            { $set: set },
            function (err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
    }

    return deferred.promise;
}*/
function updateAct(req, res) {
    var deferred = Q.defer();
    // validation
    var _id = req.body._id;
    var userParam = req.body;
    db.ProjectActivity.findById(_id, function(err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateActivityDetails();

    });

    function updateActivityDetails() {
        // fields to update

        var set = {
            activityName: userParam.activityName,
            completionCriteria: userParam.completionCriteria,
            validationCheck: userParam.validationCheck,
            startDate: userParam.startDate,
            endDate: userParam.endDate,
            activityBudget: userParam.activityBudget,
            proofRqd: userParam.proofRqd,

        };
        db.ProjectActivity.update({ _id: mongo.helper.toObjectID(_id) }, { $set: set },
            function(err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                auditTrailForUpdateActivity(req, res);
                deferred.resolve();
            });
    }

    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail for update milestone go to db
function auditTrailForUpdateActivity(req, res) {
    var deferred = Q.defer();
    var activity = req.body;
    var projectId = activity.projectId;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate: Date(),
        projectId: projectId,
        milestoneId: activity.milestoneId,
        activityId: activity.activityId,
        activityName: activity.activityName,
        milestone: activity.milestone,
        role: role,
        username: username,
        currentStatus: 'Activity Updated',
        previousStatus: 'Not Initiated'
    };
    console.log("set = ", set);
    db.AuditTable.insert(
        set,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            deferred.resolve();
        });
    return deferred.promise;
}

function GetByProjname(_projectId) {
    var deferred = Q.defer();
    db.ProjectActivity.find({ projectId: _projectId }).toArray(function(err, milestone) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(milestone);
    });
    return deferred.promise;
}

function create(project) {
    var deferred = Q.defer();
    /*function createProject() {*/

    db.ProjectActivity.insert(
        project,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);

            deferred.resolve();
        });
    /*  }*/

    return deferred.promise;
}

function getAll() {
    var deferred = Q.defer();

    db.ProjectActivity.find().toArray(function(err, cust) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(cust);
    });

    return deferred.promise;
}

function getActivityById(milestoneId) {
    var deferred = Q.defer();
    db.ProjectActivity.find({ milestoneId: milestoneId }).toArray(function(err, milestone) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(milestone);
    });
    return deferred.promise;
}

function getActivityByProjectId(projectId) {
    var deferred = Q.defer();
    db.ProjectActivity.find({ projectId: projectId }).toArray(function(err, milestone) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(milestone);
    });
    return deferred.promise;
}

function _delete(req, res) {
    var deferred = Q.defer();
    var _id = req.params._id;
    console.log("_id = = ", _id);
    db.ProjectActivity.remove({ _id: mongo.helper.toObjectID(_id) },
        function(err) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            auditTrailDeleteActivity(req, res);
            deferred.resolve();
        });

    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail for update milestone go to db
function auditTrailDeleteActivity(req, res) {
    var deferred = Q.defer();
    // var activity = req.body;
    console.log("_id = = ", req.params);
    var projectId = req.params.projectId;
    var milestoneId = req.params.milestoneId;
    var activityId = req.params.activityId;
    var milestoneName = req.params.milestoneName;
    var activityName = req.params.activityName;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate: Date(),
        projectId: projectId,
        milestoneId: milestoneId,
        milestone: milestoneName,
        activityName: activityName,
        activityId: activityId,
        role: role,
        username: username,
        currentStatus: 'Activity Deleted',
        previousStatus: 'Not Initiated'
    };
    console.log("set = ", set);
    db.AuditTable.insert(
        set,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            deferred.resolve();
        });
    return deferred.promise;
}