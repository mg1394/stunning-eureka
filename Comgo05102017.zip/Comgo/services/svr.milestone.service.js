/**
 * Created By :- Akshay
 * Created Date :- 09-06-2017 04:30 pm
 * Version :- 1.0
 * Updated By :- Madhura
 * Created Date :- 06-07-2017 12:30 pm
 * Version :- 1.1
 * Updated By :- Madhura
 * Created Date :- 11-07-2017 02:00 pm
 * Version :- 1.2
 * Updated By :- Akshay
 * Updated Date :- 22-07-2017 11:00 pm
 * Version :- 2.0.0 Add blockchain function
 * Updated By :- Akshay
 * Updated Date :- 26-07-2017 02:20 pm
 * Version :- 2.0.1 Add project and milestone to db
 * Updated By :- Madhura
 * Created Date :- 30-07-2017 12:00 pm
 * Version :- 1.0.4 send status on request fund
 * Updated By :- Akshay
 * Created Date :- 17-08-2017 02:00 pm
 * Version :- 1.0.4 Audit Trail for db
 */
var config = require('config.json');
var _ = require('lodash');
var Q = require('q');
var mongo = require('mongoskin');
var random = require("random-js")(); // uses the nativeMath engine
var db = mongo.db(config.connectionString, { native_parser: true });
//var random = require("random-js")(); // uses the nativeMath engine
db.bind('ProjectMilestone');
db.bind('ProjectActivity');
db.bind('AuditTable');

const rp = require('request-promise');

var service = {};

service.GetByProjname = GetByProjname;
// #Akshay :-19-08-2017 get all audit
service.getAllAudit = getAllAudit;
service.create = createMilestone;
service.createActivity = createActivity;
service.getAll = getAll;
service.GetAllById = GetAllById;
service.update = update;
service.delete = _delete;
// #GM 060717 :- Update FundRequested in ProjectMilestone
service.UpdateFundReq = UpdateFundReq;
// #Akshay 27-07-2017 :- Update release in blockchain
service.BKCFundReleased = BKCFundReleased;

// #Akshay 27-07-2017 :- Update FundRequested in blockchain
// #Madhura :- 30-07-2017 send status to db
service.BKCFundRequest = BKCFundRequest;

// #GM 060717 :- Update FundReleased in ProjectMilestone
service.UpdateFundRel = UpdateFundRel;

// #GM 060717 :- Update proof status in ProjectMilestone
service.UpdateProofStatus = UpdateProofStatus;

//MG update fundBudgeted
service.updateFundBudget = updateFundBudget;

service.BKCGetAllDataByParams = BKCGetAllDataByParams;

//#Akshay :- get history from blockchain
service.BKCGetAllDetails = BKCGetAllDetails;

// #Akshay 27-07-2017 :- Update FundRequested in blockchain
service.FundRequest = FundRequest;

// #Akshay 08-08-2017 :- fund allocate to blockchain
service.fundAllocateToMilestone = fundAllocateToMilestone;


module.exports = service;


//get
function BKCGetAllDataByParams(req, res) {
    var token = req.session.blockChainToken;
    var param = req.params.projectId;
    console.log("project id = ", param);
    //console.log("token in srv = ",token);
    var deferred = Q.defer();
    rp({
        uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest?peer=peer1&fcn=invoke&args=%5B%22read%22%2C%22' + param + '%22%5D',
        //  uri:'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest?peer=peer1&fcn=invoke&args=%5B%22getHistory%22%2C%22'+param+'%22%5D',
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        }
    }).then(function(data) {
        // console.log("milestone data = ",data);
        deferred.resolve(data);
        // res.send(data,len);
    });
    return deferred.promise;
}
//#Akshay :- get history from blockchain
function BKCGetAllDetails(req, res) {
    var token = req.session.blockChainToken;
    var param = req.params.projectId;
    console.log("project id = ", param);
    //console.log("token in srv = ",token);
    var deferred = Q.defer();
    rp({
        // uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest?peer=peer1&fcn=invoke&args=%5B%22read%22%2C%22'+param+'%22%5D',
        uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest?peer=peer1&fcn=invoke&args=%5B%22getHistory%22%2C%22' + param + '%22%5D',
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + token
        }
    }).then(function(data) {
        // console.log("milestone data = ",data);
        deferred.resolve(data);
        // res.send(data,len);
    });
    return deferred.promise;
}

/*function GetByProjname(donorId){
    var deferred = Q.defer();
    db.open(function(err, db) {
        db.collection('ProjectDonation', function (err, ProjectDonation) {
            //console.log(ProjectDonation.projectId);
            //ProjectDonation.find({$and: [ { projectId: { $ne: ProjectDonation.projectId } }, { donorId: ProjectDonation.donorId  } ]}, function (err, Project) {
            ProjectDonation.find({donorId:{$ne : donorId}}, function (err, Project) {
                //for sorting based on projectId
                Project.sort(['projectId','asc']);
                var join = new Join(db).on({
                    field: 'projectId', // <- field in ProjectDonation doc
                    to: '_id',         // <- field in project doc. treated as ObjectID automatically.
                    from: 'Project'  // <- collection name for project doc
                });
                join.toArray(Project, function(err, joinedDocs) {
                    deferred.resolve(joinedDocs);
                    //console.log(joinedDocs);
                    // handle array of joined documents here
                });
            });
        });

    });
    return deferred.promise;
}*/

function GetByProjname(_projectId) {
    console.log(_projectId);
    var deferred = Q.defer();
    db.ProjectMilestone.find({ projectId: _projectId }).toArray(function(err, milestone) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        //console.log('milestone==',milestone);
        deferred.resolve(milestone);
    });
    return deferred.promise;
}

// # Akshay :- 19-08-2017 get all audit from audit table
function getAllAudit(projectId) {
    console.log(projectId);
    var deferred = Q.defer();
    db.AuditTable.find({ projectId: projectId }).toArray(function(err, milestone) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        //console.log('milestone==',milestone);
        deferred.resolve(milestone);
    });
    return deferred.promise;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
//# Akshay :- 22-07-2017 save milestone to blockchain///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
/*function createMilestone(req,res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    console.log("blockChainToken in mil serv  =  ",blockChainToken);
    var projectId = req.body.projectId;
    var milestoneName = req.body.milestone;
    var uuid = random.integer(0000001,9999999);
    var milestoneId = "Milestone"+uuid;
    req.params.milestoneId = milestoneId;
    var test = 'test';
    var body ="{"+
            "\"peers\": [\"localhost:7051\", \"localhost:7056\"],"+
            "\"fcn\":\"invoke\","+
            "\"args\":[\"init_milestone\",\""+projectId+"\",\""+test+"\",\""+milestoneName+"\",\""+milestoneId+"\"]"+
        "}";
        console.log("milestone body = ",body);
    rp({
        method:'POST',
        uri:'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
        body:body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+blockChainToken
        }
    }).then(function (data) {
        console.log("milestone responce  =",data);
         if(data){
            createActivity(req,res);
        }else{
            deferred.resolve(res);
            res.send(data);
        }
    });
    return deferred.promise;
}
*/
///////////////////////////////////////////////////////////////////////////////////////////////////////
//# Akshay :- 22-07-2017 save milestone to blockchain///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
/*function createActivity(req,res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    console.log("token  =  ",blockChainToken);
    var projectId = req.body.projectId;
    console.log("req.body in act 1= ",projectId);
    var milestoneId = req.params.milestoneId;
    console.log("req.body in act 2= ",milestoneId);
    var activityName = req.body.activityName;
    console.log("req.body in act 3= ",activityName);
    var uuid = random.integer(0000001,9999999);
    var activityId = "Activity"+uuid;
    console.log("req.body in act 4= ",activityId);
    console.log("req.body in act 5= ",req.body);
    var fundAllocated = req.body.fundAllocated;
    var validationCheck = req.body.validationCheck;
   // var test = 'test';
    var body ="{"+
            "\"peers\": [\"localhost:7051\", \"localhost:7056\"],"+
            "\"fcn\":\"invoke\","+
            "\"args\":[\"init_activity\",\""+projectId+"\",\""+milestoneId+"\",\""+activityName+"\",\""+activityId+"\",\""+fundAllocated+"\",\""+validationCheck+"\"]"+
        "}";
        console.log("activity body = ",body);
    rp({
        method:'POST',
        uri:'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
        body:body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer '+blockChainToken
        }
    }).then(function (data) {
        console.log("activity responce  =",data);
            deferred.resolve(res);
            res.send(data);
    });
    return deferred.promise;
}*/



// #Akshay :- 26-07-2017 add milestone and activity to ProjectMilestone and ProjectActivity
function createMilestone(req, res) {
    var milestone = req.body;
    var uuid = random.integer(0000001, 9999999);
    //var projectName = req.body.projectName;
    var milestoneId = "Milestone" + uuid;
    milestone.milestoneId = milestoneId;
    req.params.activity = milestone;
    var mil = {
        milestone: milestone.milestone,
        startDate: milestone.startDate,
        endDate: milestone.endDate,
        fundBudgeted: milestone.fundBudgeted,

        projectId: milestone.projectId,
        milestoneId: milestone.milestoneId
    }
    var deferred = Q.defer();
    db.ProjectMilestone.insert(
        mil,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            auditTrailForCreateMilestone(req, res);
            deferred.resolve(doc);
        });
    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail go to db
function auditTrailForCreateMilestone(req, res) {
    var deferred = Q.defer();
    var milestone = req.body;
    var projectId = milestone.projectId;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate: Date(),
        projectId: projectId,
        milestoneId: milestone.milestoneId,
        milestone: milestone.milestone,
        role: role,
        username: username,
        currentStatus: 'Milestone Created',
        previousStatus: 'Not Initiated'
    };
    console.log("set = ", set);
    db.AuditTable.insert(
        set,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            deferred.resolve();
        });
    return deferred.promise;
}

function createActivity(req, res) {
    var activity = req.body;
    console.log("act my = ", activity);
    var uuid = random.integer(0000001, 9999999);
    //var projectName = req.body.projectName;
    var activityId = "Activity" + uuid;
    activity.activityId = activityId;
    var act = {
        activityName: activity.activityName,
        validationCheck: activity.validationCheck,
        completionCriteria: activity.completionCriteria,
        startDate: activity.startDate,
        endDate: activity.endDate,
        projectId: activity.projectId,
        milestoneId: activity.milestoneId,
        activityBudget: activity.activityBudget,
        activityId: activity.activityId,
        proofRqd: activity.proofRqd,
        status: 'Not Started'
    }
    console.log('act in svr service===', act);
    var deferred = Q.defer();
    db.ProjectActivity.insert(
        act,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            auditTrailForCreateActivity(req, res);
            deferred.resolve(doc);
        });
    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail go to db
function auditTrailForCreateActivity(req, res) {
    var deferred = Q.defer();
    var activity = req.body;
    var projectId = activity.projectId;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate: Date(),
        projectId: projectId,
        milestoneId: activity.milestoneId,
        activityId: activity.activityId,
        activityName: activity.activityName,
        milestone: activity.milestone,
        role: role,
        username: username,
        currentStatus: 'Activity Created',
        previousStatus: 'Not Initiated'
    };
    console.log("set = ", set);
    db.AuditTable.insert(
        set,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            deferred.resolve();
        });
    return deferred.promise;
}

function getAll() {
    var deferred = Q.defer();

    db.ProjectMilestone.find().toArray(function(err, cust) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(cust);
    });

    return deferred.promise;
}

function GetAllById(_projectId) {
    //console.log('_projectId = ',_projectId);
    var deferred = Q.defer();
    db.ProjectMilestone.find({ projectId: _projectId }).toArray(function(err, milestone) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        deferred.resolve(milestone);
    });
    return deferred.promise;
}
// #GM 060717 :- Update FundRequested in ProjectMilestone
function UpdateFundReq(_id, fundReq) {
    var deferred = Q.defer();

    // validation
    db.ProjectMilestone.findById(_id, function(err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateProjectMilestone();

    });

    function updateProjectMilestone() {
        // fields to update
        var set = {
            fundRequested: fundReq,
            status: 'Not Started'
        };


        db.ProjectMilestone.update({ milestoneId: _id }, { $set: set },
            function(err, milestone) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
    }

    return deferred.promise;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////
//# Akshay :- 27-07-2017 fund relese to blockchain///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
function BKCFundReleased(req, res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    console.log("token  =  ", blockChainToken);
    var projectId = req.params.projectId;
    console.log("projectId= ", projectId);
    var milestoneId = req.params.milestoneId;
    console.log("milestoneId= ", milestoneId);
    var activityId = req.params.activityId;
    console.log("activityId= ", activityId);
    var fundBudgeted = req.params.fundBudgeted;
    console.log("fundBudgeted= ", fundBudgeted);
    var projectOwner = req.params.projectOwner;
    console.log("projectOwner = ", projectOwner);
    var fundAllocated = req.body.fundAllocated;
    var validationCheck = req.body.validationCheck;
    var uuid = random.integer(0000001, 9999999);
    var TXREFNUMBER = "TXREFNUMBER" + uuid;

    var uuid = random.integer(0000001, 9999999);
    var TXNSTATUS = "TXNSTATUS" + uuid;


    // var test = 'test';
    var body = "{" +
        "\"peers\": [\"localhost:7051\", \"localhost:7056\"]," +
        "\"fcn\":\"invoke\"," +
        "\"args\":[\"transfer_fund_to_ngo\",\"" + projectId + "\",\"" + milestoneId + "\",\"" + activityId + "\",\"" + fundBudgeted + "\",\"" + TXNSTATUS + "\",\"" + TXREFNUMBER + "\",\"" + projectOwner + "\"]" +
        "}";
    console.log("release body = ", body);
    rp({
        method: 'POST',
        uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + blockChainToken
        }
    }).then(function(data) {
        console.log("req_activity_fund_release responce  =", data);
        auditTrailFundRelease(req, res);
        deferred.resolve(res);
    });
    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail for update milestone go to db
function auditTrailFundRelease(req, res) {
    var deferred = Q.defer();
    var projectId = req.params.projectId;
    var milestoneId = req.params.milestoneId;
    console.log("milestoneId= ", milestoneId);
    var activityId = req.params.activityId;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate: Date(),
        projectId: projectId,
        milestoneId: milestoneId,
        activityId: activityId,
        role: role,
        username: username,
        currentStatus: 'Fund Released',
        previousStatus: 'Fund Requested'
    };
    console.log("set = ", set);
    db.AuditTable.insert(
        set,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            deferred.resolve();
        });
    return deferred.promise;
}

function BKCFundRequest(req, res) {
    var deferred = Q.defer();
    var activityId = req.params.activityId;
    console.log('activityId++++++', activityId);
    var status = req.params.status;
    // validation
    db.ProjectActivity.findById(activityId, function(err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateProject();

    });

    function updateProject() {
        console.log("status=  = ", status);
        // fields to update
        var set = {
            status: status,
        };
        console.log("set in update function = ", set)
        db.ProjectActivity.update({ activityId: activityId }, { $set: set },
            function(err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                FundRequest(req, res);
                deferred.resolve();
            });

    }

    return deferred.promise;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////
//# Akshay :- 27-07-2017 fund request to blockchain///////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////////////
function FundRequest(req, res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    console.log("token  =  ", blockChainToken);
    var projectId = req.params.projectId;
    console.log("req.body in req 1= ", projectId);
    var milestoneId = req.params.milestoneId;
    console.log("req.body in req 2= ", milestoneId);
    var activityId = req.params.activityId;
    console.log("req.body in req 4= ", activityId);
    var fundReq = req.params.fundReq;
    console.log("req.body in req 5= ", fundReq);
    var fundAllocated = req.body.fundAllocated;
    var validationCheck = req.body.validationCheck;
    var status = req.params.status;
    console.log("status in fund req *=", status);
    // var test = 'test';
    var body = "{" +
        "\"peers\": [\"localhost:7051\", \"localhost:7056\"]," +
        "\"fcn\":\"invoke\"," +
        "\"args\":[\"req_activity_fund_release\",\"" + projectId + "\",\"" + milestoneId + "\",\"" + activityId + "\",\"" + fundReq + "\"]" +
        "}";
    console.log("req body = ", body);
    rp({
        method: 'POST',
        uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + blockChainToken
        }
    }).then(function(data) {
        console.log("req_activity_fund_request responce  =", data);
        auditTrailFundRequest(req, res);
        deferred.resolve(res);

    });
    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail for fund request go to db
function auditTrailFundRequest(req, res) {
    var deferred = Q.defer();
    var projectId = req.params.projectId;
    var milestoneId = req.params.milestoneId;
    console.log("milestoneId= ", milestoneId);
    var activityId = req.params.activityId;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate: Date(),
        projectId: projectId,
        milestoneId: milestoneId,
        activityId: activityId,
        role: role,
        username: username,
        currentStatus: 'Fund Requested',
        previousStatus: 'Fund Allocated'
    };
    console.log("set = ", set);
    db.AuditTable.insert(
        set,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            deferred.resolve();
        });
    return deferred.promise;
}


//#Akshay 08-08-2017 :- fund allocate to milestone
function fundAllocateToMilestone(req, res) {
    var deferred = Q.defer();
    var blockChainToken = req.session.blockChainToken;
    var projectId = req.params.projectId;
    var milestoneId = req.params.milestoneId;
    var fundBudgeted = req.params.fundBudgeted;
    var body = "{" +
        "\"peers\": [\"localhost:7051\", \"localhost:7056\"]," +
        "\"fcn\":\"invoke\"," +
        "\"args\":[\"fund_allocate_milestone\",\"" + projectId + "\",\"" + milestoneId + "\",\"" + fundBudgeted + "\"]" + "}";
    console.log("fund allocate body = ", body);
    rp({
        method: 'POST',
        uri: 'http://104.199.170.142/channels/mychannel/chaincodes/comgoTest',
        body: body,
        headers: {
            'User-Agent': 'Request-Promise',
            'Content-Type': 'application/json',
            'Authorization': 'Bearer ' + blockChainToken
        }
    }).then(function(data) {
        //if (err) deferred.reject(err.name + ': ' + err.message);
        console.log("res after allocate = ", data);
        auditTrailFundAllocate(req, res);
        deferred.resolve(data);
        //   res.send(data);
    });
    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail for fund allocate go to db
function auditTrailFundAllocate(req, res) {
    var deferred = Q.defer();
    var projectId = req.params.projectId;
    var milestoneId = req.params.milestoneId;
    console.log("milestoneId= ", milestoneId);
    var activityId = req.params.activityId;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate: Date(),
        projectId: projectId,
        milestoneId: milestoneId,
        activityId: activityId,
        role: role,
        username: username,
        currentStatus: 'Fund Allocated',
        previousStatus: 'Project Published'
    };
    console.log("set = ", set);
    db.AuditTable.insert(
        set,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            deferred.resolve();
        });
    return deferred.promise;
}


// #GM 060717 :- Update FundReleased in ProjectMilestone
function UpdateFundRel(_id, fundRel) {
    var deferred = Q.defer();

    // validation
    db.ProjectMilestone.findById(_id, function(err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateProjectMilestone();

    });

    function updateProjectMilestone() {
        // fields to update
        var set = {
            fundReleased: fundRel,
            status: 'In Progress'
        };


        db.ProjectMilestone.update({ milestoneId: _id }, { $set: set },
            function(err, milestone) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
    }

    return deferred.promise;
}

// #GM 060717 :- Update proof status in ProjectMilestone
function UpdateProofStatus(_id, status) {
    var deferred = Q.defer();

    // validation
    db.ProjectMilestone.findById(_id, function(err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateProjectMilestone();

    });

    function updateProjectMilestone() {
        // fields to update
        var set = {
            status: status
        };


        db.ProjectMilestone.update({ milestoneId: _id }, { $set: set },
            function(err, milestone) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
    }

    return deferred.promise;
}

//#MG update fundBudgeted
function updateFundBudget(_id, fundBudgeted) {
    var deferred = Q.defer();

    // validation
    db.ProjectMilestone.findById(_id, function(err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateProjectMilestone();

    });

    function updateProjectMilestone() {
        // fields to update
        var set = {
            fundBudgeted: fundBudgeted
        };


        db.ProjectMilestone.update({ milestoneId: _id }, { $set: set },
            function(err, milestone) {
                if (err) deferred.reject(err.name + ': ' + err.message);

                deferred.resolve();
            });
    }

    return deferred.promise;
}


// #update milestone
function update(req, res) {
    var deferred = Q.defer();
    var _id = req.body._id;
    var userParam = req.body;
    db.ProjectMilestone.findById(_id, function(err, user) {
        if (err) deferred.reject(err.name + ': ' + err.message);
        updateMilestone();

    });

    function updateMilestone() {
        // fields to update

        var set = {
            milestone: userParam.milestone,
            startDate: userParam.startDate,
            endDate: userParam.endDate,
            fundBudgeted: userParam.fundBudgeted,
        };
        db.ProjectMilestone.update({ _id: mongo.helper.toObjectID(_id) }, { $set: set },
            function(err, doc) {
                if (err) deferred.reject(err.name + ': ' + err.message);
                auditTrailForUpdateMilestone(req, res);
                deferred.resolve();
            });
    }
    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail for update milestone go to db
function auditTrailForUpdateMilestone(req, res) {
    var deferred = Q.defer();
    var activity = req.body;
    var projectId = activity.projectId;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate: Date(),
        projectId: projectId,
        milestoneId: activity.milestoneId,
        milestone: activity.milestone,
        role: role,
        username: username,
        currentStatus: 'Milestone Updated',
        previousStatus: 'Not Initiated'
    };
    console.log("set = ", set);
    db.AuditTable.insert(
        set,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            deferred.resolve();
        });
    return deferred.promise;
}

function _delete(req, res) {
    var deferred = Q.defer();
    var _id = req.params._id;
    console.log("_id = = ", _id);
    db.ProjectMilestone.remove({ _id: mongo.helper.toObjectID(_id) },
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            auditTrailDeleteMilestone(req, res);
            deferred.resolve();
        });

    return deferred.promise;
}

// Akshay :- 02-08-2017 Audit trail for update milestone go to db
function auditTrailDeleteMilestone(req, res) {
    var deferred = Q.defer();
    // var activity = req.body;
    console.log("_id = = ", req.params);
    var projectId = req.params.projectId;
    var milestoneId = req.params.milestoneId;
    var milestone = req.params.milestone;
    var role = req.session.role;
    var username = req.session.username;
    var set = {
        updatedDate: Date(),
        projectId: projectId,
        milestoneId: milestoneId,
        milestone: milestone,
        role: role,
        username: username,
        currentStatus: 'Milestone Deleted',
        previousStatus: 'Not Initiated'
    };
    console.log("set = ", set);
    db.AuditTable.insert(
        set,
        function(err, doc) {
            if (err) deferred.reject(err.name + ': ' + err.message);
            deferred.resolve();
        });
    return deferred.promise;
}
