﻿require('rootpath')();
var express = require('express');
var app = express();
var session = require('express-session');
var bodyParser = require('body-parser');
var expressJwt = require('express-jwt');
var config = require('config.json');
var cookieParser = require('cookie-parser');
var helmet = require('helmet');
var cors = require('cors');
var md5 = require('md5');
var sha1 = require('js-sha1');
var sha256 = require('js-sha256');
var crypto = require('crypto');
var path = require('path');
var multer = require('multer');

var mkdirp = require('mkdirp');

const Nexmo = require('nexmo');
const nexmo = new Nexmo({
    apiKey: '428f569f',
    apiSecret: '4c63166461b8a296'
}, { debug: true });


var storage = multer.diskStorage({

    destination: function(req, file, cb) {
        var dir = './uploads/' + req.query.projectId + '/' + req.query.milestoneId + '/';
        mkdirp(dir, function(err) {
            if (err) {
                console.error(err);
            }
            // move cb to here
            cb(null, dir);
        });

        console.log("Upload: saved to " + dir + file.originalname);
    },
    filename: function(req, file, cb) {
        cb(null, file.originalname);
    }

})



var upload = multer({ storage: storage })



var genRandomString = function(length) {
    return crypto.randomBytes(Math.ceil(length / 2))
        .toString('hex') /** convert to hexadecimal format */
        .slice(0, length); /** return required number of characters */
};
var sha512 = function(password, salt) {
    var hash = crypto.createHmac('sha512', salt); /** Hashing algorithm sha512 */
    hash.update(password);
    var value = hash.digest('hex');
    return {
        salt: salt,
        passwordHash: value
    };
};

function saltHashPassword(userpassword) {
    var salt = genRandomString(16); /** Gives us salt of length 16 */
    var passwordData = sha512(userpassword, salt);
    console.log('UserPassword = ' + userpassword);
    console.log('Passwordhash = ' + passwordData.passwordHash);
    console.log('nSalt = ' + passwordData.salt);
}

//saltHashPassword('MYPASSWORD');
//saltHashPassword('MYPASSWORD');

app.use(cors());
app.use(helmet());
app.use(cookieParser());
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(session({ secret: config.secret, resave: false, saveUninitialized: true }));

// use JWT auth to secure the api
app.use('/api', expressJwt({ secret: config.secret }).unless({ path: ['/api/users/authenticate', '/api/users/register'] }));

// routes
app.use('/login', require('./controllers/svr.login.controller'));
app.use('/register', require('./controllers/svr.register.controller'));
app.use('/app', require('./controllers/svr.app.controller'));
app.use('/api/users', require('./controllers/api/svr.uses.controller'));
app.use('/api/projects', require('./controllers/api/svr.project.controller'));
app.use('/api/donates', require('./controllers/api/svr.donate.controller'));
app.use('/api/documents', require('./controllers/api/svr.document.controller'));
app.use('/api/proofs', require('./controllers/api/svr.proof.controller'));
app.use('/api/milestone', require('./controllers/api/svr.milestone.controller'));
app.use('/api/activity', require('./controllers/api/svr.activity.controller'));
app.use('/api/mydonation', require('./controllers/api/svr.mydonation.controller'));
app.use('/api/projectimage', require('./controllers/api/svr.projectimage.controller'));
app.use('/api/projectdonation', require('./controllers/api/svr.projectdonation.controller'));
app.use('/api/fundraised', require('./controllers/api/svr.fundraised.controller'));
app.use('/api/banks', require('./controllers/api/svr.bank.controller'));
app.use('/api/donationType', require('./controllers/api/svr.donationtype.controller'));
app.use('/api/frequency', require('./controllers/api/svr.frequency.controller'));
app.use('/api/currency', require('./controllers/api/svr.currency.controller'));
app.use('/api/ngo', require('./controllers/api/svr.ngo.controller'));
app.use('/api/country', require('./controllers/api/svr.country.controller'));
app.use('/api/projecttype', require('./controllers/api/svr.projecttype.controller'));
app.use('/api/modeOfPayment', require('./controllers/api/svr.modeofpayment.controller'));
app.use('/api/projectImage', require('./controllers/api/svr.projectimage.controller'));
app.use('/api/invoices', require('./controllers/api/svr.invoice.controller'));
app.use('/api/fileuploads', require('./controllers/api/svr.fileupload.controller'));
app.use('/api/session', require('./controllers/api/svr.session.controller'));
app.use('/api/uploadImage', require('./controllers/api/svr.imageUpload.controller'));
app.use('/api/transactionSummary', require('./controllers/api/svr.transactionSummary.controller'));
app.use('/timeline/script', express.static(__dirname + '/app/audit/script')); // redirect bootstrap JS
app.use('/timeline/style', express.static(__dirname + '/app/audit/css')); // redirect bootstrap JS

app.use('/js', express.static(__dirname + '/node_modules/bootstrap/dist/js')); // redirect bootstrap JS
app.use('/js', express.static(__dirname + '/node_modules/jquery/dist')); // redirect JS jQuery
app.use('/css', express.static(__dirname + '/node_modules/bootstrap/dist/css')); // redirect CSS bootstrap
app.use('/img', express.static(__dirname + '/views'));
app.use('/img/project', express.static(__dirname + '/images'));
app.use('/file/project', express.static(__dirname + '/files'));
app.use('/uploadDoc', express.static(__dirname + '/uploads'));
app.use('/uploadImage', express.static(__dirname + '/images'));


app.post('/savedata', upload.single('file'), function(req, res, next) {
    console.log('Upload Successful req.file = ', req);
    console.log('Upload Successful req.body = ', req.body);

    var hash1 = md5(req.file);

    console.log('md5=', hash1);
    saltHashPassword(hash1);

    return res.send(hash1);
});


app.post('/send', (req, res) => {
    // Send SMS
    nexmo.message.sendSms(
        '919969507545', req.body.toNumber, req.body.message, { type: 'unicode' },
        (err, responseData) => { if (responseData) { console.log(responseData) } }
    );
});

app.post('/inbound', (req, res) => {
    handleParams(req.body, res);
});

function handleParams(params, res) {
    if (!params.to || !params.msisdn) {
        console.log(params.to);
        console.log(params.msisdn);
        console.log(params);
        console.log('This is not a valid inbound SMS message!');
    } else {
        console.log('Success');
        let incomingData = {
            messageId: params.messageId,
            from: params.msisdn, //mob no
            text: params.text,
            type: params.type,
            timestamp: params['message-timestamp']
        };
        console.log('incomingData=', incomingData)
        res.send(incomingData);
    }
    res.status(200).end();
}

app.get('/incoming-sms', (req, res) => {
    console.log(res.body)
    res.sendResponse(200)
})


// make '/app' default route
app.get('/', function(req, res) {
    return res.redirect('/app');
});

// start server
var server = app.listen(process.env.PORT || 3000, function() {
    console.log('Server listening at http://' + server.address().address + ':' + server.address().port);
});
